Field_code: 1019
hex_data: 0000000003da3f00

## 형식
![[Pasted image 20241012190612.png]]
[[SpaceX.API.Device.GetHeapDumpRequest]]



## 요청정보
- 데이터 없을때
```
{
  "getHeapDump": {}
}
```
[[device.GetHeapDumpRequest]]



## 응답정보
- PermissionDenied (7)
- Permission denied
[[device.GetHeapDumpResponse]]


