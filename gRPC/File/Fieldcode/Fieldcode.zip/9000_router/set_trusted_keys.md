Field_code: 1010
hex_data: 0000000003923f00

## 형식
![[Pasted image 20241012183430.png]]
[[SpaceX.API.Device.SetTrustedKeysRequest]]



## 요청정보
- 데이터 없을때
```
{
  "setTrustedKeys": {
    "keys": []
  }
}
```

- 데이터 있을때
```
{
  "setTrustedKeys": {
    "keys": [
      {
        "capabilities": [
          "SSH"
        ],
        "key": "aa",
        "user": "GOD"
      }
    ]
  }
}
```
[[device.SetTrustedKeysRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_SetTrustedKeys
[[device.SetTrustedKeysResponse]]


