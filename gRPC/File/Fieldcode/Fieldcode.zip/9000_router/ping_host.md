Field_code: 1016
hex_data: 0000000003c23f00

## 형식
![[Pasted image 20241012164826.png]]
[[SpaceX.API.Device.PingHostRequest]]



## 요청정보
- 데이터 없을때
```
{
  "pingHost": {}
}
```

- 데이터 있을때
```
{
  "pingHost": {
    "address": "8.8.8.8"
  }
}
```
[[device.PingHostRequest]]



## 응답정보
- 데이터 없을때
```
{
  "id": "0",
  "status": null,
  "api_version": "61",
  "ping_host": {
    "result": {
      "dropRate": 1,
      "latencyMs": "NaN",
      "target": {
        "service": "",
        "location": "",
        "address": ""
      }
    }
  }
}
```

- 데이터 있을때
```
{
  "id": "0",
  "status": null,
  "api_version": "61",
  "ping_host": {
    "result": {
      "dropRate": 1,
      "latencyMs": 0,
      "target": {
        "service": "",
        "location": "",
        "address": "8.8.8.8"
      }
    }
  }
}
```
[[device.PingHostResponse]]


