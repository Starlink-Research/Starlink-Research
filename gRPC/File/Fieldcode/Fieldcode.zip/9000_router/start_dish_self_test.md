Field_code: 2012
hex_data: 0000000003e27d00

## 형식
![[Pasted image 20241012204603.png]]
[[SpaceX.API.Device.StartDishSelfTestRequest]]



## 요청정보
- 데이터 없을때
```
{
  "startDishSelfTest": {}
}
```
[[dish.StartDishSelfTestRequest]]


## 응답정보
-  Unimplemented (12)
- Unimplemented: *device.Request_StartDishSelfTest
[[dish.StartDishSelfTestResponse]]

