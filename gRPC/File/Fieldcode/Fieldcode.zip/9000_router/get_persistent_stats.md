Field_code: 1022
hex_data: 0000000003f23f00

## 형식
![[Pasted image 20241012191409.png]]
[[SpaceX.API.Device.GetPersistentStatsRequest]]



## 요청정보
- 데이터 없을때
```
{
  "getPersistentStats": {}
}
```
[[device.GetPersistentStatsRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_GetPersistentStats
[[wifi.WifiGetPersistentStatsResponse]]


