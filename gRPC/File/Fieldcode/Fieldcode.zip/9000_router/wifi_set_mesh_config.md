Field_code: 3013
hex_data: 0000000004aabc0100

## 형식
![[Pasted image 20241013135239.png]]
[[SpaceX.API.Device.WifiSetMeshConfigRequest]]



## 요청정보
- 데이터 없을때
```
{
  "wifiSetMeshConfig": {}
}
```

- 데이터 있을때
```
{
  "wifiSetMeshConfig": {
    "meshConfig": {
      "displayName": "a",
      "applyDisplayName": false,
      "auth": "MESH_AUTH_UNKNOWN",
      "applyAuth": false,
      "lastConnected": "0",
      "incarnation": "0",
      "hardwareVersion": "a",
      "supports5ghzHigh": false
    },
    "deviceId": "a"
  }
}
```
[[wifi.WifiSetMeshConfigRequest]]


## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_WifiSetMeshConfig

[[wifi.WifiSetMeshConfigResponse]]


