Field_code: 4001
hex_data: 00000000048afa0100

## 형식
![[Pasted image 20241013141549.png]]
[[SpaceX.API.Device.TransceiverIFLoopbackTestRequest]]


## 요청정보
- 데이터 없을때
```
{
  "transceiverIfLoopbackTest": {}
}
```

- 데이터 있을때
```
{
  "transceiverIfLoopbackTest": {
    "enableIfLoopback": false
  }
}
```
[[transceiver.TransceiverIFLoopbackTestRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_TransceiverIfLoopbackTest
[[transceiver.TransceiverIFLoopbackTestResponse]]


