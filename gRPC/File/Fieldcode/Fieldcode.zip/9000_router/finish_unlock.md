Field_code: 5001
hex_data: 0000000004cab80200

## 형식
![[Pasted image 20241013142053.png]]
[[SpaceX.API.Device.Services.Unlock.FinishUnlockRequest]]


## 요청정보
- 데이터 없을때
```
{
  "finishUnlock": {}
}
```

- 데이터 있을때
```
{
  "finishUnlock": {
    "challenge": "Re8wt9ZPLaFkYgPDFQo5Kg==",
    "signature": "MCowBQYDK2VwAyEAJ4tUpX9rxlBWYS027URbkFiJ7tt0Bj4UWGZr4cFqACk="
  }
}
```
[[service.FinishUnlockRequest]]




## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "61",
  "finish_unlock": {
    "status": 0
  }
}
```
[[service.FinishUnlockRespons]]


