Field_code: 3020
hex_data: 0000000004e2bc0100

## 형식
![[Pasted image 20241013140646.png]]
[[SpaceX.API.Device.WifiGuestInfoRequest]]



## 요청정보
- 데이터 없을때
```
{
  "wifiGuestInfo": {}
}
```
[[wifi.WifiGuestInfoRequest]]



## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "61",
  "wifi_guest_info": {
    "is_guest": false,
    "is_online": false,
    "router_hardware_version": "v3",
    "dish_hardware_version": "rev4_prod3",
    "is_router_aviation_conformed": false
  }
}
```
[[wifi.WifiGuestInfoResponse]]


