Field_code: 1003
hex_data: 0000000003da3e00

## 형식
![[Pasted image 20241012184014.png]]
[[SpaceX.API.Device.SpeedTestRequest]]



## 요청정보
- 데이터 없을때
```
{
  "speedTest": {}
}
```

- 데이터 있을때
```
{
  "speedTest": {
    "id": 0,
    "clientSpeedtest": {
      "latencyMs": 0,
      "startTime": "0",
      "uploadStartTime": "0",
      "downloadStartTime": "0",
      "uploadMbps": 0,
      "downloadMbps": 0,
      "target": "FASTCOM",
      "tcpStreams": 0
    },
    "clientPlatform": {
      "platform": "ANDROID",
      "majorVersion": 0,
      "minorVersion": 0
    },
    "clientRssi": 0
  }
}
```
[[device.SpeedTestRequest]]



## 응답정보
- Internal (13)
- Failed to run router speed test.
[[device.SpeedTestResponse]]


