Field_code: 5000
hex_data: 0000000004c2b80200

## 형식
![[Pasted image 20241013141805.png]]
[[SpaceX.API.Device.Services.Unlock.StartUnlockRequest]]


## 요청정보
- 데이터 없을때
```
{
  "startUnlock": {}
}
```
[[service.StartUnlockRequest]]



## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "61",
  "start_unlock": {
    "device_id": "router01000000-00000000-00CEF48F",
    "nonce": "Re8wt9ZPLaFkYgPDFQo5Kg==",
    "sign_spki": "MCowBQYDK2VwAyEAJ4tUpX9rxlBWYS027URbkFiJ7tt0Bj4UWGZr4cFqACk="
  }
}
```
[[service.StartUnlockResponse]]


