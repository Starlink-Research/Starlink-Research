Field_code: 2017
hex_data: 00000000038a7e00

## 형식
![[Pasted image 20241012212725.png]]
[[SpaceX.API.Device.DishClearObstructionMapRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishClearObstructionMap": {}
}
```
[[dish.DishClearObstructionMapRequest]]


## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_DishClearObstructionMap
[[dish.DishClearObstructionMapResponse]]

