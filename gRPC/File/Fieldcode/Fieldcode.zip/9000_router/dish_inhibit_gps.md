Field_code: 2014
hex_data: 0000000003f27d00

## 형식
![[Pasted image 20241012211944.png]]
[[SpaceX.API.Device.DishInhibitGpsRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishInhibitGps": {}
}
```

- 데이터 있을때
```
{
  "dishInhibitGps": {
    "inhibitGps": true
  }
}
```
[[dish.DishInhibitGpsRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_DishInhibitGps
[[dish.DishInhibitGpsResponse]]



