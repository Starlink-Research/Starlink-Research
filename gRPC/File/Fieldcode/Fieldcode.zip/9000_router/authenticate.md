Field_code: 1005
hex_data: 0000000003ea3e00

## 형식
![[Pasted image 20241012155845.png]]
[[SpaceX.API.Device.AuthenticateRequest]]




## 요청정보
- 데이터 없을때
```
{
  "authenticate": {}
}
```

- 데이터 있을때
```
{
  "authenticate": {
    "challenge": {
      "data": "",
      "signature": ""
    }
  }
}
```
[[common.AuthenticateRequest]]


## 응답정보
- PermissionDenied (7)
- Permission denied
[[wifi.WifiAuthenticateResponse]]



