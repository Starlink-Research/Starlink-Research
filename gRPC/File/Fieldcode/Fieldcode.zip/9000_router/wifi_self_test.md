Field_code: 3018
hex_data: 0000000004d2bc0100

## 형식
![[Pasted image 20241013135738.png]]
[[SpaceX.API.Device.WifiSelfTestRequest]]



## 요청정보
- 데이터 없을때
```
{
  "wifiSelfTest": {}
}
```
[[wifi.WifiSelfTestRequest]]


## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "61",
  "wifi_self_test": {
    "self_test": {
      "total_success": false,
      "fused": {
        "name": "fused",
        "success": true,
        "failure_reason": ""
      },
      "eth_phys": [
        {
          "name": "lan0",
          "success": false,
          "failure_reason": "Ethernet interface (lan0) configured incorrectly (link detected: (false), speed: (4294967295), duplex: (unknown), autoneg: (on))"
        },
        {
          "name": "lan1",
          "success": false,
          "failure_reason": "Ethernet interface (lan1) configured incorrectly (link detected: (false), speed: (4294967295), duplex: (unknown), autoneg: (on))"
        },
        {
          "name": "wan0",
          "success": false,
          "failure_reason": "Ethernet interface (wan0) configured incorrectly (link detected: (false), speed: (4294967295), duplex: (unknown), autoneg: (on))"
        },
        {
          "name": "eth0",
          "success": true,
          "failure_reason": ""
        }
      ],
      "pcis": [
        {
          "name": "mt7986",
          "success": true,
          "failure_reason": ""
        },
        {
          "name": "root_port",
          "success": true,
          "failure_reason": ""
        },
        {
          "name": "mt7915",
          "success": true,
          "failure_reason": ""
        }
      ],
      "bl2_prod": {
        "name": "bl2_prod",
        "success": true,
        "failure_reason": ""
      }
    },
    "json": "{\"hw_id\":0,\"temp_sense_cal1\":1035,\"temp_sense_cal2\":1373,\"vrefint_cal\":1659,\"vsns_bus\":56.39698,\"vsns_vin\":56.29821,\"isns_vin\":2.1021516,\"power_vin\":118.347374,\"poe_detect\":12722.447,\"vsns_poe_ch1\":55.62833,\"vsns_poe_ch2\":55.89647,\"isns_poe_rtn1\":0.5422845,\"isns_poe_rtn2\":0.9228897,\"poe_power\":81.752655,\"vsns_v_5p0_fem0\":5.075939,\"vsns_v_5p0_fem1\":5.134854,\"isns_fem0\":0.1450354,\"isns_fem1\":0.26656508,\"fem0_power\":0.73619086,\"fem1_power\":1.3687727,\"vsns_water_detect\":-4.046914,\"percent_water_detect_min\":0.04884005,\"percent_water_detect_max\":0.12210012,\"percent_water_detect_avg\":0.07326007,\"v_refint\":2.0431035,\"vsns_v_3p3\":3.3353143,\"vsns_v_10p0\":10.035865,\"vsns_v_0p5_ref\":0.56563807,\"tsns_stm32_die\":49.366455,\"tsns_board\":44.67647,\"poe_state\":3,\"poe_fault\":0,\"Radio2GhzTemp\":53,\"Radio5GhzTemp\":53,\"Radio5GhzHighTemp\":0}"
  }
}
```
[[wifi.WifiSelfTestResponse]]


