Field_code: 3016
hex_data: 0000000004c2bc0100

## 형식
![[Pasted image 20241013135705.png]]
[[SpaceX.API.Device.WifiSetAviationConformedRequest]]



## 요청정보
- 데이터 없을때
```
{
  "wifiSetAviationConformed": {}
}
```
[[wifi.WifiSetAviationConformedRequest]]


## 응답정보
- PermissionDenied (7)
- Permission denied


