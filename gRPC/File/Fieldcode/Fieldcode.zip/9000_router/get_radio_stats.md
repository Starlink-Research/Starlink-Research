Field_code: 1036
hex_data: 0000000003e24000

## 형식
![[Pasted image 20241012195213.png]]
[[SpaceX.API.Device.GetRadioStatsRequest]]



## 요청정보
- 데이터 없을때
```
{
  "getRadioStats": {}
}
```
[[device.GetRadioStatsRequest]]



## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "61",
  "get_radio_stats": {
    "radio_stats": [
      {
        "band": "RF_2GHZ",
        "rx_stats": {
          "bytes": "472526",
          "packets": "5865",
          "frame_errors": "0"
        },
        "tx_stats": {
          "bytes": "576552",
          "packets": "8041"
        },
        "thermal_status": {
          "level": 0,
          "temp": 0,
          "temp2": 49,
          "power_reduction": 0,
          "duty_cycle": 100
        },
        "antenna_status": {
          "rssi1": "NaN",
          "rssi2": "NaN",
          "rssi3": "NaN",
          "rssi4": "NaN"
        }
      },
      {
        "band": "RF_5GHZ",
        "rx_stats": {
          "bytes": "17322155",
          "packets": "227198",
          "frame_errors": "0"
        },
        "tx_stats": {
          "bytes": "25595343",
          "packets": "320769"
        },
        "thermal_status": {
          "level": 0,
          "temp": 0,
          "temp2": 48,
          "power_reduction": 0,
          "duty_cycle": 100
        },
        "antenna_status": {
          "rssi1": -42,
          "rssi2": -56,
          "rssi3": -42,
          "rssi4": -48
        }
      },
      {
        "band": "RF_5GHZ_HIGH",
        "rx_stats": null,
        "tx_stats": null,
        "thermal_status": null,
        "antenna_status": null
      }
    ]
  }
}
```
[[device.GetRadioStatsResponse]]



