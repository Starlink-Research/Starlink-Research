Field_code: 1001
hex_data: 0000000003ca3e00

## 형식
![[Pasted image 20241012182545.png]]
[[SpaceX.API.Device.RebootRequest]]



## 요청정보
- 데이터 없을때
```
{
  "reboot": {}
}
```
[[device.RebootRequest]]



## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "61",
  "reboot": {}
}
```
[[device.RebootResponse]]





