Field_code: 1012
hex_data: 0000000003a23f00

## 형식
![[Pasted image 20241012163921.png]]
[[SpaceX.API.Device.GetLogRequest]]



## 요청정보
- 데이터 없을때
```
{
  "getLog": {}
}
```
[[device.GetLogRequest]]



## 응답정보
- PermissionDenied (7)
- Permission denied
[[device.GetLogResponse]]


