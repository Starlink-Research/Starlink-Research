Field_code: 4003
hex_data: 00000000049afa0100

## 형식
![[Pasted image 20241013141635.png]]
[[SpaceX.API.Device.TransceiverGetStatusRequest]]


## 요청정보
- 데이터 없을때
```
{
  "transceiverGetStatus": {}
}
```
[[transceiver.TransceiverGetStatusRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_TransceiverGetStatus
[[transceiver.TransceiverGetStatusResponse]]


