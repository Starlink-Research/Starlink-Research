Field_code: 2003
hex_data: 00000000039a7d00

## 형식
![[Pasted image 20241012204816.png]]
[[SpaceX.API.Device.DishGetContextRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishGetContext": {}
}
```
[[dish.DishGetContextRequest]]


## 응답정보
-  Unimplemented (12)
- Unimplemented: *device.Request_StartDishSelfTest
[[dish.DishGetContextResponse]]

