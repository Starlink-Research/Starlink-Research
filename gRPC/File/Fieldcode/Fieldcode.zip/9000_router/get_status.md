Field_code: 1004
hex_data: 0000000003E23E00

## 형식
![[Pasted image 20241012165254.png]]
[[SpaceX.API.Device.GetStatusRequest]]



## 요청정보
- 데이터 없을때
```
{
  "getStatus": {}
}
```
[[device.GetStatusRequest]]



## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "61",
  "wifi_get_status": {
    "captive_portal_enabled": false,
    "device_info": {
      "id": "Router-010000000000000000CEF48F",
      "hardware_version": "v3",
      "software_version": "2024.20.0.mr34287",
      "country_code": "",
      "utc_offset_s": 0,
      "software_partitions_equal": true,
      "is_dev": false,
      "bootcount": 73,
      "anti_rollback_version": 1,
      "is_hitl": false,
      "manufactured_version": "2024.20.0.mr34287",
      "generation_number": "0",
      "dish_cohoused": false,
      "board_rev": 8,
      "boot": {
        "count_by_reason": {
          "0": 28,
          "1": 39,
          "2": 0,
          "3": 5,
          "5": 1
        },
        "last_reason": "POWER_CYCLE",
        "last_count": 73,
        "count_by_reason_delta": {
          "0": 23,
          "2": 0,
          "3": 5
        },
        "crash_boot": false,
        "crash_boot_count": 0
      }
    },
    "device_state": {
      "uptime_s": "11874"
    },
    "ipv4_wan_address": "206.214.239.194/24",
    "ping_drop_rate": 1,
    "ping_latency_ms": "NaN",
    "rf_2ghz_status": null,
    "rf_5ghz_status": null,
    "alerts": {
      "thermal_throttle": false,
      "install_pending": false,
      "freshly_fused": false,
      "lan_eth_slow_link_10": false,
      "lan_eth_slow_link_100": false,
      "wan_eth_poor_connection": false,
      "mesh_topology_changing_often": false,
      "mesh_unreliable_backhaul": false,
      "radius_missing_process": false,
      "eth_switch_error": false,
      "poe_on_dish_unreachable": false,
      "poe_fuse_blown": false,
      "poe_router_overcurrent": false,
      "poe_off_current_nominal": false,
      "poe_vin_overvoltage": false,
      "poe_vin_undervoltage": false
    },
    "is_aviation": false,
    "dish_ping_drop_rate": 0,
    "dish_ping_latency_ms": 0.5352105,
    "pop_ping_drop_rate": 1,
    "pop_ping_latency_ms": "NaN",
    "is_aviation_conformed": false,
    "ipv6_wan_addresses": [
      "fe80::7624:9fff:fe4e:f48f/64"
    ],
    "dish_ping_drop_rate_5m": 0,
    "dhcp_servers": [
      {
        "domain": "lan",
        "subnet": "192.168.1.0/24",
        "leases": [
          {
            "ip_address": "192.168.1.22",
            "mac_address": "18:93:41:XX:XX:XX",
            "hostname": "book-846ijsq8db",
            "expires_time": "2024-03-30 00:03:00.752508278 +0000 UTC m=+12137.344885279",
            "active": true,
            "client_id": 107612116
          },
          {
            "ip_address": "192.168.1.23",
            "mac_address": "8e:ed:64:XX:XX:XX",
            "hostname": "",
            "expires_time": "2024-03-30 00:41:46.638150186 +0000 UTC m=+14463.230527494",
            "active": true,
            "client_id": 3499858082
          },
          {
            "ip_address": "192.168.1.24",
            "mac_address": "22:f1:a6:XX:XX:XX",
            "hostname": "aresares",
            "expires_time": "2024-03-30 00:03:08.956246125 +0000 UTC m=+12145.548623125",
            "active": true,
            "client_id": 1464166850
          },
          {
            "ip_address": "192.168.1.25",
            "mac_address": "98:af:65:XX:XX:XX",
            "hostname": "barrack-pc",
            "expires_time": "2024-03-30 00:13:40.406725316 +0000 UTC m=+12776.999102317",
            "active": true,
            "client_id": 3036033537
          },
          {
            "ip_address": "192.168.1.21",
            "mac_address": "2c:7b:a0:XX:XX:XX",
            "hostname": "syul",
            "expires_time": "2024-03-30 00:44:52.097229351 +0000 UTC m=+14648.689606351",
            "active": true,
            "client_id": 1868513240
          }
        ]
      },
      {
        "domain": "backhaul",
        "subnet": "192.168.2.0/24",
        "leases": []
      },
      {
        "domain": "hiddenlan",
        "subnet": "192.168.254.0/24",
        "leases": [
          {
            "ip_address": "192.168.254.21",
            "mac_address": "74:24:9f:XX:XX:XX",
            "hostname": "",
            "expires_time": "2024-03-29 23:10:39.158615057 +0000 UTC m=+8995.750992134",
            "active": true,
            "client_id": 1629416377
          }
        ]
      }
    ],
    "pop_ping_drop_rate_5m": 1,
    "ping_drop_rate_5m": 1,
    "poe_stats": {
      "poe_state": "POE_STATE_ON",
      "poe_power": 10.048459,
      "poe_faults_fast_overcurrent": 1,
      "poe_faults_slow_overcurrent": 0,
      "poe_faults_overvoltage": 0,
      "poe_faults_undervoltage": 0
    },
    "dish_id": "ut01000000-00000000-00df1780",
    "utc_ns": "1711756705150135938",
    "config": {
      "country_code": "",
      "setup_complete": true,
      "version": 0,
      "mac_wan": "74:24:9f:4e:f4:8f",
      "mac_lan": "74:24:9f:5e:f4:8f",
      "channel_2ghz": 0,
      "channel_5ghz": 0,
      "dynamic_keys": [],
      "is_repeater": false,
      "boot_count": 73,
      "nameservers": [],
      "bypass_mode": false,
      "mesh_configs": {
        "Router-010000000000000000F5951C": {
          "display_name": "Mesh 1",
          "apply_display_name": false,
          "auth": "MESH_AUTH_NEW",
          "apply_auth": false,
          "last_connected": "0",
          "incarnation": "12261697686743714150",
          "hardware_version": "v3",
          "supports_5ghz_high": true
        }
      },
      "apply_dynamic_keys": false,
      "dfs_enabled": false,
      "incarnation": "1819507386833945120",
      "wireless_mode_2ghz": "WIRELESS_MODE_DEFAULT",
      "wireless_mode_5ghz": "WIRELESS_MODE_DEFAULT",
      "ht_bandwidth_2ghz": "HT_BANDWIDTH_DEFAULT",
      "ht_bandwidth_5ghz": "HT_BANDWIDTH_DEFAULT",
      "vht_bandwidth": "VHT_BANDWIDTH_DEFAULT",
      "is_aviation": false,
      "secure_dns": false,
      "ap_mode": false,
      "disable_mesh_onboarding": false,
      "pin_country_code": false,
      "custom_power_table": false,
      "use_public_services": false,
      "disable_automated_speedtests": false,
      "channel_5ghz_high": 0,
      "wireless_mode_5ghz_high": "WIRELESS_MODE_DEFAULT",
      "ht_bandwidth_5ghz_high": "HT_BANDWIDTH_DEFAULT",
      "vht_bandwidth_5ghz_high": "VHT_BANDWIDTH_DEFAULT",
      "enable_umbilical_vlan": false,
      "client_names": [],
      "outdoor_mode": false,
      "disable_2ghz": false,
      "disable_5ghz": false,
      "disable_5ghz_high": false,
      "disable_x_mesh_backhaul": false,
      "golden_bssid": "",
      "golden_iface_type": "IFACE_TYPE_UNKNOWN",
      "tx_power_level_2ghz": "TX_POWER_LEVEL_100",
      "tx_power_level_5ghz": "TX_POWER_LEVEL_100",
      "tx_power_level_5ghz_high": "TX_POWER_LEVEL_100",
      "disable_pending_update_reboot": false,
      "client_configs": [],
      "disable_set_wifi_config_from_controller": false,
      "client_key": "",
      "wan_host_dscp_mark": 1,
      "tag": 0,
      "apply_setup_complete": false,
      "apply_channel_2ghz": false,
      "apply_channel_5ghz": false,
      "apply_channel_5ghz_high": false,
      "apply_is_repeater": false,
      "apply_mesh_configs": false,
      "apply_nameservers": false,
      "apply_bypass_mode": false,
      "apply_dfs_enabled": false,
      "apply_wireless_mode_2ghz": false,
      "apply_wireless_mode_5ghz": false,
      "apply_ht_bandwidth_2ghz": false,
      "apply_ht_bandwidth_5ghz": false,
      "apply_vht_bandwidth": false,
      "apply_is_aviation": false,
      "apply_secure_dns": false,
      "apply_ap_mode": false,
      "apply_disable_mesh_onboarding": false,
      "apply_use_public_services": false,
      "apply_disable_automated_speedtests": false,
      "apply_wireless_mode_5ghz_high": false,
      "apply_ht_bandwidth_5ghz_high": false,
      "apply_vht_bandwidth_5ghz_high": false,
      "apply_enable_umbilical_vlan": false,
      "apply_client_names": false,
      "apply_outdoor_mode": false,
      "apply_disable_2ghz": false,
      "apply_disable_5ghz": false,
      "apply_disable_5ghz_high": false,
      "apply_disable_x_mesh_backhaul": false,
      "apply_golden_bssid": false,
      "apply_golden_iface_type": false,
      "apply_tx_power_level_2ghz": false,
      "apply_tx_power_level_5ghz": false,
      "apply_tx_power_level_5ghz_high": false,
      "apply_country_code": false,
      "apply_pin_country_code": false,
      "apply_custom_power_table": false,
      "apply_disable_pending_update_reboot": false,
      "apply_client_configs": false,
      "apply_disable_set_wifi_config_from_controller": false,
      "apply_client_key": false,
      "apply_wan_traffic_control": false,
      "apply_wan_host_dscp_mark": false,
      "networks": [
        {
          "ipv4": "192.168.1.1/24",
          "basic_service_sets": [
            {
              "bssid": "32:54:02:2f:c2:20",
              "ssid": "별가디언",
              "band": "RF_2GHZ",
              "disable": false,
              "hidden": false,
              "iface_name": "ra0",
              "auth_wpa2": {
                "password": "••••••••"
              }
            },
            {
              "bssid": "32:54:02:3f:c2:20",
              "ssid": "별가디언",
              "band": "RF_5GHZ",
              "disable": false,
              "hidden": false,
              "iface_name": "rax0",
              "auth_wpa2": {
                "password": "••••••••"
              }
            },
            {
              "bssid": "32:54:02:4f:c2:20",
              "ssid": "별가디언",
              "band": "RF_5GHZ_HIGH",
              "disable": false,
              "hidden": false,
              "iface_name": "rai0",
              "auth_wpa2": {
                "password": "••••••••"
              }
            }
          ],
          "client_isolation": false,
          "guest": false,
          "landing": "",
          "domain": "lan",
          "dhcpv4_start": 20,
          "internal": false,
          "vlan": 100,
          "dhcp_disabled": false,
          "dhcpv4_lease_duration_s": 3600,
          "landing_page_v2": false
        }
      ],
      "apply_networks": false,
      "boot": {
        "count_by_reason": {
          "0": 28,
          "1": 39,
          "2": 0,
          "3": 5,
          "5": 1
        },
        "last_reason": "POWER_CYCLE",
        "last_count": 73,
        "count_by_reason_delta": {
          "0": 23,
          "2": 0,
          "3": 5
        },
        "crash_boot": false,
        "crash_boot_count": 0
      },
      "mesh_configs_updates": {},
      "wan_ack_suppression": {
        "ack_mark": 1056,
        "htb_ack_queue_rate": 2,
        "htb_ack_queue_ceil": 2.5,
        "cake_queue_bandwidth": 1.75,
        "cake_ack_filter_aggressive": true,
        "cake_manual_rtt": 0
      }
    },
    "clients": [
      {
        "name": "Controller",
        "mac_address": "74:24:9f:5e:f4:8f",
        "ip_address": "",
        "signal_strength": 0,
        "rx_stats": null,
        "tx_stats": null,
        "associated_time_s": 0,
        "mode_str": "",
        "iface": "ETH",
        "snr": 0,
        "psmode": 0,
        "channel_width": 0,
        "upstream_mac_address": "",
        "role": "CONTROLLER",
        "device_id": "Router-010000000000000000CEF48F",
        "swq_checks": 0,
        "swq_checks_non_empty": 0,
        "mib_steer_state": 0,
        "mib_steer_method": 0,
        "btm_requests": 0,
        "btm_requests_success": 0,
        "domain": "",
        "dot11v_support": false,
        "iface_name": "",
        "steer_req_success_last_1h": 0,
        "steer_req_fail_last_1h": 0,
        "steer_req_fail_and_dissoc_last_1h": 0,
        "steer_state": 0,
        "given_name": "",
        "hops_from_controller": 0,
        "est_tx_rate_mbps_from_controller": 0,
        "est_rx_rate_mbps_from_controller": 0,
        "hardware_version": "",
        "software_version": "",
        "api_version": 0,
        "ping_metrics": null,
        "ipv6_addresses": [],
        "blocked": false,
        "client_id": 0,
        "fqcodel_info": null
      },
      {
        "name": "syul",
        "mac_address": "2c:7b:a0:XX:XX:XX",
        "ip_address": "192.168.1.21",
        "signal_strength": -40,
        "rx_stats": {
          "bytes": "15931100",
          "count_errors": "0",
          "nss": 2,
          "mcs": 11,
          "bandwidth": 80,
          "guard_ns": 800,
          "rate_mbps": 1201,
          "airtime_fraction_last_1s": 0,
          "sampled_packets": 0,
          "sampled_packets_retried": 0,
          "sampled_packets_dropped": 0,
          "phy_mode": 8,
          "rate_mbps_last_30s": 1201,
          "rate_mbps_last_15s": 1201
        },
        "tx_stats": {
          "bytes": "11428536",
          "success_bytes": "0",
          "nss": 1,
          "mcs": 4,
          "bandwidth": 80,
          "guard_ns": 800,
          "rate_mbps": 216,
          "airtime_fraction_last_1s": 0,
          "phy_mode": 8,
          "rate_mbps_last_30s": 427.07144,
          "rate_mbps_last_15s": 478.66666
        },
        "associated_time_s": 5152,
        "mode_str": "",
        "iface": "RF_5GHZ",
        "snr": 48,
        "psmode": 0,
        "channel_width": 80,
        "upstream_mac_address": "74:24:9f:5e:f4:8f",
        "role": "CLIENT",
        "device_id": "",
        "swq_checks": 0,
        "swq_checks_non_empty": 0,
        "mib_steer_state": 0,
        "mib_steer_method": 0,
        "btm_requests": 0,
        "btm_requests_success": 0,
        "domain": "lan",
        "dot11v_support": true,
        "iface_name": "rax0",
        "steer_req_success_last_1h": 0,
        "steer_req_fail_last_1h": 0,
        "steer_req_fail_and_dissoc_last_1h": 0,
        "steer_state": 2,
        "given_name": "",
        "hops_from_controller": 1,
        "est_tx_rate_mbps_from_controller": 796.2288,
        "est_rx_rate_mbps_from_controller": 796.2288,
        "hardware_version": "",
        "software_version": "",
        "api_version": 0,
        "ping_metrics": null,
        "ipv6_addresses": [
          "fe80::cc00:a287:2513:2ca5",
          "fd54:26f:c220:10:7c82:781c:8051:6e9c",
          "fd54:26f:c220:10:b599:a45d:1721:636d"
        ],
        "blocked": false,
        "client_id": 1868513240,
        "fqcodel_info": null
      },
      {
        "name": "",
        "mac_address": "8e:ed:64:XX:XX:XX",
        "ip_address": "192.168.1.23",
        "signal_strength": -56,
        "rx_stats": {
          "bytes": "102567",
          "count_errors": "0",
          "nss": 2,
          "mcs": 6,
          "bandwidth": 80,
          "guard_ns": 800,
          "rate_mbps": 526,
          "airtime_fraction_last_1s": 0,
          "sampled_packets": 0,
          "sampled_packets_retried": 0,
          "sampled_packets_dropped": 0,
          "phy_mode": 4,
          "rate_mbps_last_30s": 526,
          "rate_mbps_last_15s": 526
        },
        "tx_stats": {
          "bytes": "68212",
          "success_bytes": "0",
          "nss": 2,
          "mcs": 9,
          "bandwidth": 80,
          "guard_ns": 800,
          "rate_mbps": 780,
          "airtime_fraction_last_1s": 0,
          "phy_mode": 4,
          "rate_mbps_last_30s": 780,
          "rate_mbps_last_15s": 780
        },
        "associated_time_s": 960,
        "mode_str": "",
        "iface": "RF_5GHZ",
        "snr": 32,
        "psmode": 1,
        "channel_width": 80,
        "upstream_mac_address": "74:24:9f:5e:f4:8f",
        "role": "CLIENT",
        "device_id": "",
        "swq_checks": 0,
        "swq_checks_non_empty": 0,
        "mib_steer_state": 0,
        "mib_steer_method": 0,
        "btm_requests": 0,
        "btm_requests_success": 0,
        "domain": "lan",
        "dot11v_support": true,
        "iface_name": "rax0",
        "steer_req_success_last_1h": 0,
        "steer_req_fail_last_1h": 0,
        "steer_req_fail_and_dissoc_last_1h": 0,
        "steer_state": 2,
        "given_name": "",
        "hops_from_controller": 1,
        "est_tx_rate_mbps_from_controller": 653,
        "est_rx_rate_mbps_from_controller": 653,
        "hardware_version": "",
        "software_version": "",
        "api_version": 0,
        "ping_metrics": null,
        "ipv6_addresses": [
          "fe80::83a:6ed:2210:c55b"
        ],
        "blocked": false,
        "client_id": 3499858082,
        "fqcodel_info": null
      }
    ],
    "has_client_index": true,
    "client_index": 1,
    "radius_stats": null
  }
}
```
[[wifi.WifiGetStatusResponse]]





