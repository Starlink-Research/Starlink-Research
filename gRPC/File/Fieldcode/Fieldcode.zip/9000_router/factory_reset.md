Field_code: 1011
hex_data: 00000000039a3f00

## 형식
![[Pasted image 20241012161627.png]]
[[SpaceX.API.Device.FactoryResetRequest]]



## 요청정보
- 데이터 없을때
```
{
  "factoryReset": {}
}
```
[[device.FactoryResetRequest]]


## 응답정보
- PermissionDenied (7)
- Permission denied
[[device.FactoryResetResponse]]

