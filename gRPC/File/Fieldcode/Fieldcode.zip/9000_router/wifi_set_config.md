Field_code: 3001
hex_data: 0000000004cabb0100

## 형식
![[Pasted image 20241012213820.png]]
[[SpaceX.API.Device.WifiSetConfigRequest]]



## 요청정보
- 데이터 없을때
```
{
  "wifiSetConfig": {}
}
```

- 데이터 있을때
```
{
  "wifiSetConfig": {
    "wifiConfig": {
      "meshConfigs": {
        "a": {
          "displayName": "a",
          "applyDisplayName": false,
          "auth": "MESH_AUTH_UNKNOWN",
          "applyAuth": false,
          "lastConnected": "0",
          "incarnation": "0",
          "hardwareVersion": "a",
          "supports5ghzHigh": false
        }
      },
      "meshConfigsUpdates": {
        "b": {
          "displayName": "b",
          "applyDisplayName": false,
          "auth": "MESH_AUTH_UNKNOWN",
          "applyAuth": false,
          "lastConnected": "0",
          "incarnation": "0",
          "hardwareVersion": "b",
          "supports5ghzHigh": false
        }
      },
      "dynamicKeys": [
        {
          "capabilities": [
            "READ"
          ],
          "key": "a",
          "user": "GOD"
        }
      ],
      "nameservers": [
        "a"
      ],
      "networks": [
        {
          "basicServiceSets": [
            {
              "bssid": "a",
              "ssid": "a",
              "authWpa3": {
                "password": "a"
              },
              "band": "RF_UNKNOWN",
              "ifaceName": "a",
              "disable": false,
              "hidden": false
            }
          ],
          "ipv4": "a",
          "dhcpv4Start": 0,
          "dhcpDisabled": false,
          "dhcpv4LeaseDurationS": 0,
          "domain": "a",
          "clientIsolation": false,
          "guest": false,
          "landing": "a",
          "landingPageV2": false,
          "internal": false,
          "vlan": 0
        }
      ],
      "clientNames": [
        {
          "macAddress": "a",
          "givenName": "a"
        }
      ],
      "clientConfigs": [
        {
          "weeklyBlockSchedules": [
            {
              "blockRanges": [
                {
                  "startMinutes": 0,
                  "endMinutes": 0
                }
              ],
              "groupId": "a"
            }
          ],
          "clientId": 0,
          "macAddress": "a",
          "givenName": "a",
          "groupId": "a"
        }
      ],
      "countryCode": "a",
      "applyCountryCode": false,
      "pinCountryCode": false,
      "applyPinCountryCode": false,
      "customPowerTable": false,
      "applyCustomPowerTable": false,
      "setupComplete": false,
      "applySetupComplete": false,
      "version": 0,
      "macWan": "a",
      "macLan": "a",
      "channel2ghz": 0,
      "applyChannel2ghz": false,
      "channel5ghz": 0,
      "applyChannel5ghz": false,
      "channel5ghzHigh": 0,
      "applyChannel5ghzHigh": false,
      "applyMeshConfigs": false,
      "applyDynamicKeys": false,
      "isRepeater": false,
      "applyIsRepeater": false,
      "applyApMode": false,
      "apMode": false,
      "isAviation": false,
      "applyIsAviation": false,
      "bootCount": 0,
      "boot": {
        "countByReason": {
          "0": 0
        },
        "countByReasonDelta": {
          "0": 0
        },
        "lastReason": "BOOT_REASON_UNKNOWN",
        "lastCount": 0,
        "crashBoot": false,
        "crashBootCount": 0
      },
      "applyNameservers": false,
      "secureDns": false,
      "applySecureDns": false,
      "bypassMode": false,
      "applyBypassMode": false,
      "dfsEnabled": false,
      "applyDfsEnabled": false,
      "disableMeshOnboarding": false,
      "applyDisableMeshOnboarding": false,
      "applyNetworks": false,
      "incarnation": "0",
      "wirelessMode2ghz": "WIRELESS_MODE_DEFAULT",
      "applyWirelessMode2ghz": false,
      "wirelessMode5ghz": "WIRELESS_MODE_DEFAULT",
      "applyWirelessMode5ghz": false,
      "wirelessMode5ghzHigh": "WIRELESS_MODE_DEFAULT",
      "applyWirelessMode5ghzHigh": false,
      "htBandwidth2ghz": "HT_BANDWIDTH_DEFAULT",
      "applyHtBandwidth2ghz": false,
      "htBandwidth5ghz": "HT_BANDWIDTH_DEFAULT",
      "applyHtBandwidth5ghz": false,
      "htBandwidth5ghzHigh": "HT_BANDWIDTH_DEFAULT",
      "applyHtBandwidth5ghzHigh": false,
      "vhtBandwidth": "VHT_BANDWIDTH_DEFAULT",
      "applyVhtBandwidth": false,
      "vhtBandwidth5ghzHigh": "VHT_BANDWIDTH_DEFAULT",
      "applyVhtBandwidth5ghzHigh": false,
      "usePublicServices": false,
      "applyUsePublicServices": false,
      "disableAutomatedSpeedtests": false,
      "applyDisableAutomatedSpeedtests": false,
      "enableUmbilicalVlan": false,
      "applyEnableUmbilicalVlan": false,
      "applyClientNames": false,
      "outdoorMode": false,
      "applyOutdoorMode": false,
      "disable2ghz": false,
      "applyDisable2ghz": false,
      "disable5ghz": false,
      "applyDisable5ghz": false,
      "disable5ghzHigh": false,
      "applyDisable5ghzHigh": false,
      "disableXMeshBackhaul": false,
      "applyDisableXMeshBackhaul": false,
      "goldenBssid": "",
      "applyGoldenBssid": false,
      "goldenIfaceType": "IFACE_TYPE_UNKNOWN",
      "applyGoldenIfaceType": false,
      "txPowerLevel2ghz": "TX_POWER_LEVEL_100",
      "applyTxPowerLevel2ghz": false,
      "txPowerLevel5ghz": "TX_POWER_LEVEL_100",
      "applyTxPowerLevel5ghz": false,
      "txPowerLevel5ghzHigh": "TX_POWER_LEVEL_100",
      "applyTxPowerLevel5ghzHigh": false,
      "disablePendingUpdateReboot": false,
      "applyDisablePendingUpdateReboot": false,
      "applyClientConfigs": false,
      "disableSetWifiConfigFromController": false,
      "applyDisableSetWifiConfigFromController": false,
      "clientKey": "",
      "applyClientKey": false,
      "wanAckSuppression": {
        "ackMark": 0,
        "htbAckQueueRate": 0,
        "htbAckQueueCeil": 0,
        "cakeQueueBandwidth": 0,
        "cakeAckFilterAggressive": false,
        "cakeManualRtt": 0
      },
      "applyWanTrafficControl": false,
      "wanHostDscpMark": 0,
      "applyWanHostDscpMark": false,
      "tag": 0
    }
  }
}
```
[[wifi.WifiSetConfigRequest]]


## 응답정보
- PermissionDenied (7)
- Permission denied
[[wifi.WifiSetConfigResponse]]


