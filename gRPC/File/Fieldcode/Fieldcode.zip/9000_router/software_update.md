Field_code: 1033
hex_data: 0000000003ca4000

## 형식
![[Pasted image 20241012194237.png]]
[[SpaceX.API.Device.SoftwareUpdateRequest]]



## 요청정보
- 데이터 없을때
```
{
  "softwareUpdate": {}
}
```

- 데이터 있을때
```
{
  "softwareUpdate": {
    "streamId": "0",
    "data": "",
    "open": false,
    "close": false
  }
}
```
[[common.SoftwareUpdateRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_SelfTest
[[common.SoftwareUpdateRespons]]


