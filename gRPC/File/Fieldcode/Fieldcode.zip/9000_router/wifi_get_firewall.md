Field_code: 3024
hex_data: 000000000482bd0100

## 형식
![[Pasted image 20241013140836.png]]
[[SpaceX.API.Device.WifiGetFirewallRequest]]



## 요청정보
- 데이터 없을때
```
{
  "wifiGetFirewall": {}
}
```
[[wifi.WifiGetFirewallRequest]]



## 응답정보
- PermissionDenied (7)
- Permission denied
[[wifi.WifiGetFirewallResponse]]


