Field_code: 1020
hex_data: 0000000003e23f00

## 형식
![[Pasted image 20241012190831.png]]
[[SpaceX.API.Device.RestartControlRequest]]



## 요청정보
- 데이터 없을때
```
{
  "restartControl": {}
}
```
[[device.RestartControlRequest]]



## 응답정보
- PermissionDenied (7)
- Permission denied
[[device.RestartControlResponse]]


