Field_code: 1030
hex_data: 0000000003b24000

## 형식
![[Pasted image 20241012193244.png]]
[[SpaceX.API.Device.InitiateRemoteSshRequest]]



## 요청정보
- 데이터 없을때
```
{
  "initiateRemoteSsh": {}
}
```
[[common.InitiateRemoteSshRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_InitiateRemoteSsh
[[common.InitiateRemoteSshResponse]]



