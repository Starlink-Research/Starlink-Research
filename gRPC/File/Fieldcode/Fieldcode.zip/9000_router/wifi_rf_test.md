Field_code: 3021
hex_data: 0000000004eabc0100

## 형식
![[Pasted image 20241013140729.png]]
[[SpaceX.API.Device.WifiRfTestRequest]]



## 요청정보
- 데이터 없을때
```
{
  "wifiRfTest": {}
}
```

- 데이터 있을때
```
{
  "wifiRfTest": {
    "channel2ghz": 0,
    "numMeasurements": 0,
    "channel5ghz": 0,
    "channel5ghzHigh": 0,
    "mcs5ghz": 0,
    "mcs2ghz": 0,
    "mcs5ghzHigh": 0,
    "phyMode2ghz": 0,
    "phyMode5ghz": 0,
    "phyMode5ghzHigh": 0
  }
}
```
[[wifi.WifiRfTestRequest]]


## 응답정보
- PermissionDenied (7)
- Permission denied
[[wifi.WifiRfTestResponse]]

