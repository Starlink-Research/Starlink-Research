Field_code: 15
hex_data: 00000000027a00

## 형식
![[Pasted image 20241012152807.png]]
[[SpaceX.API.Device.SignedData]]



## 요청정보
- 데이터 없을때
```
{
  "signedRequest": {}
}
```

- 데이터 있을때
	- data: 
	- signature: 
```
{
  "signedRequest": {
    "data": "",
    "signature": ""
  }
}
```
[[common.SignedData]]



## 응답정보
- PermissionDenied (7)
- Unable to verify signature 