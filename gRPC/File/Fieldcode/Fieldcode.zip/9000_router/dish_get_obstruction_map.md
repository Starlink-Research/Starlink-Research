Field_code: 2008
hex_data: 0000000003c27d00

## 형식
![[Pasted image 20241012205802.png]]
[[SpaceX.API.Device.DishGetObstructionMapRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishGetObstructionMap": {}
}
```
[[dish.DishGetObstructionMapRequest]]


## 응답정보
-  Unimplemented (12)
- Unimplemented: *device.Request_StartDishSelfTest
[[dish.DishGetObstructionMapResponse]]

