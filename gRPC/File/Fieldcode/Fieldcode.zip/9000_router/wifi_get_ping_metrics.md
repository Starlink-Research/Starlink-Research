Field_code: 3007
hex_data: 0000000004fabb0100

## 형식
![[Pasted image 20241012213433.png]]
[[SpaceX.API.Device.WifiGetPingMetricsRequest]]



## 요청정보
- 데이터 없을때ㅎㅎ
```
{
  "wifiGetPingMetrics": {}
}
```
[[wifi.WifiGetPingMetricsRequest]]


## 응답정보
- PermissionDenied (7)
- Permission denied
[[wifi.WifiGetPingMetricsResponse]]

