Field_code: 3009
hex_data: 00000000048abc0100

## 형식
![[Pasted image 20241012215554.png]]
[[SpaceX.API.Device.WifiGetConfigRequest]]



## 요청정보
- 데이터 없을때
```
{
  "wifiGetConfig": {}
}
```
[[wifi.WifiGetConfigRequest]]


## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "61",
  "wifi_get_config": {
    "wifi_config": {
      "country_code": "",
      "setup_complete": true,
      "version": 0,
      "mac_wan": "74:24:9f:4e:f4:8f",
      "mac_lan": "74:24:9f:5e:f4:8f",
      "channel_2ghz": 0,
      "channel_5ghz": 0,
      "dynamic_keys": [],
      "is_repeater": false,
      "boot_count": 74,
      "nameservers": [],
      "bypass_mode": false,
      "mesh_configs": {
        "Router-010000000000000000F5951C": {
          "display_name": "Mesh 1",
          "apply_display_name": false,
          "auth": "MESH_AUTH_NEW",
          "apply_auth": false,
          "last_connected": "0",
          "incarnation": "12261697686743714150",
          "hardware_version": "v3",
          "supports_5ghz_high": true
        }
      },
      "apply_dynamic_keys": false,
      "dfs_enabled": false,
      "incarnation": "1819507386833945120",
      "wireless_mode_2ghz": "WIRELESS_MODE_DEFAULT",
      "wireless_mode_5ghz": "WIRELESS_MODE_DEFAULT",
      "ht_bandwidth_2ghz": "HT_BANDWIDTH_DEFAULT",
      "ht_bandwidth_5ghz": "HT_BANDWIDTH_DEFAULT",
      "vht_bandwidth": "VHT_BANDWIDTH_DEFAULT",
      "is_aviation": false,
      "secure_dns": false,
      "ap_mode": false,
      "disable_mesh_onboarding": false,
      "pin_country_code": false,
      "custom_power_table": false,
      "use_public_services": false,
      "disable_automated_speedtests": false,
      "channel_5ghz_high": 0,
      "wireless_mode_5ghz_high": "WIRELESS_MODE_DEFAULT",
      "ht_bandwidth_5ghz_high": "HT_BANDWIDTH_DEFAULT",
      "vht_bandwidth_5ghz_high": "VHT_BANDWIDTH_DEFAULT",
      "enable_umbilical_vlan": false,
      "client_names": [],
      "outdoor_mode": false,
      "disable_2ghz": false,
      "disable_5ghz": false,
      "disable_5ghz_high": false,
      "disable_x_mesh_backhaul": false,
      "golden_bssid": "",
      "golden_iface_type": "IFACE_TYPE_UNKNOWN",
      "tx_power_level_2ghz": "TX_POWER_LEVEL_100",
      "tx_power_level_5ghz": "TX_POWER_LEVEL_100",
      "tx_power_level_5ghz_high": "TX_POWER_LEVEL_100",
      "disable_pending_update_reboot": false,
      "client_configs": [],
      "disable_set_wifi_config_from_controller": false,
      "client_key": "",
      "wan_host_dscp_mark": 1,
      "tag": 0,
      "apply_setup_complete": false,
      "apply_channel_2ghz": false,
      "apply_channel_5ghz": false,
      "apply_channel_5ghz_high": false,
      "apply_is_repeater": false,
      "apply_mesh_configs": false,
      "apply_nameservers": false,
      "apply_bypass_mode": false,
      "apply_dfs_enabled": false,
      "apply_wireless_mode_2ghz": false,
      "apply_wireless_mode_5ghz": false,
      "apply_ht_bandwidth_2ghz": false,
      "apply_ht_bandwidth_5ghz": false,
      "apply_vht_bandwidth": false,
      "apply_is_aviation": false,
      "apply_secure_dns": false,
      "apply_ap_mode": false,
      "apply_disable_mesh_onboarding": false,
      "apply_use_public_services": false,
      "apply_disable_automated_speedtests": false,
      "apply_wireless_mode_5ghz_high": false,
      "apply_ht_bandwidth_5ghz_high": false,
      "apply_vht_bandwidth_5ghz_high": false,
      "apply_enable_umbilical_vlan": false,
      "apply_client_names": false,
      "apply_outdoor_mode": false,
      "apply_disable_2ghz": false,
      "apply_disable_5ghz": false,
      "apply_disable_5ghz_high": false,
      "apply_disable_x_mesh_backhaul": false,
      "apply_golden_bssid": false,
      "apply_golden_iface_type": false,
      "apply_tx_power_level_2ghz": false,
      "apply_tx_power_level_5ghz": false,
      "apply_tx_power_level_5ghz_high": false,
      "apply_country_code": false,
      "apply_pin_country_code": false,
      "apply_custom_power_table": false,
      "apply_disable_pending_update_reboot": false,
      "apply_client_configs": false,
      "apply_disable_set_wifi_config_from_controller": false,
      "apply_client_key": false,
      "apply_wan_traffic_control": false,
      "apply_wan_host_dscp_mark": false,
      "networks": [
        {
          "ipv4": "192.168.1.1/24",
          "basic_service_sets": [
            {
              "bssid": "32:54:02:2f:c2:20",
              "ssid": "별가디언",
              "band": "RF_2GHZ",
              "disable": false,
              "hidden": false,
              "iface_name": "ra0",
              "auth_wpa2": {
                "password": "••••••••"
              }
            },
            {
              "bssid": "32:54:02:3f:c2:20",
              "ssid": "별가디언",
              "band": "RF_5GHZ",
              "disable": false,
              "hidden": false,
              "iface_name": "rax0",
              "auth_wpa2": {
                "password": "••••••••"
              }
            },
            {
              "bssid": "32:54:02:4f:c2:20",
              "ssid": "별가디언",
              "band": "RF_5GHZ_HIGH",
              "disable": false,
              "hidden": false,
              "iface_name": "rai0",
              "auth_wpa2": {
                "password": "••••••••"
              }
            }
          ],
          "client_isolation": false,
          "guest": false,
          "landing": "",
          "domain": "lan",
          "dhcpv4_start": 20,
          "internal": false,
          "vlan": 100,
          "dhcp_disabled": false,
          "dhcpv4_lease_duration_s": 3600,
          "landing_page_v2": false
        }
      ],
      "apply_networks": false,
      "boot": {
        "count_by_reason": {
          "0": 28,
          "1": 39,
          "2": 0,
          "3": 6,
          "5": 1
        },
        "last_reason": "COMMAND",
        "last_count": 74,
        "count_by_reason_delta": {
          "0": 23,
          "2": 0,
          "3": 6
        },
        "crash_boot": false,
        "crash_boot_count": 0
      },
      "mesh_configs_updates": {},
      "wan_ack_suppression": {
        "ack_mark": 1056,
        "htb_ack_queue_rate": 2,
        "htb_ack_queue_ceil": 2.5,
        "cake_queue_bandwidth": 1.75,
        "cake_ack_filter_aggressive": true,
        "cake_manual_rtt": 0
      }
    }
  }
}
```
[[wifi.WifiGetConfigResponse]]

