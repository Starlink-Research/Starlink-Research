Field_code: 3019
hex_data: 0000000004dabc0100

## 형식
![[Pasted image 20241013140546.png]]
[[SpaceX.API.Device.WifiCalibrationModeRequest]]



## 요청정보
- 데이터 없을때
```
{
  "wifiCalibrationMode": {}
}
```
[[wifi.WifiCalibrationModeRequest]]



## 응답정보
- PermissionDenied (7)
- Permission denied


