Field_code: 1017
hex_data: 0000000003ca3f00

## 형식
![[Pasted image 20241012185752.png]]
[[SpaceX.API.Device.GetLocationRequest]]



## 요청정보
- 데이터 없을때
```
{
  "getLocation": {}
}
```

- 데이터 있을때
```
{
  "getLocation": {
    "source": "STARLINK"
  }
}
```
[[device.GetLocationRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_GetLocation
[[device.GetLocationResponse]]


