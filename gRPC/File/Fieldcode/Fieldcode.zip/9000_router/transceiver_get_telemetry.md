Field_code: 4004
hex_data: 0000000004a2fa0100

## 형식
![[Pasted image 20241013141713.png]]
[[SpaceX.API.Device.TransceiverGetTelemetryRequest]]


## 요청정보
- 데이터 없을때
```
{
  "transceiverGetTelemetry": {}
}
```
[[transceiver.TransceiverGetTelemetryRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_TransceiverGetTelemetry
[[transceiver.TransceiverGetTelemetryResponse]]



