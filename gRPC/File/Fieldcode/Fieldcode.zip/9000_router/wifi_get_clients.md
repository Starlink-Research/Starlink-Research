Field_code: 3002
hex_data: 0000000004d2bb0100

## 형식
![[Pasted image 20241012213135.png]]
[[SpaceX.API.Device.WifiGetClientsRequest]]



## 요청정보
- 데이터 없을때
```
{
  "wifiGetClients": {}
}
```
[[wifi.WifiGetClientsRequest]]


## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "61",
  "wifi_get_clients": {
    "clients": [
      {
        "name": "Controller",
        "mac_address": "74:24:9f:5e:f4:8f",
        "ip_address": "",
        "signal_strength": 0,
        "rx_stats": null,
        "tx_stats": null,
        "associated_time_s": 0,
        "mode_str": "",
        "iface": "ETH",
        "snr": 0,
        "psmode": 0,
        "channel_width": 0,
        "upstream_mac_address": "",
        "role": "CONTROLLER",
        "device_id": "Router-010000000000000000CEF48F",
        "swq_checks": 0,
        "swq_checks_non_empty": 0,
        "mib_steer_state": 0,
        "mib_steer_method": 0,
        "btm_requests": 0,
        "btm_requests_success": 0,
        "domain": "",
        "dot11v_support": false,
        "iface_name": "",
        "steer_req_success_last_1h": 0,
        "steer_req_fail_last_1h": 0,
        "steer_req_fail_and_dissoc_last_1h": 0,
        "steer_state": 0,
        "given_name": "",
        "hops_from_controller": 0,
        "est_tx_rate_mbps_from_controller": 0,
        "est_rx_rate_mbps_from_controller": 0,
        "hardware_version": "",
        "software_version": "",
        "api_version": 0,
        "ping_metrics": null,
        "ipv6_addresses": [],
        "blocked": false,
        "client_id": 0,
        "fqcodel_info": null
      },
      {
        "name": "syul",
        "mac_address": "2c:7b:a0:XX:XX:XX",
        "ip_address": "192.168.1.21",
        "signal_strength": -43,
        "rx_stats": {
          "bytes": "13942855",
          "count_errors": "0",
          "nss": 2,
          "mcs": 11,
          "bandwidth": 80,
          "guard_ns": 800,
          "rate_mbps": 1201,
          "airtime_fraction_last_1s": 0,
          "sampled_packets": 0,
          "sampled_packets_retried": 0,
          "sampled_packets_dropped": 0,
          "phy_mode": 8,
          "rate_mbps_last_30s": 1189.7667,
          "rate_mbps_last_15s": 1201
        },
        "tx_stats": {
          "bytes": "10927638",
          "success_bytes": "0",
          "nss": 1,
          "mcs": 4,
          "bandwidth": 80,
          "guard_ns": 800,
          "rate_mbps": 216,
          "airtime_fraction_last_1s": 0,
          "phy_mode": 8,
          "rate_mbps_last_30s": 281.66666,
          "rate_mbps_last_15s": 216
        },
        "associated_time_s": 6312,
        "mode_str": "",
        "iface": "RF_5GHZ",
        "snr": 45,
        "psmode": 0,
        "channel_width": 80,
        "upstream_mac_address": "74:24:9f:5e:f4:8f",
        "role": "CLIENT",
        "device_id": "",
        "swq_checks": 0,
        "swq_checks_non_empty": 0,
        "mib_steer_state": 0,
        "mib_steer_method": 0,
        "btm_requests": 0,
        "btm_requests_success": 0,
        "domain": "lan",
        "dot11v_support": true,
        "iface_name": "rax0",
        "steer_req_success_last_1h": 0,
        "steer_req_fail_last_1h": 0,
        "steer_req_fail_and_dissoc_last_1h": 0,
        "steer_state": 0,
        "given_name": "",
        "hops_from_controller": 1,
        "est_tx_rate_mbps_from_controller": 741.88983,
        "est_rx_rate_mbps_from_controller": 741.88983,
        "hardware_version": "",
        "software_version": "",
        "api_version": 0,
        "ping_metrics": null,
        "ipv6_addresses": [
          "fd54:26f:c220:10:b1d1:5973:4c6b:d5e3",
          "fe80::cc00:a287:2513:2ca5"
        ],
        "blocked": false,
        "client_id": 1868513240,
        "fqcodel_info": null
      }
    ],
    "has_client_index": true,
    "client_index": 1
  }
}
```
[[wifi.WifiGetClientsResponse]]

