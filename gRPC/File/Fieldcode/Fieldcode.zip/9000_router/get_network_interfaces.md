Field_code: 1015
hex_data: 0000000003ba3f00

## 형식
![[Pasted image 20241012164136.png]]
[[SpaceX.API.Device.GetNetworkInterfacesRequest]]



## 요청정보
- 데이터 없을때
```
{
  "getNetworkInterfaces": {}
}
```
[[device.GetNetworkInterfacesRequest]]



## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "61",
  "get_network_interfaces": {
    "network_interfaces": [
      {
        "name": "lan0",
        "rx_stats": {
          "bytes": "0",
          "packets": "0",
          "frame_errors": "0"
        },
        "tx_stats": {
          "bytes": "0",
          "packets": "0"
        },
        "up": true,
        "mac_address": "74:24:9f:5e:f4:8f",
        "ipv4_addresses": [],
        "ipv6_addresses": [],
        "ethernet": {
          "link_detected": false,
          "speed_mbps": 0,
          "autonegotiation_on": true,
          "duplex": "UNKNOWN"
        }
      },
      {
        "name": "lan1",
        "rx_stats": {
          "bytes": "0",
          "packets": "0",
          "frame_errors": "0"
        },
        "tx_stats": {
          "bytes": "0",
          "packets": "0"
        },
        "up": true,
        "mac_address": "74:24:9f:5f:f4:8f",
        "ipv4_addresses": [],
        "ipv6_addresses": [],
        "ethernet": {
          "link_detected": false,
          "speed_mbps": 0,
          "autonegotiation_on": true,
          "duplex": "UNKNOWN"
        }
      },
      {
        "name": "wan0",
        "rx_stats": {
          "bytes": "13566234",
          "packets": "143388",
          "frame_errors": "0"
        },
        "tx_stats": {
          "bytes": "17175673",
          "packets": "176195"
        },
        "up": true,
        "mac_address": "74:24:9f:4e:f4:8f",
        "ipv4_addresses": [],
        "ipv6_addresses": [
          "fe80::7624:9fff:fe4e:f48f/64"
        ],
        "ethernet": {
          "link_detected": false,
          "speed_mbps": 0,
          "autonegotiation_on": true,
          "duplex": "UNKNOWN"
        }
      },
      {
        "name": "ra0",
        "rx_stats": {
          "bytes": "0",
          "packets": "0",
          "frame_errors": "0"
        },
        "tx_stats": {
          "bytes": "0",
          "packets": "0"
        },
        "up": true,
        "mac_address": "32:54:02:2f:c2:20",
        "ipv4_addresses": [],
        "ipv6_addresses": [],
        "wifi": {
          "invalid_packet_counts": {
            "rx_invalid_nwid": 0,
            "rx_invalid_crypt": 0,
            "rx_invalid_frag": 0,
            "tx_excessive_retries": 0,
            "invalid_misc": 0
          },
          "channel": 6,
          "link_quality": 10,
          "signal_level": 0,
          "noise_level": 209,
          "missed_beacons": 0
        }
      },
      {
        "name": "ra1",
        "rx_stats": {
          "bytes": "0",
          "packets": "0",
          "frame_errors": "0"
        },
        "tx_stats": {
          "bytes": "0",
          "packets": "0"
        },
        "up": true,
        "mac_address": "32:54:02:5f:c2:20",
        "ipv4_addresses": [],
        "ipv6_addresses": [
          "fe80::3054:2ff:fe5f:c220/64"
        ],
        "wifi": {
          "invalid_packet_counts": {
            "rx_invalid_nwid": 0,
            "rx_invalid_crypt": 0,
            "rx_invalid_frag": 0,
            "tx_excessive_retries": 0,
            "invalid_misc": 0
          },
          "channel": 6,
          "link_quality": 10,
          "signal_level": 0,
          "noise_level": 209,
          "missed_beacons": 0
        }
      },
      {
        "name": "ra2",
        "rx_stats": {
          "bytes": "686008",
          "packets": "2562",
          "frame_errors": "0"
        },
        "tx_stats": {
          "bytes": "149867",
          "packets": "1814"
        },
        "up": true,
        "mac_address": "32:54:02:8f:c2:20",
        "ipv4_addresses": [],
        "ipv6_addresses": [],
        "wifi": {
          "invalid_packet_counts": {
            "rx_invalid_nwid": 0,
            "rx_invalid_crypt": 0,
            "rx_invalid_frag": 0,
            "tx_excessive_retries": 0,
            "invalid_misc": 0
          },
          "channel": 6,
          "link_quality": 10,
          "signal_level": 0,
          "noise_level": 209,
          "missed_beacons": 0
        }
      },
      {
        "name": "apcli0",
        "rx_stats": {
          "bytes": "0",
          "packets": "0",
          "frame_errors": "0"
        },
        "tx_stats": {
          "bytes": "0",
          "packets": "0"
        },
        "up": true,
        "mac_address": "36:54:02:2f:c2:20",
        "ipv4_addresses": [],
        "ipv6_addresses": [],
        "wifi": {
          "invalid_packet_counts": {
            "rx_invalid_nwid": 0,
            "rx_invalid_crypt": 0,
            "rx_invalid_frag": 0,
            "tx_excessive_retries": 0,
            "invalid_misc": 0
          },
          "channel": 6,
          "link_quality": 10,
          "signal_level": 0,
          "noise_level": 209,
          "missed_beacons": 0
        }
      },
      {
        "name": "rax0",
        "rx_stats": {
          "bytes": "15795905",
          "packets": "196888",
          "frame_errors": "0"
        },
        "tx_stats": {
          "bytes": "21407016",
          "packets": "275846"
        },
        "up": true,
        "mac_address": "32:54:02:3f:c2:20",
        "ipv4_addresses": [],
        "ipv6_addresses": [],
        "wifi": {
          "invalid_packet_counts": {
            "rx_invalid_nwid": 0,
            "rx_invalid_crypt": 0,
            "rx_invalid_frag": 0,
            "tx_excessive_retries": 0,
            "invalid_misc": 0
          },
          "channel": 36,
          "link_quality": 10,
          "signal_level": 0,
          "noise_level": 209,
          "missed_beacons": 0
        }
      },
      {
        "name": "rax1",
        "rx_stats": {
          "bytes": "0",
          "packets": "0",
          "frame_errors": "0"
        },
        "tx_stats": {
          "bytes": "0",
          "packets": "0"
        },
        "up": true,
        "mac_address": "32:54:02:6f:c2:20",
        "ipv4_addresses": [],
        "ipv6_addresses": [
          "fe80::3054:2ff:fe6f:c220/64"
        ],
        "wifi": {
          "invalid_packet_counts": {
            "rx_invalid_nwid": 0,
            "rx_invalid_crypt": 0,
            "rx_invalid_frag": 0,
            "tx_excessive_retries": 0,
            "invalid_misc": 0
          },
          "channel": 36,
          "link_quality": 10,
          "signal_level": 0,
          "noise_level": 209,
          "missed_beacons": 0
        }
      },
      {
        "name": "apclix0",
        "rx_stats": {
          "bytes": "0",
          "packets": "0",
          "frame_errors": "0"
        },
        "tx_stats": {
          "bytes": "0",
          "packets": "0"
        },
        "up": true,
        "mac_address": "3a:54:02:2f:c2:20",
        "ipv4_addresses": [],
        "ipv6_addresses": [],
        "wifi": {
          "invalid_packet_counts": {
            "rx_invalid_nwid": 0,
            "rx_invalid_crypt": 0,
            "rx_invalid_frag": 0,
            "tx_excessive_retries": 0,
            "invalid_misc": 0
          },
          "channel": 36,
          "link_quality": 10,
          "signal_level": 0,
          "noise_level": 209,
          "missed_beacons": 0
        }
      },
      {
        "name": "rai0",
        "rx_stats": {
          "bytes": "0",
          "packets": "0",
          "frame_errors": "0"
        },
        "tx_stats": {
          "bytes": "0",
          "packets": "0"
        },
        "up": false,
        "mac_address": "",
        "ipv4_addresses": [],
        "ipv6_addresses": [],
        "wifi": {
          "invalid_packet_counts": {
            "rx_invalid_nwid": 0,
            "rx_invalid_crypt": 0,
            "rx_invalid_frag": 0,
            "tx_excessive_retries": 0,
            "invalid_misc": 0
          },
          "channel": 0,
          "link_quality": 0,
          "signal_level": 0,
          "noise_level": 0,
          "missed_beacons": 0
        }
      },
      {
        "name": "br-backhaul",
        "rx_stats": {
          "bytes": "0",
          "packets": "0",
          "frame_errors": "0"
        },
        "tx_stats": {
          "bytes": "14546",
          "packets": "103"
        },
        "up": true,
        "mac_address": "74:24:9f:5e:f4:8f",
        "ipv4_addresses": [
          "192.168.2.1/24"
        ],
        "ipv6_addresses": [
          "fd54:26f:c220::1/60",
          "fe80::7624:9fff:fe5e:f48f/64"
        ],
        "bridge": {
          "member_names": [
            "lan0.200",
            "lan1.200",
            "ra1.200",
            "rax1.200"
          ]
        }
      },
      {
        "name": "br-hiddenlan",
        "rx_stats": {
          "bytes": "323818",
          "packets": "1255",
          "frame_errors": "0"
        },
        "tx_stats": {
          "bytes": "53024",
          "packets": "636"
        },
        "up": true,
        "mac_address": "74:24:9f:5e:f4:8f",
        "ipv4_addresses": [
          "192.168.254.1/24"
        ],
        "ipv6_addresses": [],
        "bridge": {
          "member_names": [
            "apcli0",
            "apclix0",
            "lan0.420",
            "ra1.420",
            "ra2",
            "rax1.420"
          ]
        }
      },
      {
        "name": "br-lan",
        "rx_stats": {
          "bytes": "6520553",
          "packets": "93799",
          "frame_errors": "0"
        },
        "tx_stats": {
          "bytes": "7043933",
          "packets": "91685"
        },
        "up": true,
        "mac_address": "74:24:9f:5e:f4:8f",
        "ipv4_addresses": [
          "192.168.1.1/24"
        ],
        "ipv6_addresses": [
          "fd54:26f:c220:10::1/60",
          "fe80::7624:9fff:fe5e:f48f/64"
        ],
        "bridge": {
          "member_names": [
            "lan0",
            "lan1",
            "ra0",
            "ra1.100",
            "rax0",
            "rax1.100"
          ]
        }
      }
    ]
  }
}
```
[[device.GetNetworkInterfacesResponse]]


