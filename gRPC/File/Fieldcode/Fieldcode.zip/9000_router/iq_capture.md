Field_code: 1035
hex_data: 0000000003da4000

## 형식
![[Pasted image 20241012194654.png]]
[[SpaceX.API.Device.IQCaptureRequest]]



## 요청정보
- 데이터 없을때
```
{
  "iqCapture": {}
}
```
[[device.IQCaptureRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_InitiateRemoteSsh




