Field_code: 1078
hex_data: 0000000003b24300

## 형식
![[Pasted image 20241012155436.png]]
[[SpaceX.API.Device.SignedData]]



## 요청정보
- 데이터 없을때
```
{
  "sensitiveRequest": {}
}
```

- 데이터 있을때
```
{
  "sensitiveRequest": {
    "data": "",
    "signature": ""
  }
}
```
[[common.SignedData]]

## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_SensitiveRequest