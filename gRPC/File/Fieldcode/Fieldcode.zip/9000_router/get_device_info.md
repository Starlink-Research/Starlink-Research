Field_code: 1008
hex_data: 0000000003823f00

## 형식
![[Pasted image 20241012162033.png]]
[[SpaceX.API.Device.GetDeviceInfoRequest]]



## 요청정보
- 데이터 없을때
```
{
  "getDeviceInfo": {}
}
```
[[device.GetDeviceInfoRequest]]



## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "61",
  "get_device_info": {
    "device_info": {
      "id": "Router-010000000000000000CEF48F",
      "hardware_version": "v3",
      "software_version": "2024.20.0.mr34287",
      "country_code": "",
      "utc_offset_s": 0,
      "software_partitions_equal": true,
      "is_dev": false,
      "bootcount": 73,
      "anti_rollback_version": 1,
      "is_hitl": false,
      "manufactured_version": "2024.20.0.mr34287",
      "generation_number": "0",
      "dish_cohoused": false,
      "board_rev": 8,
      "boot": {
        "count_by_reason": {
          "0": 28,
          "1": 39,
          "2": 0,
          "3": 5,
          "5": 1
        },
        "last_reason": "POWER_CYCLE",
        "last_count": 73,
        "count_by_reason_delta": {
          "0": 23,
          "2": 0,
          "3": 5
        },
        "crash_boot": false,
        "crash_boot_count": 0
      }
    }
  }
}
```
[[device.GetDeviceInfoResponse]]


