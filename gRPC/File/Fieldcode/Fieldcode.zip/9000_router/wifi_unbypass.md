Field_code: 3022
hex_data: 0000000004f2bc0100

## 형식
![[Pasted image 20241013141529.png]]
[[SpaceX.API.Device.WifiUnbypassRequest]]


## 요청정보
- 데이터 없을때
```
{
  "wifiStartLocalTelemProxy": {}
}
```
[[device.WifiUnbypassRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_WifiUnbypass
[[device.WifiUnbypassResponse]]


