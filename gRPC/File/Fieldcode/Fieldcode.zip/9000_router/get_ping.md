Field_code: 1009
hex_data: 00000000038a3f00

## 형식
![[Pasted image 20241012164509.png]]
[[SpaceX.API.Device.GetPingRequest]]



## 요청정보
- 데이터 없을때
```
{
  "getPing": {}
}
```
[[device.GetPingRequest]]



## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "61",
  "get_ping": {
    "results": {
      "103.10.124.1": {
        "dropRate": 1,
        "latencyMs": 0,
        "target": {
          "service": "Counter-Strike: GO",
          "location": "Singapore",
          "address": "103.10.124.1"
        }
      },
      "103.10.125.1": {
        "dropRate": 1,
        "latencyMs": 0,
        "target": {
          "service": "Counter-Strike: GO",
          "location": "Sydney",
          "address": "103.10.125.1"
        }
      },
      "104.160.131.3": {
        "dropRate": 1,
        "latencyMs": 0,
        "target": {
          "service": "League of Legends",
          "location": "Chicago",
          "address": "104.160.131.3"
        }
      },
      "104.160.136.3": {
        "dropRate": 1,
        "latencyMs": 0,
        "target": {
          "service": "League of Legends",
          "location": "Los Angeles",
          "address": "104.160.136.3"
        }
      },
      "104.160.141.3": {
        "dropRate": 1,
        "latencyMs": 0,
        "target": {
          "service": "League of Legends",
          "location": "Amsterdam",
          "address": "104.160.141.3"
        }
      },
      "104.160.142.3": {
        "dropRate": 1,
        "latencyMs": 0,
        "target": {
          "service": "League of Legends",
          "location": "Frankfurt",
          "address": "104.160.142.3"
        }
      },
      "104.160.156.1": {
        "dropRate": 1,
        "latencyMs": 0,
        "target": {
          "service": "League of Legends",
          "location": "Sydney",
          "address": "104.160.156.1"
        }
      },
      "146.66.152.1": {
        "dropRate": 1,
        "latencyMs": 0,
        "target": {
          "service": "Counter-Strike: GO",
          "location": "Luxemborg",
          "address": "146.66.152.1"
        }
      },
      "146.66.155.1": {
        "dropRate": 1,
        "latencyMs": 0,
        "target": {
          "service": "Counter-Strike: GO",
          "location": "Vienna",
          "address": "146.66.155.1"
        }
      },
      "146.66.156.1": {
        "dropRate": 1,
        "latencyMs": 0,
        "target": {
          "service": "Counter-Strike: GO",
          "location": "Stockholm",
          "address": "146.66.156.1"
        }
      },
      "185.25.183.1": {
        "dropRate": 1,
        "latencyMs": 0,
        "target": {
          "service": "Counter-Strike: GO",
          "location": "Dubai",
          "address": "185.25.183.1"
        }
      },
      "192.168.100.1": {
        "dropRate": 0,
        "latencyMs": 6,
        "target": {
          "service": "Your Starlink",
          "location": "",
          "address": "192.168.100.1"
        }
      },
      "192.69.96.1": {
        "dropRate": 1,
        "latencyMs": 0,
        "target": {
          "service": "Counter-Strike: GO",
          "location": "Seattle",
          "address": "192.69.96.1"
        }
      },
      "197.80.200.1": {
        "dropRate": 1,
        "latencyMs": 0,
        "target": {
          "service": "Counter-Strike: GO",
          "location": "Johannesburg",
          "address": "197.80.200.1"
        }
      },
      "208.78.164.1": {
        "dropRate": 1,
        "latencyMs": 0,
        "target": {
          "service": "Counter-Strike: GO",
          "location": "Virginia",
          "address": "208.78.164.1"
        }
      },
      "209.197.29.1": {
        "dropRate": 1,
        "latencyMs": 0,
        "target": {
          "service": "Counter-Strike: GO",
          "location": "São Paulo",
          "address": "209.197.29.1"
        }
      },
      "dynamodb.ap-east-1.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "Hong Kong",
          "address": "dynamodb.ap-east-1.amazonaws.com"
        }
      },
      "dynamodb.ap-northeast-1.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "Tokyo",
          "address": "dynamodb.ap-northeast-1.amazonaws.com"
        }
      },
      "dynamodb.ap-northeast-2.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "Seoul",
          "address": "dynamodb.ap-northeast-2.amazonaws.com"
        }
      },
      "dynamodb.ap-northeast-3.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "Osaka",
          "address": "dynamodb.ap-northeast-3.amazonaws.com"
        }
      },
      "dynamodb.ap-south-1.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "Mumbai",
          "address": "dynamodb.ap-south-1.amazonaws.com"
        }
      },
      "dynamodb.ap-southeast-1.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "Singapore",
          "address": "dynamodb.ap-southeast-1.amazonaws.com"
        }
      },
      "dynamodb.ap-southeast-2.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "Sydney",
          "address": "dynamodb.ap-southeast-2.amazonaws.com"
        }
      },
      "dynamodb.ca-central-1.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "Montreal",
          "address": "dynamodb.ca-central-1.amazonaws.com"
        }
      },
      "dynamodb.cn-north-1.amazonaws.com.cn": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "Beijing",
          "address": "dynamodb.cn-north-1.amazonaws.com.cn"
        }
      },
      "dynamodb.cn-northwest-1.amazonaws.com.cn": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "Ningxia",
          "address": "dynamodb.cn-northwest-1.amazonaws.com.cn"
        }
      },
      "dynamodb.eu-central-1.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "Frankfurt",
          "address": "dynamodb.eu-central-1.amazonaws.com"
        }
      },
      "dynamodb.eu-north-1.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "Stockholm",
          "address": "dynamodb.eu-north-1.amazonaws.com"
        }
      },
      "dynamodb.eu-west-1.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "Ireland",
          "address": "dynamodb.eu-west-1.amazonaws.com"
        }
      },
      "dynamodb.eu-west-2.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "London",
          "address": "dynamodb.eu-west-2.amazonaws.com"
        }
      },
      "dynamodb.eu-west-3.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "Paris",
          "address": "dynamodb.eu-west-3.amazonaws.com"
        }
      },
      "dynamodb.me-south-1.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "Bahrain",
          "address": "dynamodb.me-south-1.amazonaws.com"
        }
      },
      "dynamodb.sa-east-1.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "São Paulo",
          "address": "dynamodb.sa-east-1.amazonaws.com"
        }
      },
      "dynamodb.us-east-1.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "Virginia",
          "address": "dynamodb.us-east-1.amazonaws.com"
        }
      },
      "dynamodb.us-east-2.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "Ohio",
          "address": "dynamodb.us-east-2.amazonaws.com"
        }
      },
      "dynamodb.us-west-1.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "California",
          "address": "dynamodb.us-west-1.amazonaws.com"
        }
      },
      "dynamodb.us-west-2.amazonaws.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Fortnite",
          "location": "Oregon",
          "address": "dynamodb.us-west-2.amazonaws.com"
        }
      },
      "google.com": {
        "dropRate": 1,
        "latencyMs": "NaN",
        "target": {
          "service": "Google",
          "location": "",
          "address": "google.com"
        }
      }
    }
  }
}
```
[[device.GetPingResponse]]


