Field_code: 3012
hex_data: 0000000004a2bc0100

## 형식
![[Pasted image 20241013135215.png]]
[[SpaceX.API.Device.WifiSetMeshDeviceTrustRequest]]



## 요청정보
- 데이터 없을때
```
{
  "wifiSetMeshDeviceTrust": {}
}
```

- 데이터 있을때
```
{
  "wifiSetMeshDeviceTrust": {
    "deviceId": "",
    "auth": "MESH_AUTH_UNKNOWN"
  }
}
```
[[wifi.WifiSetMeshDeviceTrustRequest]]


## 응답정보
- InvalidArgument (3)
- Failed to set mesh auth(deviceId() not in MeshConfigs. MeshAuth(MESH_AUTH_UNKNOWN) not set.)
[[wifi.WifiSetMeshDeviceTrustResponse]]


