Field_code: 1014
hex_data: 0000000003b23f00

## 형식
![[Pasted image 20241012185422.png]]
[[SpaceX.API.Device.UpdateRequest]]



## 요청정보
- 데이터 없을때
```
{
  "update": {}
}
```
[[device.UpdateRequest]]



## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "61",
  "update": {}
}
```
[[device.UpdateResponse]]



