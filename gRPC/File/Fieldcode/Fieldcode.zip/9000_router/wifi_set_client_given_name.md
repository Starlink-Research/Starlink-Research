Field_code: 3017
hex_data: 0000000004cabc0100

## 형식
![[Pasted image 20241013135518.png]]
[[SpaceX.API.Device.WifiSetClientGivenNameRequest]]


## 요청정보
- 데이터 없을때
```
{
  "wifiSetClientGivenName": {}
}
```

- 데이터 있을때
```
{
  "wifiSetClientGivenName": {
    "clientName": {
      "macAddress": "a",
      "givenName": "a"
    },
    "clientConfig": {
      "weeklyBlockSchedules": [
        {
          "blockRanges": [
            {
              "startMinutes": 0,
              "endMinutes": 0
            }
          ],
          "groupId": "a"
        }
      ],
      "macAddress": "a",
      "clientId": 0,
      "givenName": "a",
      "groupId": "a"
    }
  }
}
```
[[wifi.WifiSetClientGivenNameRequest]]


## 응답정보
- PermissionDenied (7)
- Permission denied


