Field_code: 2011
hex_data: 0000000003da7d00

## 형식
![[Pasted image 20241012211428.png]]
[[SpaceX.API.Device.DishGetConfigRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishGetConfig": {}
}
```
[[dish.DishGetConfigRequest]]


## 응답정보
-  Unimplemented (12)
- Unimplemented: *device.Request_StartDishSelfTest
[[dish.DishGetConfigResponse]]

