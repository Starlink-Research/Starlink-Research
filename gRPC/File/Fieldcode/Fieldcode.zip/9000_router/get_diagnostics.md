Field_code: 6000
hex_data: 000000000482f70200

## 형식
![[Pasted image 20241013142246.png]]
[[SpaceX.API.Device.GetDiagnosticsRequest]]


## 요청정보
- 데이터 없을때
```
{
  "getDiagnostics": {}
}
```
[[device.GetDiagnosticsRequest]]




## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "61",
  "wifi_get_diagnostics": {
    "id": "Router-010000000000000000CEF48F",
    "hardware_version": "v3",
    "software_version": "2024.20.0.mr34287"
  }
}
```
[[device.WifiGetDiagnosticsResponse]]


