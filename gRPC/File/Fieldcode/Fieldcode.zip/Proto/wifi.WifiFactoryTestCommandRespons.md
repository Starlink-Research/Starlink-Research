```
message WifiFactoryTestCommandResponse {
  string response = 1;
}
```
