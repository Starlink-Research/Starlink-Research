```
message DishOutage {
  enum Cause {
    UNKNOWN = 0;
    BOOTING = 1;
    STOWED = 2;
    THERMAL_SHUTDOWN = 3;
    NO_SCHEDULE = 4;
    NO_SATS = 5;
    OBSTRUCTED = 6;
    NO_DOWNLINK = 7;
    NO_PINGS = 8;
    ACTUATOR_ACTIVITY = 9;
    CABLE_TEST = 10;
    SLEEPING = 11;
    MOVING_WHILE_NOT_ALLOWED = 12;
  }

  .SpaceX.API.Device.DishOutage.Cause cause = 1;
  int64 start_timestamp_ns = 2;
  uint64 duration_ns = 3;
  bool did_switch = 4;
}
```


