[[transceiver.TransceiverGetTelemetryRequest]]

관련데이터
[[transceiver.TransceiverGetTelemetryResponse]]

