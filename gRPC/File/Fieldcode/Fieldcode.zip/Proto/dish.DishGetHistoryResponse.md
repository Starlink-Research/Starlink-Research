```
message DishGetHistoryResponse {
  reserved 1005;
  reserved 1006;
  reserved 1007;
  reserved 1008;
  uint64 current = 1;
  repeated float pop_ping_drop_rate = 1001;
  repeated float pop_ping_latency_ms = 1002;
  repeated float downlink_throughput_bps = 1003;
  repeated float uplink_throughput_bps = 1004;
  repeated .SpaceX.API.Device.DishOutage outages = 1009;
}
```
[[dish.DishOutage]]
