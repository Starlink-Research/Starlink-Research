```
message SelfTestRequest {
  bool detailed = 1;
}
```

