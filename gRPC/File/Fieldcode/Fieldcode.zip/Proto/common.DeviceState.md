```
message DeviceState {
  uint64 uptime_s = 1;
}
```

