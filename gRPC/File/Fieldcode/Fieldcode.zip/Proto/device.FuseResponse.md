```
message FuseResponse {
}
```

