```
message SelfTestResponse {
  bool passed = 1;
  string report = 2;
}
```



