```
message WifiGetFirewallResponse {
  string iptables = 1;
  string iptables_6 = 2;
}
```

