```
message DishObstructionStats {
  reserved "wedge_fraction_obstructed";
  reserved "wedge_abs_fraction_obstructed";
  reserved 2;
  reserved 3;
  reserved 1006;
  bool currently_obstructed = 5;
  float fraction_obstructed = 1;
  float time_obstructed = 9;
  float valid_s = 4;
  uint32 patches_valid = 10;
  float avg_prolonged_obstruction_duration_s = 6;
  float avg_prolonged_obstruction_interval_s = 7;
  bool avg_prolonged_obstruction_valid = 8;
}
```



