```
message DishSetConfigResponse {
  .SpaceX.API.Device.DishConfig updated_dish_config = 1;
}
```
[[dish_config.DishConfig]]
