```
message WifiGetStatusResponse {
  reserved 2;
  reserved 5;
  reserved 6;
  reserved 7;
  reserved 1001;
  reserved 1002;
  reserved 1006;
  reserved 1007;
  .SpaceX.API.Device.DeviceInfo device_info = 3;
  .SpaceX.API.Device.DeviceState device_state = 4;
  bool captive_portal_enabled = 1;
  string ipv4_wan_address = 1003;
  repeated string ipv6_wan_addresses = 1017;
  float ping_drop_rate = 1004;
  float ping_drop_rate_5m = 1021;
  float ping_latency_ms = 1005;
  float dish_ping_drop_rate = 1012;
  float dish_ping_drop_rate_5m = 1018;
  float dish_ping_latency_ms = 1013;
  float pop_ping_drop_rate = 1014;
  float pop_ping_drop_rate_5m = 1020;
  float pop_ping_latency_ms = 1015;
  .SpaceX.API.Device.WifiBandStatus rf_2ghz_status = 1008;
  .SpaceX.API.Device.WifiBandStatus rf_5ghz_status = 1009;
  .SpaceX.API.Device.WifiAlerts alerts = 1010;
  bool is_aviation = 1011;
  .SpaceX.API.Device.WifiConfig config = 2000;
  repeated .SpaceX.API.Device.WifiClient clients = 3000;
  bool has_client_index = 3001;
  int32 client_index = 3002;
  bool is_aviation_conformed = 1016;
  .SpaceX.API.Device.RadiusStatsMap radius_stats = 3003;
  repeated .SpaceX.API.Device.DhcpServer dhcp_servers = 1019;
  .SpaceX.API.Device.PoeStats poe_stats = 1022;
  string dish_id = 1023;
  int64 utc_ns = 1024;
}
```

[[common.DeviceInfo]]
[[common.DeviceState]]
[[wifi.WifiBandStatus]]
[[wifi.WifiAlerts]]
[[wifi_config.WifiConfig]]
[[wifi.WifiClient]]
[[wifi_util.RadiusStatsMap]]
[[wifi_util.DhcpServer]]
[[wifi_util.PoeStats]]









