```
message GetPingResponse {
  message ResultsEntry {
    string key = 1;
    .SpaceX.API.Device.PingResult value = 2;
  }

  repeated .SpaceX.API.Device.GetPingResponse.ResultsEntry results = 1;
}
```

[[common.PingResult]]


