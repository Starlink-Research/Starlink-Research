```
message RssiEntry {
  double theta_degree = 1;
  double phi_degree = 2;
  double rssi_dbf = 3;
  uint64 scan_timestamp_ms = 4;
}
```

