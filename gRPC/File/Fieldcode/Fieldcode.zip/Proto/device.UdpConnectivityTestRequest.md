```
message UdpConnectivityTestRequest {
  enum UDPProbeDataType {
    EMPTY = 0;
    DNS_STATUS_REQUEST = 1;
    DTLS_CLIENT_HELLO = 2;
    DNS_VERSION_BIND_REQ = 3;
    RPC_CHECK = 4;
    DNS_SD = 5;
    SNMP_V1_PUBLIC = 6;
    SNMP_V3_GET_REQUEST = 7;
    NTP_MESSAGE = 8;
    XDMCP = 9;
    KERBEROS = 10;
    SIP_OPTIONS = 11;
    LDAP_SEARCH_REQ = 12;
    MEMCACHED_STATS = 13;
    OPENVPN = 14;
    CIFS_NS_UC = 15;
    TFTP_GET = 16;
    DHCP_INFORM = 17;
    QUIC = 18;
    RIPV1 = 19;
    NFS_PROC_NULL = 20;
    COAP_REQUEST = 21;
  }

  string target = 1;
  uint32 port = 2;
  .SpaceX.API.Device.UdpConnectivityTestRequest.UDPProbeDataType probe_data = 3;
}
```
