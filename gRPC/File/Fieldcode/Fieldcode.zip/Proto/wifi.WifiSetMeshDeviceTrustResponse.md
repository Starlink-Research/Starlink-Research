```
message WifiSetMeshDeviceTrustResponse {
}
```

