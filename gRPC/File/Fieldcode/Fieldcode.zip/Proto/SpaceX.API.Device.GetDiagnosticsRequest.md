[[device.GetDiagnosticsRequest]]

관련자료
[[device.WifiGetDiagnosticsResponse]]

[[device.DishGetDiagnosticsResponse]]


