```
message SpeedTestStats {
  enum Target {
    UNKNOWN = 0;
    FASTCOM = 1;
    CLOUDFLARE = 2;
  }

  float latency_ms = 3;
  uint64 start_time = 4;
  int64 upload_start_time = 5;
  int64 download_start_time = 6;
  float upload_mbps = 1;
  float download_mbps = 2;
  .SpaceX.API.Device.SpeedTestStats.Target target = 7;
  uint32 tcp_streams = 8;
}
```

![[Pasted image 20241012184254.png]]