```
message DishClearObstructionMapRequest {
}
```
