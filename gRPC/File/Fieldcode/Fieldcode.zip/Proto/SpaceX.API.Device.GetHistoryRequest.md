[[device.GetHistoryRequest]]

관련데이터
[[dish.DishGetHistoryResponse]]

[[wifi.WifiGetHistoryResponse]]


