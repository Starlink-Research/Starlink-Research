```
enum UserMobilityClass {
  STATIONARY = 0;
  NOMADIC = 1;
  MOBILE = 2;
}
```



