```
message WifiBackhaulStatsRequest {
}
```

