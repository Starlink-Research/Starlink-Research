```
message GetSpeedtestStatusResponse {
  .SpaceX.API.Device.SpeedtestStatus status = 1;
}
```

[[device.SpeedtestStatus]]

