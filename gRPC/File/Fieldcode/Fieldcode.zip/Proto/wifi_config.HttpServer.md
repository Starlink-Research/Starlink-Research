```
message HttpServer {
  string domain_name = 1;
  string pages_bundle_url = 101;
  optional .SpaceX.API.Device.TlsConfig tls = 2;
  optional string file_content_id = 3;
}
```
[[wifi_config.TlsConfig]]


