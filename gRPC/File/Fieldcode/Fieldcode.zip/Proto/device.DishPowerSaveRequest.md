```
message DishPowerSaveRequest {
  uint32 power_save_start_minutes = 1;
  uint32 power_save_duration_minutes = 2;
  bool enable_power_save = 3;
}
```
