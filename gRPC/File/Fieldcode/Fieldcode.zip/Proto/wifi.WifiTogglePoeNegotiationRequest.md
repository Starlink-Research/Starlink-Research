```
message WifiTogglePoeNegotiationRequest {
  bool enable = 1;
}
```
