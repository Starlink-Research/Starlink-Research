```
message StartSpeedtestRequest {
}
```

