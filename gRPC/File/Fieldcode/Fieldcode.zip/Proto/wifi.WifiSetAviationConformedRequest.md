```
message WifiSetAviationConformedRequest {
}
```
