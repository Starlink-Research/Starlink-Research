```
message WifiSetupRequest {
  bool skip = 1;
  string network_name = 2;
  string network_password = 3;
  bool bypass = 4;
}
```
