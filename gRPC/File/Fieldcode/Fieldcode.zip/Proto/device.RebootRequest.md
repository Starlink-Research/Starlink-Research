```
message RebootRequest {
}
```

