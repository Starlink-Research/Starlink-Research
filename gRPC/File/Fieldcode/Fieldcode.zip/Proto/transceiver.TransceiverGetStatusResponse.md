```
message TransceiverGetStatusResponse {
  .SpaceX.API.Device.TransceiverModulatorState mod_state = 1;
  .SpaceX.API.Device.TransceiverModulatorState demod_state = 2;
  .SpaceX.API.Device.TransceiverTxRxState tx_state = 3;
  .SpaceX.API.Device.TransceiverTxRxState rx_state = 4;
  .SpaceX.API.Device.DishState state = 1006;
  .SpaceX.API.Device.TransceiverFaults faults = 1007;
  .SpaceX.API.Device.TransceiverTransmitBlankingState transmit_blanking_state = 1008;
  float modem_asic_temp = 1009;
  float tx_if_temp = 1010;
}
```
[[transceiver.TransceiverModulatorState]]
[[transceiver.TransceiverTxRxState]]
[[dish.DishState]]
[[transceiver.TransceiverFaults]]
[[transceiver.TransceiverTransmitBlankingState]]

