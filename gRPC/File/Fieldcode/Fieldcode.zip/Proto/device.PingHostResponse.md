```
message PingHostResponse {
  .SpaceX.API.Device.PingResult result = 1;
}
```

[[common.PingResult]]

