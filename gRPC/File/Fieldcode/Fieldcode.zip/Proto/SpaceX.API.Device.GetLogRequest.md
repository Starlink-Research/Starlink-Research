[[device.GetLogRequest]]

관련데이터
[[device.GetLogResponse]]

