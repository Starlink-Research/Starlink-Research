```
message GetTimeResponse {
  int64 unix_nano = 1;
}
```
