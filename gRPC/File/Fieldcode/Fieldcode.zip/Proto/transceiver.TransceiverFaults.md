```
message TransceiverFaults {
  bool over_temp_modem_asic_fault = 1;
  bool over_temp_pcba_fault = 2;
  bool dc_voltage_fault = 3;
}
```
