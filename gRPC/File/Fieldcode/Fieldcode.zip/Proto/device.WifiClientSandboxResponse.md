```
message WifiClientSandboxResponse {
}
```

