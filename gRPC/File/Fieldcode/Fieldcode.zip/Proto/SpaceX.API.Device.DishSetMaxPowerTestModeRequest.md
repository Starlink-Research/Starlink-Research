[[device.DishSetMaxPowerTestModeRequest]]

관련데이터
[[device.DishSetMaxPowerTestModeResponse]]

