```
message GetLogRequest {
}
```

