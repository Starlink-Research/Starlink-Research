```
message DishInhibitGpsRequest {
  bool inhibit_gps = 1;
}
```
