[[dish.DishClearObstructionMapRequest]]

관련데이터
[[dish.DishClearObstructionMapResponse]]

