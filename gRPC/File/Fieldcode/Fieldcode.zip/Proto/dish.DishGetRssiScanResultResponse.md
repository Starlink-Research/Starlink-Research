```
message DishGetRssiScanResultResponse {
  .SpaceX.API.Device.DishGetRssiScanResult result = 1;
}
```

[[rssi_scan.DishGetRssiScanResult]]

