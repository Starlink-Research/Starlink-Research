[[wifi.WifiTogglePoeNegotiationRequest]]

