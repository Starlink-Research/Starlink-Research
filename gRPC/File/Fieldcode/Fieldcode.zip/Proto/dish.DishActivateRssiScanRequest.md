```
message DishActivateRssiScanRequest {
  .SpaceX.API.Device.DishActivateRssiScan scan_query = 1;
}
```
[[rssi_scan.DishActivateRssiScan]]

