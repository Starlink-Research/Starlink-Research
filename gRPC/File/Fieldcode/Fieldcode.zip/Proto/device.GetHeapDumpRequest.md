```
message GetHeapDumpRequest {
}
```


