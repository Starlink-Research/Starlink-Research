```
message WifiSetMeshConfigRequest {
  .SpaceX.API.Device.MeshConfig mesh_config = 1;
  string device_id = 2;
}
```
[[wifi_config.MeshConfig]]

