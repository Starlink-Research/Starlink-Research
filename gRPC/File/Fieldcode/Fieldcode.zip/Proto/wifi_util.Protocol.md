```
enum Protocol {
  TCP = 0;
  UDP = 1;
  TLS = 2;
  DTLS = 3;
}
```
