[[dish.DishStowRequest]]

관련데이터
[[dish.DishStowResponse]]

