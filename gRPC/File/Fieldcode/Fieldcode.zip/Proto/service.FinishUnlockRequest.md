```
message FinishUnlockRequest {
  bytes challenge = 1;
  bytes signature = 2;
}
```
