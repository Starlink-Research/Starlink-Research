```
message GetDeviceInfoRequest {
}
```
