```
message InitializationDurationSeconds {
  int32 attitude_initialization = 1;
  int32 burst_detected = 2;
  int32 ekf_converged = 3;
  int32 first_cplane = 4;
  int32 first_pop_ping = 5;
  int32 gps_valid = 6;
  int32 initial_network_entry = 7;
  int32 network_schedule = 8;
  int32 rf_ready = 9;
  int32 stable_connection = 10;
}
```


