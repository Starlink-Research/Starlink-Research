```
message LLAPosition {
  double lat = 1;
  double lon = 2;
  double alt = 3;
}
```


