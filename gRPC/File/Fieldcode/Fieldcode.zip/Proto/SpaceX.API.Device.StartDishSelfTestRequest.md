[[dish.StartDishSelfTestRequest]]

관련데이터
[[dish.StartDishSelfTestResponse]]
