```
message MeshConfig {
  reserved 6;
  reserved 8;
  string display_name = 1;
  bool apply_display_name = 2;
  .SpaceX.API.Device.MeshAuth auth = 3;
  bool apply_auth = 4;
  int64 last_connected = 5;
  uint64 incarnation = 7;
  string hardware_version = 9;
  bool supports_5ghz_high = 10;
}
```

[[wifi_config.MeshAuth]]

![[Pasted image 20241012214351.png]]