[[wifi.WifiSetupRequest]]

관련데이터
[[wifi.WifiSetupResponse]]

