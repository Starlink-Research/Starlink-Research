```
message StartUnlockResponse {
  string device_id = 1;
  bytes nonce = 2;
  bytes sign_spki = 3;
}
```
