```
message WifiGetPingMetricsRequest {
}
```
