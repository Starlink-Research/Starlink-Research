[[device.GetPersistentStatsRequest]]

관련자료
[[wifi.WifiGetPersistentStatsResponse]]
