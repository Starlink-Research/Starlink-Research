```
message ClientConfig {
  reserved "weekly_block_schedule";
  reserved 4;
  uint32 client_id = 1;
  string mac_address = 2;
  string given_name = 3;
  repeated .SpaceX.API.Device.WeeklyBlockSchedule weekly_block_schedules = 5;
  string group_id = 6;
}
```
[[wifi_config.WeeklyBlockSchedule]]

![[Pasted image 20241012214808.png]]

