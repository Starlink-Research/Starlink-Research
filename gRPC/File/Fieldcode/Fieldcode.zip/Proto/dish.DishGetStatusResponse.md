```
message DishGetStatusResponse {
  reserved 1001;
  reserved 1006;
  reserved 1013;
  .SpaceX.API.Device.DeviceInfo device_info = 1;
  .SpaceX.API.Device.DeviceState device_state = 2;
  .SpaceX.API.Device.DishAlerts alerts = 1005;
  .SpaceX.API.Device.DishOutage outage = 1014;
  .SpaceX.API.Device.DishGpsStats gps_stats = 1015;
  float seconds_to_first_nonempty_slot = 1002;
  float pop_ping_drop_rate = 1003;
  float downlink_throughput_bps = 1007;
  float uplink_throughput_bps = 1008;
  float pop_ping_latency_ms = 1009;
  .SpaceX.API.Device.DishObstructionStats obstruction_stats = 1004;
  bool stow_requested = 1010;
  float boresight_azimuth_deg = 1011;
  float boresight_elevation_deg = 1012;
  int32 eth_speed_mbps = 1016;
  .SpaceX.API.Device.UserMobilityClass mobility_class = 1017;
  bool is_snr_above_noise_floor = 1018;
  .SpaceX.API.Device.DishReadyStates ready_states = 1019;
  .SpaceX.API.Device.UserClassOfService class_of_service = 1020;
  .SpaceX.API.Device.SoftwareUpdateState software_update_state = 1021;
  bool swupdate_reboot_ready = 1030;
  .SpaceX.API.Device.SoftwareUpdateStats software_update_stats = 1026;
  .SpaceX.API.Device.AlignmentStats alignment_stats = 1027;
  bool is_snr_persistently_low = 1022;
  .SpaceX.API.Device.HasActuators has_actuators = 1023;
  .SpaceX.API.Satellites.Network.UtDisablementCode disablement_code = 1024;
  bool has_signed_cals = 1025;
  .SpaceX.API.Device.DishConfig config = 2000;
  .SpaceX.API.Device.InitializationDurationSeconds initialization_duration_seconds = 1028;
  bool is_cell_disabled = 1029;
}
```
[[common.DeviceInfo]]
[[common.DeviceState]]
[[dish.DishAlerts]]
[[dish.DishOutage]]
[[dish.DishGpsStats]]
[[dish.DishObstructionStats]]
[[dish.UserMobilityClass]]
[[dish.DishReadyStates]]
[[dish.UserClassOfService]]
[[dish.SoftwareUpdateState]]
[[dish.AlignmentStats]]
[[dish.HasActuators]]
[[Satellites.Network.UtDisablementCode]]
[[dish_config.DishConfig]]
[[dish.InitializationDurationSeconds]]













