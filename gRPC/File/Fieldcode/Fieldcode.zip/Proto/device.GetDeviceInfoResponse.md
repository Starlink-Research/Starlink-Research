```
message GetDeviceInfoResponse {
  .SpaceX.API.Device.DeviceInfo device_info = 1;
}
```

[[common.DeviceInfo]]

