[[wifi.WifiGetConfigRequest]]

관련데이터
[[wifi.WifiGetConfigResponse]]

