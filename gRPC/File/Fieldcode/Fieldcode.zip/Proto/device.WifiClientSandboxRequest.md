```
message WifiClientSandboxRequest {
  repeated .SpaceX.API.Device.WifiClientSandboxStatus client_sandbox_status = 1;
  repeated .SpaceX.API.Device.WifiClientSandboxAlert alerts = 2;
}
```

[[device.WifiClientSandboxStatus]]
[[device.WifiClientSandboxAlert]]


