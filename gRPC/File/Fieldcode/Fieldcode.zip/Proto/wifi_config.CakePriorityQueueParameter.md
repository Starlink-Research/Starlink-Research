```
enum CakePriorityQueueParameter {
  DIFFSERV3 = 0;
  DIFFSERV4 = 1;
  PRECEDENCE = 2;
  BEST_EFFORT = 3;
}
```


