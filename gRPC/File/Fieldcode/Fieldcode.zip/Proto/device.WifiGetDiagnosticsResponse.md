```
message WifiGetDiagnosticsResponse {
  string id = 1;
  string hardware_version = 2;
  string software_version = 3;
}
```

