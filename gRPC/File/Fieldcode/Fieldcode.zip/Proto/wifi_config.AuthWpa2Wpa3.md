```
message AuthWpa2Wpa3 {
  string password = 1;
}
```

