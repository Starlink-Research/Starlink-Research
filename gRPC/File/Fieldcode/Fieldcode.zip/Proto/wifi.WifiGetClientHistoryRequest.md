```
message WifiGetClientHistoryRequest {
  string mac_address = 1;
  uint32 client_id = 2;
}
```
