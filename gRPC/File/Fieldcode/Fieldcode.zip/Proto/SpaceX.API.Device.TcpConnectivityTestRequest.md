[[device.TcpConnectivityTestRequest]]

