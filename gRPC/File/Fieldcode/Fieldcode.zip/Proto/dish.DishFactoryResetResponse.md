```
message DishFactoryResetResponse {
}
```

