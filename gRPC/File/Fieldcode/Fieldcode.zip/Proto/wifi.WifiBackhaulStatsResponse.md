```
message WifiBackhaulStatsResponse {
  bool success = 1;
  string bssid = 2;
  .SpaceX.API.Device.IfaceType iface = 3;
  uint32 preference = 4;
  repeated .SpaceX.API.Device.WifiSiteSurveyResult siteSurveyScan = 5;
}
```

[[wifi.WifiSiteSurveyResult]]


