```
message FactoryResetRequest {
}
```

