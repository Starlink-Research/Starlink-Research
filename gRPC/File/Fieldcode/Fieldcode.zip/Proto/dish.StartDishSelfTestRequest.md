```
message StartDishSelfTestRequest {
}
```
