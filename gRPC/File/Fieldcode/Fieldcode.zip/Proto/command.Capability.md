```
enum Capability {
  READ = 0;
  READ_INTERNAL = 13;
  READ_PRIVATE = 7;
  LOCAL = 14;
  WRITE = 1;
  WRITE_PERSISTENT = 11;
  DEBUG = 2;
  ADMIN = 3;
  SETUP = 4;
  SET_SKU = 5;
  REFRESH = 6;
  FUSE = 8;
  RESET = 9;
  TEST = 10;
  SSH = 12;
  GUEST = 15;
}
```


![[Pasted image 20241012185106.png]]


