```
message EnableDebugTelemRequest {
  uint32 duration_m = 1;
}
```

![[Pasted image 20241012184750.png]]