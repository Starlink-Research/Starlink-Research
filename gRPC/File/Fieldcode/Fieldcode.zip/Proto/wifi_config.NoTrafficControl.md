```
message NoTrafficControl {
}
```

