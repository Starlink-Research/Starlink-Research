```
message DishSetMaxPowerTestModeRequest {
  bool enabled = 1;
}
```
