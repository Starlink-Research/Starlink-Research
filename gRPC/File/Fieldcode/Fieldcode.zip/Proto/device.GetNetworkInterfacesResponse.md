```
message GetNetworkInterfacesResponse {
  repeated .SpaceX.API.Device.NetworkInterface network_interfaces = 1006;
}
```
[[common.NetworkInterface]]


