```
message GetNetworkInterfacesRequest {
}
```

