```
message DishStowResponse {
}
```
