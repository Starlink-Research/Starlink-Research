```
message StartSpeedtestResponse {
}
```

