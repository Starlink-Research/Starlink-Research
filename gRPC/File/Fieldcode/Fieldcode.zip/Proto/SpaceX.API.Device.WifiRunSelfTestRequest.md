[[wifi.WifiRunSelfTestRequest]]


