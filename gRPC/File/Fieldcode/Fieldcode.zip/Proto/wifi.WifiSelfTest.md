```
message WifiSelfTest {
  message TestResult {
    string name = 1;
    bool success = 2;
    string failure_reason = 3;
  }

  bool total_success = 1;
  .SpaceX.API.Device.WifiSelfTest.TestResult fused = 2;
  repeated .SpaceX.API.Device.WifiSelfTest.TestResult eth_phys = 3;
  repeated .SpaceX.API.Device.WifiSelfTest.TestResult pcis = 4;
  .SpaceX.API.Device.WifiSelfTest.TestResult bl2_prod = 5;
}
```
