
[[common.AuthenticateRequest]]


관련데이터
[[dish.DishAuthenticateResponse]]

[[wifi.WifiAuthenticateResponse]]


