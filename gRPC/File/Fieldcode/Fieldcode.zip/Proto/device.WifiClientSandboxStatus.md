```
message WifiClientSandboxStatus {
  string client = 1;
  uint32 sandbox = 2;
  bool sandboxed = 3;
}
```
