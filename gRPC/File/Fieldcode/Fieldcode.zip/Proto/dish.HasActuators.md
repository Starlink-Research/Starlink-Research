```
enum HasActuators {
  HAS_ACTUATORS_UNKNOWN = 0;
  HAS_ACTUATORS_YES = 1;
  HAS_ACTUATORS_NO = 2;
}
```

