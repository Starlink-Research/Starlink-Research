```
message SetSkuRequest {
  string sku = 1;
  string country_code = 2;
  bool apply_country_code = 4;
  bool pin_country_code = 5;
  bool custom_power_table = 6;
}
```

![[Pasted image 20241012184932.png]]


