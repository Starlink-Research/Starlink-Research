```
message DishGetDiagnosticsResponse {
  message Alerts {
    bool dish_is_heating = 1;
    bool dish_thermal_throttle = 2;
    bool dish_thermal_shutdown = 3;
    bool power_supply_thermal_throttle = 4;
    bool motors_stuck = 5;
    bool mast_not_near_vertical = 6;
    bool slow_ethernet_speeds = 7;
    bool software_install_pending = 8;
    bool moving_too_fast_for_policy = 9;
  }

  enum TestResult {
    NO_RESULT = 0;
    PASSED = 1;
    FAILED = 2;
  }

  enum DisablementCode {
    UNKNOWN = 0;
    OKAY = 1;
    NO_ACTIVE_ACCOUNT = 2;
    TOO_FAR_FROM_SERVICE_ADDRESS = 3;
    IN_OCEAN = 4;
    INVALID_COUNTRY = 5;
    BLOCKED_COUNTRY = 6;
    DATA_OVERAGE_SANDBOX_POLICY = 7;
  }

  string id = 1;
  string hardware_version = 2;
  string software_version = 3;
  int32 utc_offset_s = 4;
  .SpaceX.API.Device.DishGetDiagnosticsResponse.TestResult hardware_self_test = 7;
  .SpaceX.API.Device.DishGetDiagnosticsResponse.Alerts alerts = 5;
  .SpaceX.API.Device.DishGetDiagnosticsResponse.DisablementCode disablement_code = 6;
}
```