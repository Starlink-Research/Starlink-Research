```
message WifiSelfTestResponse {
  .SpaceX.API.Device.WifiSelfTest self_test = 1;
  string json = 2;
}
```
[[wifi.WifiSelfTest]]

