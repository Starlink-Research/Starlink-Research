```
message BootInfo {
  message CountByReasonEntry {
    int32 key = 1;
    int32 value = 2;
  }

  message CountByReasonDeltaEntry {
    int32 key = 1;
    int32 value = 2;
  }

  repeated .SpaceX.API.Device.BootInfo.CountByReasonEntry count_by_reason = 1;
  repeated .SpaceX.API.Device.BootInfo.CountByReasonDeltaEntry count_by_reason_delta = 4;
  .SpaceX.API.Device.BootReason last_reason = 2;
  int32 last_count = 3;
  bool crash_boot = 5;
  int32 crash_boot_count = 6;
}
```
router


```
message BootInfo {
  message CountByReasonEntry {
    int32 key = 1;
    int32 value = 2;
  }

  message CountByReasonDeltaEntry {
    int32 key = 1;
    int32 value = 2;
  }

  repeated .SpaceX.API.Device.BootInfo.CountByReasonEntry count_by_reason = 1;
  repeated .SpaceX.API.Device.BootInfo.CountByReasonDeltaEntry count_by_reason_delta = 4;
  .SpaceX.API.Device.BootReason last_reason = 2;
  int32 last_count = 3;
  bool crash_boot = 5;
  int32 crash_boot_count = 6;
  string even_side_software_version = 7;
  string odd_side_software_version = 8;
  int32 api_version_odd_side = 9;
  int32 api_version_even_side = 10;
}
```
dishy

[[common.BootReason]]


![[Pasted image 20241012214622.png]]
