[[wifi.WifiSetMeshDeviceTrustRequest]]

관련데이터
[[wifi.WifiSetMeshDeviceTrustResponse]]

