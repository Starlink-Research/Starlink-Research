```
message GetConnectionsRequest {
}
```

