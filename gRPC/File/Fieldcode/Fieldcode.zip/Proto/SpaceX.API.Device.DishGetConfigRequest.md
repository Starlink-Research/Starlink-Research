[[dish.DishGetConfigRequest]]

관련데이터
[[dish.DishGetConfigResponse]]

