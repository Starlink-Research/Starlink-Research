```
message ResetButtonRequest {
  bool pressed = 1;
}
```

