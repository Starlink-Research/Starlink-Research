```
message DishClearObstructionMapResponse {
}
```
