```
enum WifiSecurity {
  WIFI_SECURITY_UNKNOWN = 0;
  OPEN = 1;
  WPA2 = 2;
  WPA3 = 3;
  WPA2WPA3 = 4;
}
```

