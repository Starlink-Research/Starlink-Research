```
message WifiSetConfigResponse {
  .SpaceX.API.Device.WifiConfig updated_wifi_config = 1;
}
```
[[wifi_config.WifiConfig]]

