```
message WifiGetClientsRequest {
}
```
