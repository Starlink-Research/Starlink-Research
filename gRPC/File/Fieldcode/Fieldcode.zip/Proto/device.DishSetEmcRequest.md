```
message DishSetEmcRequest {
  double theta = 1;
  double phi = 2;
  uint32 rx_chan = 3;
  uint32 tx_chan = 4;
  uint32 modulation = 5;
  double desired_tilt_angle = 7;
  bool chan_override = 8;
  bool theta_enabled = 9;
  bool phi_enabled = 10;
  bool idle = 11;
  bool fast_switching = 12;
  bool sky_search = 13;
  bool force_pll_unlock = 14;
  bool force_eirp_failure = 15;
  bool snow_active_override = 16;
  bool manual_tilting = 18;
  bool tilt_to_stowed = 19;
  bool reboot = 20;
  bool continuous_motor_test = 21;
  double distance_override_meters = 22;
  uint32 amplitude_taper_override = 23;
  uint32 country_code_override = 24;
  int32 tx_duty_cycle_override = 25;
  int32 rx_duty_cycle_override = 26;
  double eirp_legal_limit_dbw_override = 27;
  double eirp_adjustment_db = 28;
}
```
