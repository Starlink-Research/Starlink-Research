```
message RestartControlRequest {
}
```

