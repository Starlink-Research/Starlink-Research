```
enum MeshAuth {
  MESH_AUTH_UNKNOWN = 0;
  MESH_AUTH_NEW = 1;
  MESH_AUTH_TRUSTED = 2;
  MESH_AUTH_UNTRUSTED = 3;
}
```


![[Pasted image 20241012214446.png]]


