```
message PingMetrics {
  float latency_mean_ms = 1;
  float latency_stddev_ms = 2;
  float latency_mean_ms_5m = 3;
  float latency_mean_ms_1h = 4;
  float latency_mean_ms_1d = 5;
  float drop_rate = 6;
  float drop_rate_5m = 7;
  float drop_rate_1h = 8;
  float drop_rate_1d = 9;
  float seconds_since_last_success = 10;
  float seconds_since_last_1s_outage = 11;
  float seconds_since_last_2s_outage = 15;
  float seconds_since_last_5s_outage = 12;
  float seconds_since_last_15s_outage = 18;
  float seconds_since_last_60s_outage = 19;
  float seconds_since_last_300s_outage = 20;
  float happy_hours_1s_1d = 13;
  float happy_hours_2s_1d = 16;
  float happy_hours_5s_1d = 14;
}
```