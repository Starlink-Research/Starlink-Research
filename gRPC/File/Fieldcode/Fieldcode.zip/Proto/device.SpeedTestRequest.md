```
message SpeedTestRequest {
  uint32 id = 4;
  .SpaceX.API.Device.SpeedTestStats client_speedtest = 1;
  float client_rssi = 2;
  .SpaceX.API.Device.ClientPlatform client_platform = 3;
}
```

[[device.SpeedTestStats]]
[[device.ClientPlatform]]


![[Pasted image 20241012185250.png]]

