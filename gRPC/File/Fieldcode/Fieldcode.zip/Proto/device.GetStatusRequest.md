```
message GetStatusRequest {
}
```
