```
message WifiGetClientHistoryResponse {
  enum WifiLimitedReason {
    LIMIT_UNKNOWN = 0;
    LIMIT_NONE = 1;
    LIMIT_UNCLASSIFIED = 2;
    LIMIT_DROPPED_PACKETS = 3;
  }

  uint64 current = 1;
  repeated float tx_throughput_mbps = 2;
  repeated float rx_throughput_mbps = 3;
  repeated .SpaceX.API.Device.WifiGetClientHistoryResponse.WifiLimitedReason throughput_limited = 4;
  repeated float rx_rate_mbps = 5;
  bytes rssi = 6;
}
```
