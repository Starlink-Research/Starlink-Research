```
message DishGetContextResponse {
  .SpaceX.API.Device.DeviceInfo device_info = 1;
  .SpaceX.API.Device.DeviceState device_state = 7;
  float obstruction_fraction = 2;
  float obstruction_time = 20;
  float obstruction_valid_s = 3;
  bool obstruction_current = 12;
  uint32 cell_id = 4;
  uint32 pop_rack_id = 5;
  uint32 initial_satellite_id = 8;
  uint32 initial_gateway_id = 9;
  bool on_backup_beam = 10;
  float seconds_to_slot_end = 6;
  bool debug_telemetry_enabled = 11;
  float pop_ping_drop_rate_15s_mean = 13;
  float pop_ping_latency_ms_15s_mean = 14;
  float seconds_since_last_1s_outage = 15;
  float seconds_since_last_2s_outage = 16;
  float seconds_since_last_5s_outage = 17;
  float seconds_since_last_15s_outage = 18;
  float seconds_since_last_60s_outage = 19;
  .SpaceX.API.Satellites.Network.UtDisablementCode disablement_code = 21;
  float ku_mac_active_ratio = 22;
}
```
router


```
message DishGetContextResponse {
  .SpaceX.API.Device.DeviceInfo device_info = 1;
  .SpaceX.API.Device.DeviceState device_state = 7;
  float obstruction_fraction = 2;
  float obstruction_time = 20;
  float obstruction_valid_s = 3;
  bool obstruction_current = 12;
  uint32 cell_id = 4;
  uint32 pop_rack_id = 5;
  uint32 initial_satellite_id = 8;
  uint32 initial_gateway_id = 9;
  bool on_backup_beam = 10;
  float seconds_to_slot_end = 6;
  bool debug_telemetry_enabled = 11;
  float pop_ping_drop_rate_15s_mean = 13;
  float pop_ping_latency_ms_15s_mean = 14;
  float seconds_since_last_1s_outage = 15;
  float seconds_since_last_2s_outage = 16;
  float seconds_since_last_5s_outage = 17;
  float seconds_since_last_15s_outage = 18;
  float seconds_since_last_60s_outage = 19;
  bool outage_1s_within_1h = 23;
  bool outage_2s_within_1h = 24;
  bool outage_5s_within_1h = 25;
  .SpaceX.API.Satellites.Network.UtDisablementCode disablement_code = 21;
  float ku_mac_active_ratio = 22;
}
```
dishy

[[common.DeviceInfo]]
[[common.DeviceState]]
[[Satellites.Network.UtDisablementCode]]

