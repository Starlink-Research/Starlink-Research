```
message InitiateRemoteSshResponse {
  uint32 port = 1;
  string address = 2;
  bytes stsafe = 3;
}
```


