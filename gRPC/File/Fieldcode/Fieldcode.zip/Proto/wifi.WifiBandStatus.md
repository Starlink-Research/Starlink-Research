```
message WifiBandStatus {
  float chan_busy_time_fraction = 1;
  float tx_air_time_fraction = 2;
  float rx_air_time_fraction = 3;
  float obss_air_time_fraction = 4;
  float edcca_air_time_fraction = 5;
}
```
