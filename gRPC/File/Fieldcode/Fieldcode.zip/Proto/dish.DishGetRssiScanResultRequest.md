```
message DishGetRssiScanResultRequest {
}
```
