[[wifi.WifiSetMeshConfigRequest]]

관련데이터
[[wifi.WifiSetMeshConfigResponse]]

