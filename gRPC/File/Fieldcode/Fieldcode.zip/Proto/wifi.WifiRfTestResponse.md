```
message WifiRfTestResponse {
  string report = 1;
}
```
