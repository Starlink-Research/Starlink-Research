[[wifi.WifiRfTestRequest]]

관련데이터
[[wifi.WifiRfTestResponse]]

