```
enum TransceiverTransmitBlankingState {
  TB_UNKNOWN = 0;
  TB_ENABLED = 1;
  TB_DISABLED = 2;
}
```
