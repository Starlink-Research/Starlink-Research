[[common.SoftwareUpdateRequest]]

관련데이터
[[common.SoftwareUpdateRespons]]

