```
message TcpConnectivityTestRequest {
  string target = 1;
  uint32 port = 2;
}
```

