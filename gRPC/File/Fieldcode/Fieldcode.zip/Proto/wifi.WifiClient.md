```
message WifiClient {
  message RxStats {
    reserved 4;
    uint64 bytes = 1;
    uint64 count_errors = 2;
    uint32 phy_mode = 13;
    int32 nss = 3;
    uint32 rate_mbps = 8;
    float rate_mbps_last_30s = 14;
    float rate_mbps_last_15s = 15;
    uint32 mcs = 5;
    uint32 bandwidth = 6;
    uint32 guard_ns = 7;
    float airtime_fraction_last_1s = 9;
    uint32 sampled_packets = 10;
    uint32 sampled_packets_retried = 11;
    uint32 sampled_packets_dropped = 12;
  }

  message TxStats {
    reserved 4;
    uint64 bytes = 1;
    uint64 success_bytes = 2;
    uint32 phy_mode = 10;
    int32 nss = 3;
    uint32 rate_mbps = 8;
    float rate_mbps_last_30s = 11;
    float rate_mbps_last_15s = 12;
    uint32 mcs = 5;
    uint32 bandwidth = 6;
    uint32 guard_ns = 7;
    float airtime_fraction_last_1s = 9;
  }

  message PingMetrics {
    bool in_unhappy_hour_2s = 1;
    bool in_unhappy_hour_5s = 2;
    float drop_rate_5m = 3;
    float latency_5m = 4;
  }

  message FqcodelInfo {
    uint64 enqs_hi_prio = 1;
    uint64 enqs_fqcodel = 2;
    uint64 enqs_new = 3;
    uint64 enqs_old = 4;
    uint64 enqs_dropped = 5;
    uint64 deqs_new = 6;
    uint64 deqs_old = 7;
    uint64 deqs_flow_new = 8;
    uint64 deqs_flow_old_deficit = 9;
    uint64 deqs_flow_old_starvation = 10;
    uint64 deqs_dropped = 11;
  }

  enum Interface {
    UNKNOWN = 0;
    ETH = 1;
    RF_2GHZ = 2;
    RF_5GHZ = 3;
    RF_5GHZ_HIGH = 4;
  }

  enum Role {
    ROLE_UNKNOWN = 0;
    CLIENT = 1;
    REPEATER = 2;
    CONTROLLER = 3;
  }

  string name = 1;
  string given_name = 31;
  string domain = 22;
  string mac_address = 2;
  string ip_address = 3;
  repeated string ipv6_addresses = 41;
  float signal_strength = 4;
  uint32 channel_width = 12;
  .SpaceX.API.Device.WifiClient.RxStats rx_stats = 5;
  .SpaceX.API.Device.WifiClient.TxStats tx_stats = 6;
  uint32 associated_time_s = 7;
  string mode_str = 8;
  .SpaceX.API.Device.WifiClient.Interface iface = 9;
  string iface_name = 26;
  float snr = 10;
  int32 psmode = 11;
  string upstream_mac_address = 13;
  .SpaceX.API.Device.WifiClient.Role role = 14;
  string device_id = 15;
  uint32 swq_checks = 16;
  uint32 swq_checks_non_empty = 17;
  uint32 mib_steer_state = 18;
  uint32 mib_steer_method = 19;
  uint32 btm_requests = 20;
  uint32 btm_requests_success = 21;
  uint32 steer_state = 30;
  uint32 steer_req_success_last_1h = 27;
  uint32 steer_req_fail_last_1h = 28;
  uint32 steer_req_fail_and_dissoc_last_1h = 29;
  bool dot11v_support = 23;
  uint32 hops_from_controller = 32;
  float est_tx_rate_mbps_from_controller = 33;
  float est_rx_rate_mbps_from_controller = 34;
  string hardware_version = 37;
  string software_version = 38;
  uint32 api_version = 39;
  .SpaceX.API.Device.WifiClient.PingMetrics ping_metrics = 40;
  bool blocked = 42;
  uint32 client_id = 43;
  .SpaceX.API.Device.WifiClient.FqcodelInfo fqcodel_info = 44;
}
```
router


```
message WifiClient {
  reserved "authorized";
  reserved 50;
  message RxStats {
    reserved 4;
    uint64 bytes = 1;
    uint64 count_errors = 2;
    uint32 phy_mode = 13;
    int32 nss = 3;
    uint32 rate_mbps = 8;
    float rate_mbps_last_30s = 14;
    float rate_mbps_last_15s = 15;
    uint32 mcs = 5;
    uint32 bandwidth = 6;
    uint32 guard_ns = 7;
    float airtime_fraction_last_1s = 9;
    uint32 sampled_packets = 10;
    uint32 sampled_packets_retried = 11;
    uint32 sampled_packets_dropped = 12;
  }

  message TxStats {
    reserved 4;
    uint64 bytes = 1;
    uint64 success_bytes = 2;
    uint32 phy_mode = 10;
    int32 nss = 3;
    uint32 rate_mbps = 8;
    float rate_mbps_last_30s = 11;
    float rate_mbps_last_15s = 12;
    uint32 mcs = 5;
    uint32 bandwidth = 6;
    uint32 guard_ns = 7;
    float airtime_fraction_last_1s = 9;
  }

  message PingMetrics {
    bool in_unhappy_hour_2s = 1;
    bool in_unhappy_hour_5s = 2;
    float drop_rate_5m = 3;
    float latency_5m = 4;
  }

  message FqcodelInfo {
    uint64 enqs_hi_prio = 1;
    uint64 enqs_fqcodel = 2;
    uint64 enqs_new = 3;
    uint64 enqs_old = 4;
    uint64 enqs_dropped = 5;
    uint64 deqs_new = 6;
    uint64 deqs_old = 7;
    uint64 deqs_flow_new = 8;
    uint64 deqs_flow_old_deficit = 9;
    uint64 deqs_flow_old_starvation = 10;
    uint64 deqs_dropped = 11;
  }

  enum Interface {
    UNKNOWN = 0;
    ETH = 1;
    RF_2GHZ = 2;
    RF_5GHZ = 3;
    RF_5GHZ_HIGH = 4;
  }

  enum Role {
    ROLE_UNKNOWN = 0;
    CLIENT = 1;
    REPEATER = 2;
    CONTROLLER = 3;
  }

  string name = 1;
  string given_name = 31;
  string domain = 22;
  string mac_address = 2;
  string ip_address = 3;
  bool dhcp_lease_found = 49;
  bool dhcp_lease_active = 46;
  bool dhcp_lease_renewed = 47;
  float seconds_until_dhcp_lease_expires = 48;
  repeated string ipv6_addresses = 41;
  float signal_strength = 4;
  uint32 channel_width = 12;
  .SpaceX.API.Device.WifiClient.RxStats rx_stats = 5;
  .SpaceX.API.Device.WifiClient.TxStats tx_stats = 6;
  uint32 associated_time_s = 7;
  uint32 no_data_idle_s = 45;
  string mode_str = 8;
  .SpaceX.API.Device.WifiClient.Interface iface = 9;
  string iface_name = 26;
  float snr = 10;
  int32 psmode = 11;
  string upstream_mac_address = 13;
  .SpaceX.API.Device.WifiClient.Role role = 14;
  string device_id = 15;
  uint32 swq_checks = 16;
  uint32 swq_checks_non_empty = 17;
  uint32 mib_steer_state = 18;
  uint32 mib_steer_method = 19;
  uint32 btm_requests = 20;
  uint32 btm_requests_success = 21;
  uint32 steer_state = 30;
  uint32 steer_req_success_last_1h = 27;
  uint32 steer_req_fail_last_1h = 28;
  uint32 steer_req_fail_and_dissoc_last_1h = 29;
  bool dot11v_support = 23;
  uint32 hops_from_controller = 32;
  float est_tx_rate_mbps_from_controller = 33;
  float est_rx_rate_mbps_from_controller = 34;
  string hardware_version = 37;
  string software_version = 38;
  uint32 api_version = 39;
  .SpaceX.API.Device.WifiClient.PingMetrics ping_metrics = 40;
  bool blocked = 42;
  uint32 client_id = 43;
  string sandbox_client_id = 51;
  .SpaceX.API.Device.WifiClient.FqcodelInfo fqcodel_info = 44;
}
```
dishy


