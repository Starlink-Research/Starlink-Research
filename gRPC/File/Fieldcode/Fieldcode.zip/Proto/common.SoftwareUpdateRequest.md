```
message SoftwareUpdateRequest {
  uint64 stream_id = 1;
  bytes data = 2;
  bool open = 3;
  bool close = 4;
}
```

![[Pasted image 20241012194305.png]]
