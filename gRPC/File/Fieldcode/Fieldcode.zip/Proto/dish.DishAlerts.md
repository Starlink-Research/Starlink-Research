```
message DishAlerts {
  reserved "moving_fast_while_not_aviation";
  reserved 13;
  bool motors_stuck = 1;
  bool thermal_throttle = 3;
  bool thermal_shutdown = 2;
  bool mast_not_near_vertical = 5;
  bool unexpected_location = 4;
  bool slow_ethernet_speeds = 6;
  bool roaming = 7;
  bool install_pending = 8;
  bool is_heating = 9;
  bool power_supply_thermal_throttle = 10;
  bool is_power_save_idle = 11;
  bool moving_while_not_mobile = 12;
  bool moving_too_fast_for_policy = 15;
  bool dbf_telem_stale = 14;
  bool low_motor_current = 16;
  bool lower_signal_than_predicted = 17;
}
```







