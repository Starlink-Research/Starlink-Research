```
message FactoryResetResponse {
}
```

