```
message DishPrioritizedUpdateRequest {
  bool prioritized = 1;
}
```
