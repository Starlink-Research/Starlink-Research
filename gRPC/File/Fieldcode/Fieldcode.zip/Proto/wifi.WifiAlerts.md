```
message WifiAlerts {
  reserved "inconsistent_2ghz_antennae_performance_15db";
  reserved "inconsistent_5ghz_antennae_performance_15db";
  reserved "poor_2ghz_antennae_performance_80db";
  reserved "poor_5ghz_antennae_performance_80db";
  reserved 6;
  reserved 7;
  reserved 8;
  reserved 9;
  bool thermal_throttle = 1;
  bool install_pending = 2;
  bool freshly_fused = 3;
  bool lan_eth_slow_link_10 = 4;
  bool lan_eth_slow_link_100 = 5;
  bool wan_eth_poor_connection = 10;
  bool mesh_topology_changing_often = 11;
  bool mesh_unreliable_backhaul = 12;
  bool radius_missing_process = 13;
  bool eth_switch_error = 14;
  bool poe_on_dish_unreachable = 15;
  bool poe_fuse_blown = 16;
  bool poe_router_overcurrent = 17;
  bool poe_off_current_nominal = 18;
  bool poe_vin_overvoltage = 19;
  bool poe_vin_undervoltage = 20;
}
```
