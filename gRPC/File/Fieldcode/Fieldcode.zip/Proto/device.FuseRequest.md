```
message FuseRequest {
  bool prevent_reboot = 1;
}
```

![[Pasted image 20241012191215.png]]