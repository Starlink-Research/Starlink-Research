```
message DhcpServer {
  string domain = 1;
  string subnet = 2;
  repeated .SpaceX.API.Device.DhcpLease leases = 3;
}
```
[[wifi_util.DhcpLease]]


