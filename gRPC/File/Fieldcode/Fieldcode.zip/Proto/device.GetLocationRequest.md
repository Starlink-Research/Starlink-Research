```
message GetLocationRequest {
  .SpaceX.API.Device.PositionSource source = 1;
}
```
[[device.PositionSource]]

![[Pasted image 20241012190119.png]]