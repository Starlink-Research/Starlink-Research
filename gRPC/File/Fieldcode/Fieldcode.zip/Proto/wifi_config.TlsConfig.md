```
message TlsConfig {
  string key = 1;
  string cert = 2;
}
```

