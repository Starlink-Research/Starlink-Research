```
message AlignmentStats {
  .SpaceX.API.Device.HasActuators has_actuators = 1;
  .SpaceX.API.Device.ActuatorState actuator_state = 2;
  float tilt_angle_deg = 3;
  float boresight_azimuth_deg = 4;
  float boresight_elevation_deg = 5;
  float desired_boresight_azimuth_deg = 8;
  float desired_boresight_elevation_deg = 9;
  .SpaceX.API.Device.AttitudeEstimationState attitude_estimation_state = 6;
  float attitude_uncertainty_deg = 7;
}
```
[[dish.HasActuators]]
[[dish.ActuatorState]]
[[dish.AttitudeEstimationState]]





