```
message PublicKey {
  string key = 1;
  repeated .SpaceX.API.Device.Capability capabilities = 2;
  .SpaceX.API.Device.User user = 3;
}
```

[[command.Capability]]
[[command.User]]

![[Pasted image 20241012185143.png]]




