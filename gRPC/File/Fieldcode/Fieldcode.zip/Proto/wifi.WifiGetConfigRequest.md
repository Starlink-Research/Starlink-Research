```
message WifiGetConfigRequest {
}
```
