```
enum TransceiverTxRxState {
  TXRX_UNKNOWN = 0;
  TXRX_ENABLED = 1;
  TXRX_DISABLED = 2;
}
```
