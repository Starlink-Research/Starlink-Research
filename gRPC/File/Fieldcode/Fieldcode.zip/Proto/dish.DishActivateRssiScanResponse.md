```
message DishActivateRssiScanResponse {
  bool success = 1;
}
```
