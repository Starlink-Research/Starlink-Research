[[wifi.WifiGetClientHistoryRequest]]

관련데이터
[[wifi.WifiGetClientHistoryResponse]]

