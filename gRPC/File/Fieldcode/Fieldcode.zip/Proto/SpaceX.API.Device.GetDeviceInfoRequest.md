
[[device.GetDeviceInfoRequest]]

관련데이터
[[device.GetDeviceInfoResponse]]
