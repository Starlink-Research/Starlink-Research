```
enum User {
  NO_USER = 0;
  GOD = 1;
  LAN = 2;
  CLOUD = 3;
  FACTORY = 4;
  ROUTER = 5;
  GUEST_LAN = 6;
  SENSITIVE_COMMANDING = 7;
}
```
router


```
enum User {
  NO_USER = 0;
  GOD = 1;
  LAN = 2;
  CLOUD = 3;
  FACTORY = 4;
  ROUTER = 5;
  GUEST_LAN = 6;
  SENSITIVE_COMMANDING = 7;
  LAN_TLS = 8;
}
```
dishy


![[Pasted image 20241012185032.png]]

