```
message WifiSetMeshConfigResponse {
}
```
