```
message TransceiverIFLoopbackTestResponse {
  float ber_loopback_test = 1;
  float snr_loopback_test = 2;
  float rssi_loopback_test = 3;
  bool pll_lock = 4;
}
```
