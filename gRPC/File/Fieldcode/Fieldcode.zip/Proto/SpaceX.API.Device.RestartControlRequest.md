[[device.RestartControlRequest]]

관련데이터
[[device.RestartControlResponse]]

