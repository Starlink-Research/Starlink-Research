```
enum WifiClientSandboxAlert {
  LANDING_PAGE_DOWN = 0;
  SANDBOX_API_DOWN_GROUND = 1;
  SANDBOX_API_DOWN_STARLINK = 2;
}
```
