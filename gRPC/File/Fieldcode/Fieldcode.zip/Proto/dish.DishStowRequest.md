```
message DishStowRequest {
  bool unstow = 1;
}
```
