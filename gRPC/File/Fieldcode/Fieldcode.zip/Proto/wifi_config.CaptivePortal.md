```
message CaptivePortal {
  string domain_name = 1;
  bool display_in_captive_browser = 2;
}
```

