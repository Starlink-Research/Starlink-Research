```
message PoeStats {
  .SpaceX.API.Device.PoeState poe_state = 1;
  float poe_power = 2;
  uint32 poe_faults_fast_overcurrent = 3;
  uint32 poe_faults_slow_overcurrent = 4;
  uint32 poe_faults_overvoltage = 5;
  uint32 poe_faults_undervoltage = 6;
}
```

[[wifi_util.PoeState]]


