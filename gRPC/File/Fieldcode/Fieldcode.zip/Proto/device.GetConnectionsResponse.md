```
message GetConnectionsResponse {
  message ServiceConnection {
    string address = 1;
    int32 seconds_since_success = 2;
  }

  message ServicesEntry {
    string key = 1;
    .SpaceX.API.Device.GetConnectionsResponse.ServiceConnection value = 2;
  }

  repeated .SpaceX.API.Device.GetConnectionsResponse.ServicesEntry services = 1;
}
```


