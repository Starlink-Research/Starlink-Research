```
message StartDishSelfTestResponse {
}
```
