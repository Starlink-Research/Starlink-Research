```
message WifiPersistentStats {
  message Event {
    uint32 count = 1;
    int64 last_occurred_timestamp = 2;
  }

  .SpaceX.API.Device.WifiPersistentStats.Event factory_reset_button = 1;
  .SpaceX.API.Device.WifiPersistentStats.Event factory_reset_plug_unplug = 2;
  .SpaceX.API.Device.WifiPersistentStats.Event factory_reset_command = 3;
  .SpaceX.API.Device.WifiPersistentStats.Event factory_reset_failed_load_wifi_config = 4;
  .SpaceX.API.Device.WifiPersistentStats.Event reboot_from_software_update = 5;
}
```

