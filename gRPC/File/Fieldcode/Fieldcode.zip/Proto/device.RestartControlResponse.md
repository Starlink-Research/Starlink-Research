```
message RestartControlResponse {
}
```

