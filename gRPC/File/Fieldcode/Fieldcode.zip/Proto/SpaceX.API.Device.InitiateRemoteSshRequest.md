[[common.InitiateRemoteSshRequest]]

관련데이터
[[common.InitiateRemoteSshResponse]]

