[[device.DishSetEmcRequest]]

관련데이터
[[device.DishSetEmcResponse]]

