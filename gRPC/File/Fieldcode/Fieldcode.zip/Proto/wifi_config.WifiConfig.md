```
message WifiConfig {
  reserved "apply_enable_remote_ssh";
  reserved "apply_lan_ipv4";
  reserved "apply_network_name";
  reserved "apply_network_name_5ghz";
  reserved "apply_network_password";
  reserved "apply_wifi_security";
  reserved "enable_remote_ssh";
  reserved "lan_ipv4";
  reserved "last_remote_ssh_access";
  reserved "network_name";
  reserved "network_name_5ghz";
  reserved "network_password";
  reserved "wifi_security";
  reserved 1;
  reserved 2;
  reserved 4;
  reserved 5;
  reserved 6;
  reserved 8;
  reserved 10;
  reserved 11;
  reserved 14;
  reserved 15;
  reserved 16;
  reserved 17;
  reserved 18;
  reserved 21;
  reserved 24;
  reserved 25;
  reserved 27;
  reserved 28;
  reserved 29;
  reserved 32;
  reserved 34;
  reserved 35;
  reserved 36;
  reserved 37;
  reserved 38;
  reserved 40;
  reserved 41;
  reserved 1001;
  reserved 1002;
  reserved 1003;
  reserved 1004;
  reserved 1005;
  reserved 1006;
  reserved 1007;
  reserved 1008;
  reserved 1009;
  reserved 1011;
  reserved 1012;
  reserved 1015;
  reserved 1021;
  reserved 1041;
  reserved 1051;
  reserved 1052;
  reserved 1053;
  reserved 1056;
  reserved 1057;
  reserved 2001;
  reserved 2002;
  reserved 2003;
  reserved 2004;
  reserved 2005;
  reserved 2006;
  reserved 2007;
  reserved 2008;
  message MeshConfigsEntry {
    string key = 1;
    .SpaceX.API.Device.MeshConfig value = 2;
  }

  message MeshConfigsUpdatesEntry {
    string key = 1;
    .SpaceX.API.Device.MeshConfig value = 2;
  }

  message BasicServiceSet {
    reserved 1000;
    reserved 1001;
    reserved 1002;
    reserved 1004;
    reserved 1006;
    reserved 2000;
    reserved 1012;
    reserved 1014;
    reserved 1016;
    string bssid = 1003;
    string ssid = 1005;
    .SpaceX.API.Device.WifiConfig.Band band = 1011;
    string iface_name = 1017;
    bool disable = 1013;
    bool hidden = 1015;
    oneof auth {
      .SpaceX.API.Device.AuthOpen auth_open = 2001;
      .SpaceX.API.Device.AuthWpa2 auth_wpa2 = 2002;
      .SpaceX.API.Device.AuthWpa3 auth_wpa3 = 2003;
      .SpaceX.API.Device.AuthWpa2Wpa3 auth_wpa2_wpa3 = 2004;
      .SpaceX.API.Device.AuthRadius auth_radius = 2005;
    }
  }

  message Network {
    reserved 1000;
    reserved 1001;
    reserved 1002;
    reserved 1004;
    reserved 1005;
    reserved 1006;
    string ipv4 = 1003;
    uint32 dhcpv4_start = 1012;
    bool dhcp_disabled = 1015;
    uint32 dhcpv4_lease_duration_s = 1016;
    string domain = 1011;
    repeated .SpaceX.API.Device.WifiConfig.BasicServiceSet basic_service_sets = 1007;
    bool client_isolation = 1008;
    bool guest = 1009;
    string landing = 1010;
    bool landing_page_v2 = 1017;
    bool internal = 1013;
    uint32 vlan = 1014;
  }

  enum Security {
    UNKNOWN = 0;
    WPA2 = 1;
    WPA3 = 2;
    WPA2WPA3 = 3;
  }

  enum Band {
    RF_UNKNOWN = 0;
    RF_2GHZ = 2;
    RF_5GHZ = 5;
    RF_5GHZ_HIGH = 6;
  }

  enum WirelessMode {
    WIRELESS_MODE_DEFAULT = 0;
    A_ONLY = 1;
    B_ONLY = 2;
    G_ONLY = 3;
    N_ONLY = 4;
    B_G_MIXED = 5;
    A_N_MIXED = 6;
    G_N_MIXED = 7;
    B_G_N_MIXED = 8;
    A_AN_AC_MIXED = 9;
    AN_AC_MIXED = 10;
    B_G_N_AX_MIXED = 11;
    A_AN_AC_AX_MIXED = 12;
  }

  enum HTBandwidth {
    HT_BANDWIDTH_DEFAULT = 0;
    HT_BANDWIDTH_20_MHZ = 1;
    HT_BANDWIDTH_20_OR_40_MHZ = 2;
  }

  enum VHTBandwidth {
    VHT_BANDWIDTH_DEFAULT = 0;
    VHT_BANDWIDTH_DISABLED = 1;
    VHT_BANDWIDTH_80_MHZ = 2;
    VHT_BANDWIDTH_160_MHZ = 3;
    VHT_BANDWIDTH_80_PLUS_80_MHZ = 4;
  }

  string country_code = 3;
  bool apply_country_code = 1085;
  bool pin_country_code = 53;
  bool apply_pin_country_code = 1086;
  bool custom_power_table = 54;
  bool apply_custom_power_table = 1087;
  bool setup_complete = 7;
  bool apply_setup_complete = 1010;
  uint32 version = 9;
  string mac_wan = 12;
  string mac_lan = 13;
  uint32 channel_2ghz = 19;
  bool apply_channel_2ghz = 1013;
  uint32 channel_5ghz = 20;
  bool apply_channel_5ghz = 1014;
  uint32 channel_5ghz_high = 57;
  bool apply_channel_5ghz_high = 1016;
  repeated .SpaceX.API.Device.WifiConfig.MeshConfigsEntry mesh_configs = 33;
  repeated .SpaceX.API.Device.WifiConfig.MeshConfigsUpdatesEntry mesh_configs_updates = 3033;
  bool apply_mesh_configs = 1033;
  repeated .SpaceX.API.Device.PublicKey dynamic_keys = 22;
  bool apply_dynamic_keys = 39;
  bool is_repeater = 23;
  bool apply_is_repeater = 1031;
  bool ap_mode = 51;
  bool apply_ap_mode = 1066;
  bool is_aviation = 49;
  bool apply_is_aviation = 1064;
  int32 boot_count = 26;
  .SpaceX.API.Device.BootInfo boot = 3001;
  repeated string nameservers = 30;
  bool apply_nameservers = 1054;
  bool secure_dns = 50;
  bool apply_secure_dns = 1065;
  bool bypass_mode = 31;
  bool apply_bypass_mode = 1055;
  bool dfs_enabled = 42;
  bool apply_dfs_enabled = 1058;
  bool disable_mesh_onboarding = 52;
  bool apply_disable_mesh_onboarding = 1067;
  repeated .SpaceX.API.Device.WifiConfig.Network networks = 1100;
  bool apply_networks = 1101;
  uint64 incarnation = 43;
  .SpaceX.API.Device.WifiConfig.WirelessMode wireless_mode_2ghz = 44;
  bool apply_wireless_mode_2ghz = 1059;
  .SpaceX.API.Device.WifiConfig.WirelessMode wireless_mode_5ghz = 45;
  bool apply_wireless_mode_5ghz = 1060;
  .SpaceX.API.Device.WifiConfig.WirelessMode wireless_mode_5ghz_high = 58;
  bool apply_wireless_mode_5ghz_high = 1070;
  .SpaceX.API.Device.WifiConfig.HTBandwidth ht_bandwidth_2ghz = 46;
  bool apply_ht_bandwidth_2ghz = 1061;
  .SpaceX.API.Device.WifiConfig.HTBandwidth ht_bandwidth_5ghz = 47;
  bool apply_ht_bandwidth_5ghz = 1062;
  .SpaceX.API.Device.WifiConfig.HTBandwidth ht_bandwidth_5ghz_high = 59;
  bool apply_ht_bandwidth_5ghz_high = 1071;
  .SpaceX.API.Device.WifiConfig.VHTBandwidth vht_bandwidth = 48;
  bool apply_vht_bandwidth = 1063;
  .SpaceX.API.Device.WifiConfig.VHTBandwidth vht_bandwidth_5ghz_high = 60;
  bool apply_vht_bandwidth_5ghz_high = 1072;
  bool use_public_services = 55;
  bool apply_use_public_services = 1068;
  bool disable_automated_speedtests = 56;
  bool apply_disable_automated_speedtests = 1069;
  bool enable_umbilical_vlan = 61;
  bool apply_enable_umbilical_vlan = 1073;
  repeated .SpaceX.API.Device.ClientName client_names = 62;
  bool apply_client_names = 1074;
  bool outdoor_mode = 63;
  bool apply_outdoor_mode = 1075;
  bool disable_2ghz = 64;
  bool apply_disable_2ghz = 1076;
  bool disable_5ghz = 65;
  bool apply_disable_5ghz = 1077;
  bool disable_5ghz_high = 66;
  bool apply_disable_5ghz_high = 1078;
  bool disable_x_mesh_backhaul = 67;
  bool apply_disable_x_mesh_backhaul = 1079;
  string golden_bssid = 68;
  bool apply_golden_bssid = 1080;
  .SpaceX.API.Device.IfaceType golden_iface_type = 69;
  bool apply_golden_iface_type = 1081;
  .SpaceX.API.Device.TxPowerLevel tx_power_level_2ghz = 70;
  bool apply_tx_power_level_2ghz = 1082;
  .SpaceX.API.Device.TxPowerLevel tx_power_level_5ghz = 71;
  bool apply_tx_power_level_5ghz = 1083;
  .SpaceX.API.Device.TxPowerLevel tx_power_level_5ghz_high = 72;
  bool apply_tx_power_level_5ghz_high = 1084;
  bool disable_pending_update_reboot = 73;
  bool apply_disable_pending_update_reboot = 1088;
  repeated .SpaceX.API.Device.ClientConfig client_configs = 74;
  bool apply_client_configs = 1089;
  bool disable_set_wifi_config_from_controller = 75;
  bool apply_disable_set_wifi_config_from_controller = 1090;
  bytes client_key = 76;
  bool apply_client_key = 1091;
  bool apply_wan_traffic_control = 1092;
  int32 wan_host_dscp_mark = 77;
  bool apply_wan_host_dscp_mark = 1093;
  uint32 tag = 78;
  oneof wan_traffic_control {
    .SpaceX.API.Device.NoTrafficControl wan_no_traffic_control = 4001;
    .SpaceX.API.Device.AckSuppression wan_ack_suppression = 4002;
    .SpaceX.API.Device.CakeRateLimit wan_cake_rate_limit = 4003;
  }
}
```
router


```
message MeshConfig {
  reserved 6;
  reserved 8;
  string display_name = 1;
  bool apply_display_name = 2;
  .SpaceX.API.Device.MeshAuth auth = 3;
  bool apply_auth = 4;
  int64 last_connected = 5;
  uint64 incarnation = 7;
  string hardware_version = 9;
  bool supports_5ghz_high = 10;
}

message TlsConfig {
  string key = 1;
  string cert = 2;
}

message HttpServer {
  string domain_name = 1;
  string pages_bundle_url = 101;
  optional .SpaceX.API.Device.TlsConfig tls = 2;
  optional string file_content_id = 3;
}

message CaptivePortal {
  string domain_name = 1;
  bool display_in_captive_browser = 2;
}

message WifiConfig {
  reserved "apply_enable_remote_ssh";
  reserved "apply_lan_ipv4";
  reserved "apply_network_name";
  reserved "apply_network_name_5ghz";
  reserved "apply_network_password";
  reserved "apply_wifi_security";
  reserved "enable_remote_ssh";
  reserved "lan_ipv4";
  reserved "last_remote_ssh_access";
  reserved "network_name";
  reserved "network_name_5ghz";
  reserved "network_password";
  reserved "wifi_security";
  reserved "local_landing_domain";
  reserved "apply_local_landing_domain";
  reserved "local_landing";
  reserved "apply_local_landing";
  reserved 1;
  reserved 2;
  reserved 4;
  reserved 5;
  reserved 6;
  reserved 8;
  reserved 10;
  reserved 11;
  reserved 14;
  reserved 15;
  reserved 16;
  reserved 17;
  reserved 18;
  reserved 21;
  reserved 24;
  reserved 25;
  reserved 27;
  reserved 28;
  reserved 29;
  reserved 32;
  reserved 34;
  reserved 35;
  reserved 36;
  reserved 37;
  reserved 38;
  reserved 40;
  reserved 41;
  reserved 1001;
  reserved 1002;
  reserved 1003;
  reserved 1004;
  reserved 1005;
  reserved 1006;
  reserved 1007;
  reserved 1008;
  reserved 1009;
  reserved 1011;
  reserved 1012;
  reserved 1015;
  reserved 1021;
  reserved 1041;
  reserved 1051;
  reserved 1052;
  reserved 1053;
  reserved 1056;
  reserved 1057;
  reserved 1102;
  reserved 1103;
  reserved 1104;
  reserved 1105;
  reserved 2001;
  reserved 2002;
  reserved 2003;
  reserved 2004;
  reserved 2005;
  reserved 2006;
  reserved 2007;
  reserved 2008;
  message MeshConfigsEntry {
    string key = 1;
    .SpaceX.API.Device.MeshConfig value = 2;
  }

  message MeshConfigsUpdatesEntry {
    string key = 1;
    .SpaceX.API.Device.MeshConfig value = 2;
  }

  message BasicServiceSet {
    reserved 1000;
    reserved 1001;
    reserved 1002;
    reserved 1004;
    reserved 1006;
    reserved 2000;
    reserved 1012;
    reserved 1014;
    reserved 1016;
    string bssid = 1003;
    string ssid = 1005;
    .SpaceX.API.Device.WifiConfig.Band band = 1011;
    string iface_name = 1017;
    bool disable = 1013;
    bool hidden = 1015;
    oneof auth {
      .SpaceX.API.Device.AuthOpen auth_open = 2001;
      .SpaceX.API.Device.AuthWpa2 auth_wpa2 = 2002;
      .SpaceX.API.Device.AuthWpa3 auth_wpa3 = 2003;
      .SpaceX.API.Device.AuthWpa2Wpa3 auth_wpa2_wpa3 = 2004;
      .SpaceX.API.Device.AuthRadius auth_radius = 2005;
    }
  }

  message Network {
    reserved "client_authorization_required";
    reserved "unauthorized_client_domain_allow_list";
    reserved 1000;
    reserved 1001;
    reserved 1002;
    reserved 1004;
    reserved 1005;
    reserved 1006;
    reserved 1018;
    reserved 1019;
    string ipv4 = 1003;
    uint32 dhcpv4_start = 1012;
    bool dhcp_disabled = 1015;
    uint32 dhcpv4_lease_duration_s = 1016;
    string domain = 1011;
    repeated .SpaceX.API.Device.WifiConfig.BasicServiceSet basic_service_sets = 1007;
    bool client_isolation = 1008;
    bool guest = 1009;
    string landing = 1010;
    bool landing_page_v2 = 1017;
    bool sandbox_enabled = 1020;
    repeated string sandbox_domain_allow_list = 1022;
    uint32 sandbox_id = 1023;
    bool internal = 1013;
    uint32 vlan = 1014;
    .SpaceX.API.Device.CaptivePortal captive_portal = 1024;
  }

  enum Security {
    UNKNOWN = 0;
    WPA2 = 1;
    WPA3 = 2;
    WPA2WPA3 = 3;
  }

  enum Band {
    RF_UNKNOWN = 0;
    RF_2GHZ = 2;
    RF_5GHZ = 5;
    RF_5GHZ_HIGH = 6;
  }

  enum WirelessMode {
    WIRELESS_MODE_DEFAULT = 0;
    A_ONLY = 1;
    B_ONLY = 2;
    G_ONLY = 3;
    N_ONLY = 4;
    B_G_MIXED = 5;
    A_N_MIXED = 6;
    G_N_MIXED = 7;
    B_G_N_MIXED = 8;
    A_AN_AC_MIXED = 9;
    AN_AC_MIXED = 10;
    B_G_N_AX_MIXED = 11;
    A_AN_AC_AX_MIXED = 12;
  }

  enum HTBandwidth {
    HT_BANDWIDTH_DEFAULT = 0;
    HT_BANDWIDTH_20_MHZ = 1;
    HT_BANDWIDTH_20_OR_40_MHZ = 2;
  }

  enum VHTBandwidth {
    VHT_BANDWIDTH_DEFAULT = 0;
    VHT_BANDWIDTH_DISABLED = 1;
    VHT_BANDWIDTH_80_MHZ = 2;
    VHT_BANDWIDTH_160_MHZ = 3;
    VHT_BANDWIDTH_80_PLUS_80_MHZ = 4;
  }

  string country_code = 3;
  bool apply_country_code = 1085;
  bool pin_country_code = 53;
  bool apply_pin_country_code = 1086;
  bool custom_power_table = 54;
  bool apply_custom_power_table = 1087;
  bool setup_complete = 7;
  bool apply_setup_complete = 1010;
  uint32 version = 9;
  string mac_wan = 12;
  string mac_lan = 13;
  uint32 channel_2ghz = 19;
  bool apply_channel_2ghz = 1013;
  uint32 channel_5ghz = 20;
  bool apply_channel_5ghz = 1014;
  uint32 channel_5ghz_high = 57;
  bool apply_channel_5ghz_high = 1016;
  repeated .SpaceX.API.Device.WifiConfig.MeshConfigsEntry mesh_configs = 33;
  repeated .SpaceX.API.Device.WifiConfig.MeshConfigsUpdatesEntry mesh_configs_updates = 3033;
  bool apply_mesh_configs = 1033;
  repeated .SpaceX.API.Device.PublicKey dynamic_keys = 22;
  bool apply_dynamic_keys = 39;
  bool is_repeater = 23;
  bool apply_is_repeater = 1031;
  bool ap_mode = 51;
  bool apply_ap_mode = 1066;
  bool is_aviation = 49;
  bool apply_is_aviation = 1064;
  int32 boot_count = 26;
  .SpaceX.API.Device.BootInfo boot = 3001;
  repeated string nameservers = 30;
  bool apply_nameservers = 1054;
  bool secure_dns = 50;
  bool apply_secure_dns = 1065;
  bool bypass_mode = 31;
  bool apply_bypass_mode = 1055;
  bool dfs_enabled = 42;
  bool apply_dfs_enabled = 1058;
  bool disable_mesh_onboarding = 52;
  bool apply_disable_mesh_onboarding = 1067;
  bool disable_wireless_mesh_onboarding = 1097;
  bool apply_disable_wireless_mesh_onboarding = 1098;
  bool apply_http_server = 1107;
  .SpaceX.API.Device.HttpServer http_server = 1108;
  repeated .SpaceX.API.Device.WifiConfig.Network networks = 1100;
  bool apply_networks = 1101;
  uint64 incarnation = 43;
  .SpaceX.API.Device.WifiConfig.WirelessMode wireless_mode_2ghz = 44;
  bool apply_wireless_mode_2ghz = 1059;
  .SpaceX.API.Device.WifiConfig.WirelessMode wireless_mode_5ghz = 45;
  bool apply_wireless_mode_5ghz = 1060;
  .SpaceX.API.Device.WifiConfig.WirelessMode wireless_mode_5ghz_high = 58;
  bool apply_wireless_mode_5ghz_high = 1070;
  .SpaceX.API.Device.WifiConfig.HTBandwidth ht_bandwidth_2ghz = 46;
  bool apply_ht_bandwidth_2ghz = 1061;
  .SpaceX.API.Device.WifiConfig.HTBandwidth ht_bandwidth_5ghz = 47;
  bool apply_ht_bandwidth_5ghz = 1062;
  .SpaceX.API.Device.WifiConfig.HTBandwidth ht_bandwidth_5ghz_high = 59;
  bool apply_ht_bandwidth_5ghz_high = 1071;
  .SpaceX.API.Device.WifiConfig.VHTBandwidth vht_bandwidth = 48;
  bool apply_vht_bandwidth = 1063;
  .SpaceX.API.Device.WifiConfig.VHTBandwidth vht_bandwidth_5ghz_high = 60;
  bool apply_vht_bandwidth_5ghz_high = 1072;
  bool use_public_services = 55;
  bool apply_use_public_services = 1068;
  bool disable_automated_speedtests = 56;
  bool apply_disable_automated_speedtests = 1069;
  bool enable_umbilical_vlan = 61;
  bool apply_enable_umbilical_vlan = 1073;
  repeated .SpaceX.API.Device.ClientName client_names = 62;
  bool apply_client_names = 1074;
  bool outdoor_mode = 63;
  bool apply_outdoor_mode = 1075;
  bool disable_2ghz = 64;
  bool apply_disable_2ghz = 1076;
  bool disable_5ghz = 65;
  bool apply_disable_5ghz = 1077;
  bool disable_5ghz_high = 66;
  bool apply_disable_5ghz_high = 1078;
  bool disable_x_mesh_backhaul = 67;
  bool apply_disable_x_mesh_backhaul = 1079;
  string golden_bssid = 68;
  bool apply_golden_bssid = 1080;
  .SpaceX.API.Device.IfaceType golden_iface_type = 69;
  bool apply_golden_iface_type = 1081;
  .SpaceX.API.Device.TxPowerLevel tx_power_level_2ghz = 70;
  bool apply_tx_power_level_2ghz = 1082;
  .SpaceX.API.Device.TxPowerLevel tx_power_level_5ghz = 71;
  bool apply_tx_power_level_5ghz = 1083;
  .SpaceX.API.Device.TxPowerLevel tx_power_level_5ghz_high = 72;
  bool apply_tx_power_level_5ghz_high = 1084;
  bool disable_pending_update_reboot = 73;
  bool apply_disable_pending_update_reboot = 1088;
  repeated .SpaceX.API.Device.ClientConfig client_configs = 74;
  bool apply_client_configs = 1089;
  bool disable_set_wifi_config_from_controller = 75;
  bool apply_disable_set_wifi_config_from_controller = 1090;
  bytes client_key = 76;
  bool apply_client_key = 1091;
  bool apply_wan_traffic_control = 1092;
  int32 wan_host_dscp_mark = 77;
  bool apply_wan_host_dscp_mark = 1093;
  bool debug_pop_pings = 79;
  bool apply_debug_pop_pings = 1095;
  bool debug_pings = 94;
  bool apply_debug_pings = 1106;
  bool client_tester = 80;
  bool apply_client_tester = 1096;
  uint32 asset_class = 81;
  bool apply_asset_class = 1099;
  uint32 tag = 78;
  oneof wan_traffic_control {
    .SpaceX.API.Device.NoTrafficControl wan_no_traffic_control = 4001;
    .SpaceX.API.Device.AckSuppression wan_ack_suppression = 4002;
    .SpaceX.API.Device.CakeRateLimit wan_cake_rate_limit = 4003;
  }
}
```
dishy

[[wifi_config.MeshConfig]]
[[wifi_config.AuthOpen]]
[[wifi_config.AuthWpa2]]
[[wifi_config.AuthWpa3]]
[[wifi_config.AuthWpa2Wpa3]]
[[wifi_config.AuthRadius]]
[[command.PublicKey]]
[[common.BootInfo]]
[[wifi_config.ClientName]]
[[wifi_util.IfaceType]]
[[wifi_util.TxPowerLevel]]
[[wifi_config.ClientConfig]]
[[wifi_config.NoTrafficControl]]
[[wifi_config.AckSuppression]]
[[wifi_config.CakeRateLimit]]
[[wifi_config.CaptivePortal]]
[[wifi_config.HttpServer]]

![[Pasted image 20241012214041.png]]
![[Pasted image 20241012214100.png]]
![[Pasted image 20241012214121.png]]
![[Pasted image 20241012214136.png]]
![[Pasted image 20241012214153.png]]
![[Pasted image 20241012214208.png]]
![[Pasted image 20241012214224.png]]
![[Pasted image 20241012214246.png]]
![[Pasted image 20241012214302.png]]




