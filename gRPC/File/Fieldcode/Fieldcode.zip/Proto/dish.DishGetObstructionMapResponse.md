```
message DishGetObstructionMapResponse {
  uint32 num_rows = 1;
  uint32 num_cols = 2;
  repeated float snr = 3;
  float min_elevation_deg = 4;
  float max_theta_deg = 5;
}
```
router


```
message DishGetObstructionMapResponse {
  uint32 num_rows = 1;
  uint32 num_cols = 2;
  repeated float snr = 3;
  float min_elevation_deg = 4;
  float max_theta_deg = 5;
  .SpaceX.API.Device.ObstructionMapReferenceFrame map_reference_frame = 6;
}
```
dishy

[[dish.ObstructionMapReferenceFrame]]






