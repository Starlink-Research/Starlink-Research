```
message ClientPlatform {
  enum Platform {
    UNKNOWN = 0;
    IOS = 1;
    ANDROID = 2;
    WEB = 3;
  }

  .SpaceX.API.Device.ClientPlatform.Platform platform = 1;
  float major_version = 2;
  float minor_version = 3;
}
```

![[Pasted image 20241012184315.png]]