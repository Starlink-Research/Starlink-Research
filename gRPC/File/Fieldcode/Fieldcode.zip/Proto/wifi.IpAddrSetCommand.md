```
message IpAddrSetCommand {
  string iface = 1;
  bool add = 2;
  string cidr = 3;
}
```


![[Pasted image 20241013141214.png]]


