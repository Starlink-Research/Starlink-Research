```
message PingTarget {
  string service = 1;
  string location = 2;
  string address = 3;
}
```


