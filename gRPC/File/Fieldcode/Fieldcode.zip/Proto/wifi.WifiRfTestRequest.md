```
message WifiRfTestRequest {
  uint32 num_measurements = 1;
  uint32 channel_2ghz = 2;
  uint32 channel_5ghz = 3;
  uint32 channel_5ghz_high = 4;
  uint32 mcs_2ghz = 5;
  uint32 mcs_5ghz = 6;
  uint32 mcs_5ghz_high = 7;
  uint32 phy_mode_2ghz = 8;
  uint32 phy_mode_5ghz = 9;
  uint32 phy_mode_5ghz_high = 10;
}
```
