```
message DishFactoryResetRequest {
}
```
