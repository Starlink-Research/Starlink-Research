```
message WifiAuthenticateResponse {
  .SpaceX.API.Device.ChallengeResponse wifi = 1;
  .SpaceX.API.Device.ChallengeResponse dish = 2;
}
```
[[common.ChallengeResponse]]


