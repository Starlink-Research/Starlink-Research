```
message GetDiagnosticsRequest {
}
```
