```
message SetTrustedKeysRequest {
  repeated .SpaceX.API.Device.PublicKey keys = 1;
}
```
[[command.PublicKey]]

![[Pasted image 20241012185006.png]]


