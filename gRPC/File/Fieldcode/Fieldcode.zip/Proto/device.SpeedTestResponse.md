```
message SpeedTestResponse {
  float download_bps = 1;
  float upload_bps = 2;
  float latency_s = 3;
  float download_mbps = 4;
  float upload_mbps = 5;
  float latency_ms = 6;
  .SpaceX.API.Device.SpeedTestStats router_speedtest = 15;
  float download_mbps_1_tcp_conn = 7;
  float upload_mbps_1_tcp_conn = 8;
  float download_mbps_4_tcp_conn = 9;
  float upload_mbps_4_tcp_conn = 10;
  float download_mbps_16_tcp_conn = 11;
  float upload_mbps_16_tcp_conn = 12;
  float download_mbps_64_tcp_conn = 13;
  float upload_mbps_64_tcp_conn = 14;
}
```

[[device.SpeedTestStats]]

