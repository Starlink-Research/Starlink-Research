```
message DishGetDataRequest {
  uint32 id = 1;
}
```
