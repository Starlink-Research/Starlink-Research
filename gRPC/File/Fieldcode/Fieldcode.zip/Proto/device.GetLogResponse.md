```
message GetLogResponse {
  message Logs {
    string syslog = 1;
    string dmesg = 2;
    string kernel_panic = 3;
    string mtk_eth_procs = 4;
  }

  .SpaceX.API.Device.GetLogResponse.Logs current = 4;
  .SpaceX.API.Device.GetLogResponse.Logs saved = 5;
  string syslog = 1;
  string offline_log = 2;
  string persistent_log = 3;
}
```
router


```
message GetLogResponse {
  message Logs {
    string syslog = 1;
    string dmesg = 2;
    string kernel_panic = 3;
    string mtk_eth_procs = 4;
    string debug_netsys_0sec = 5;
    string debug_netsys_2sec = 6;
  }

  .SpaceX.API.Device.GetLogResponse.Logs current = 4;
  .SpaceX.API.Device.GetLogResponse.Logs saved = 5;
  string syslog = 1;
  string offline_log = 2;
  string persistent_log = 3;
}
```
dishy
