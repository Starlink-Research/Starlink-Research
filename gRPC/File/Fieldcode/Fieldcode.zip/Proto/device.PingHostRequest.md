```
message PingHostRequest {
  string address = 3;
}
```
router


```
message PingHostRequest {
  string address = 3;
  uint32 size = 4;
}
```
dishy

![[Pasted image 20241012184850.png]]