```
message WifiSelfTestRequest {
}
```
