```
message GetNextIdResponse {
  uint64 id = 1;
  uint64 epoch_id = 2;
}
```



