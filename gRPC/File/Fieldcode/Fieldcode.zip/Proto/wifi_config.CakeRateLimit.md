```
message CakeRateLimit {
  uint32 host_mark = 1;
  float bandwidth = 2;
  .SpaceX.API.Device.CakePriorityQueueParameter priority_queue_parameter = 3;
  .SpaceX.API.Device.CakePriorityQueueParameter ack_filter = 4;
  float manual_rtt = 6;
}
```

[[wifi_config.CakePriorityQueueParameter]]


