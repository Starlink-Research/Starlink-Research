```
enum AttitudeEstimationState {
  FILTER_RESET = 0;
  FILTER_UNCONVERGED = 1;
  FILTER_CONVERGED = 2;
  FILTER_FAULTED = 3;
  FILTER_INVALID = 4;
}
```



