[[wifi.WifiSelfTestRequest]]

관련데이터
[[wifi.WifiSelfTestResponse]]

