```
message DeviceInfo {
  string id = 1;
  string hardware_version = 2;
  int32 board_rev = 14;
  string software_version = 3;
  string manufactured_version = 11;
  int64 generation_number = 12;
  string country_code = 4;
  int32 utc_offset_s = 5;
  bool software_partitions_equal = 6;
  bool is_dev = 7;
  int32 bootcount = 8;
  int32 anti_rollback_version = 9;
  bool is_hitl = 10;
  .SpaceX.API.Device.BootInfo boot = 1001;
  bool dish_cohoused = 13;
}
```

