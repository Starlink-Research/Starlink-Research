```
message AuthWpa2 {
  string password = 1;
}
```

