```
message DishActivateRssiScan {
  uint32 channel = 1;
}
```

