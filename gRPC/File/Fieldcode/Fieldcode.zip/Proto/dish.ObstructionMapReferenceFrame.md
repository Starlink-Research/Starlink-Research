```
enum ObstructionMapReferenceFrame {
  FRAME_UNKNOWN = 0;
  FRAME_EARTH = 1;
  FRAME_UT = 2;
}
```

