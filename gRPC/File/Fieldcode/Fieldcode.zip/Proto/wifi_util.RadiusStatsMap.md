```
message RadiusStatsMap {
  message RadiusStats {
    string iface_name = 1;
    uint32 timeout_count = 2;
    uint32 access_request_count = 3;
    uint32 access_accept_count = 4;
    uint32 access_reject_count = 5;
    uint32 access_challenge_count = 6;
    uint32 accounting_request_count = 7;
    uint32 accounting_response_count = 8;
  }

  message RadiusStatsEntry {
    string key = 1;
    .SpaceX.API.Device.RadiusStatsMap.RadiusStats value = 2;
  }

  repeated .SpaceX.API.Device.RadiusStatsMap.RadiusStatsEntry radius_stats = 1;
}
```
