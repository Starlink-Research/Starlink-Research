```
message DishReadyStates {
  bool cady = 1;
  bool scp = 2;
  bool l1l2 = 3;
  bool xphy = 4;
  bool aap = 5;
  bool rf = 6;
}
```

