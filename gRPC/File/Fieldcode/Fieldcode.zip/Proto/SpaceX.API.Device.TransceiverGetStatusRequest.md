[[transceiver.TransceiverGetStatusRequest]]

관련데이터
[[transceiver.TransceiverGetStatusResponse]]

