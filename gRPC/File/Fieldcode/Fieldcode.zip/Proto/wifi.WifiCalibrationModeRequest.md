```
message WifiCalibrationModeRequest {
}
```
