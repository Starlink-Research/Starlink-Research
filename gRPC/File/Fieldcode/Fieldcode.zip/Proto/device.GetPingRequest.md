```
message GetPingRequest {
}
```

