```
message TransceiverGetStatusRequest {
}
```

