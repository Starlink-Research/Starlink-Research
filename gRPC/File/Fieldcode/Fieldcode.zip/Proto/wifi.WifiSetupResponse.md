```
message WifiSetupResponse {
}
```
