```
message RunIperfServerRequest {
  uint32 duration_s = 1;
}
```
