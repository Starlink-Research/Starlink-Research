```
message WifiGuestInfoRequest {
}
```
