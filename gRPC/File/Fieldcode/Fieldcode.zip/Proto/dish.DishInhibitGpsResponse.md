```
message DishInhibitGpsResponse {
  bool inhibit_gps = 1;
}
```
