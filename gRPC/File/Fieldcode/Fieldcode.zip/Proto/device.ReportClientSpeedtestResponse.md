```
message ReportClientSpeedtestResponse {
}
```

