```
message SetTestModeRequest {
  enum RfMode {
    RX = 0;
    IDLE = 1;
    TX = 2;
    CAL = 3;
    USER = 4;
    NORMAL = 420;
  }

  .SpaceX.API.Device.SetTestModeRequest.RfMode rf_mode = 1;
  bool disable_loss_of_comm_fdir = 1001;
  bool enable_rules_override = 1002;
}
```


![[Pasted image 20241012194026.png]]
![[Pasted image 20241012194002.png]]

