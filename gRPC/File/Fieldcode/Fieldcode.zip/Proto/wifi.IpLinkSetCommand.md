```
message IpLinkSetCommand {
  string iface = 1;
  bool up = 2;
}
```

![[Pasted image 20241013141200.png]]
