```
message IwprivCommand {
  enum Ioctl {
    IOCTL_SET = 0;
    IOCTL_E2P = 1;
    IOCTL_MAC = 3;
    IOCTL_SX_ALLOW_5GHZ_HIGH = 4;
  }

  string iface = 1;
  string arg = 2;
  .SpaceX.API.Device.IwprivCommand.Ioctl ioctl = 3;
}
```

![[Pasted image 20241013141138.png]]

