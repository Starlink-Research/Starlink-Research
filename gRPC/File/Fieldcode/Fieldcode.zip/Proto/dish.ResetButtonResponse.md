```
message ResetButtonResponse {
}
```

