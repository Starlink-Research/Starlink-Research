```
message WifiGetConfigResponse {
  .SpaceX.API.Device.WifiConfig wifi_config = 1;
}
```
[[wifi_config.WifiConfig]]

