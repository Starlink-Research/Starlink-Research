```
message WifiGuestInfoResponse {
  bool is_guest = 1;
  bool is_online = 2;
  string router_hardware_version = 3;
  string dish_hardware_version = 4;
  bool is_router_aviation_conformed = 5;
}
```
