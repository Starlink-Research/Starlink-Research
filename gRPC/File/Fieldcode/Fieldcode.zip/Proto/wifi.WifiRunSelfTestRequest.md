```
message WifiRunSelfTestRequest {
}
```

