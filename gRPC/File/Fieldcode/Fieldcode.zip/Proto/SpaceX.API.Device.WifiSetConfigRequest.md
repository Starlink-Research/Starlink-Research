[[wifi.WifiSetConfigRequest]]

관련데이터
[[wifi.WifiSetConfigResponse]]

