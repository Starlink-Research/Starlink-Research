```
message SignedData {
  bytes data = 1;
  bytes signature = 2;
}
```

![[Pasted image 20241012184620.png]]