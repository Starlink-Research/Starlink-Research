```
message WifiGetPingMetricsResponse {
  .SpaceX.API.Device.PingMetrics internet = 1;
}
```
[[wifi.PingMetrics]]
