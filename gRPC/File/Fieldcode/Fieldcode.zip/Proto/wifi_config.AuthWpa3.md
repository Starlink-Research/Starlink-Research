```
message AuthWpa3 {
  string password = 1;
}
```


