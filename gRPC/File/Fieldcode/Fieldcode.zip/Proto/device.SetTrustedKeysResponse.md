```
message SetTrustedKeysResponse {
}
```

