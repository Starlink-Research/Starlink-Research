```
message WifiGetHistoryResponse {
  uint64 current = 1;
  repeated float ping_drop_rate = 1001;
  repeated float ping_latency_ms = 1002;
}
```
