```
message AuthOpen {
}
```

