```
message RebootResponse {
}
```

