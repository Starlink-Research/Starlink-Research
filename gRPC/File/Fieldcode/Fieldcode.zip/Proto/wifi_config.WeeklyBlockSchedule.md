```
message WeeklyBlockSchedule {
  message BlockRange {
    uint32 start_minutes = 1;
    uint32 end_minutes = 2;
  }

  repeated .SpaceX.API.Device.WeeklyBlockSchedule.BlockRange block_ranges = 1;
  string group_id = 2;
}
```

![[Pasted image 20241012214835.png]]

