```
message WifiFactoryTestCommandRequest {
  oneof command {
    .SpaceX.API.Device.IwprivCommand iwpriv_command = 1;
    .SpaceX.API.Device.IpLinkSetCommand ip_link_set_command = 2;
    .SpaceX.API.Device.IpAddrSetCommand ip_addr_set_command = 3;
  }
}
```
[[wifi.IwprivCommand]]
[[wifi.IpLinkSetCommand]]
[[wifi.IpAddrSetCommand]]

![[Pasted image 20241013141233.png]]

