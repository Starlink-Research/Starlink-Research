```
message WifiSetClientGivenNameRequest {
  .SpaceX.API.Device.ClientName client_name = 1;
  .SpaceX.API.Device.ClientConfig client_config = 2;
}
```
[[wifi_config.ClientName]]
[[wifi_config.ClientConfig]]

