```
message ReportClientSpeedtestRequest {
  uint32 id = 1;
  .SpaceX.API.Device.SpeedTestStats client_speedtest = 2;
  .SpaceX.API.Device.SpeedTestStats wifi_speedtest = 5;
  float client_rssi = 3;
  .SpaceX.API.Device.ClientPlatform client_platform = 4;
  string app_version = 6;
  uint32 app_build = 7;
}
```
[[device.SpeedTestStats]]
[[device.ClientPlatform]]


![[Pasted image 20241012192841.png]]


