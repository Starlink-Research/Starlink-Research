```
message DishGetObstructionMapRequest {
}
```

