```
message TransceiverGetTelemetryRequest {
}
```
