```
message DishAuthenticateResponse {
  .SpaceX.API.Device.ChallengeResponse dish = 2;
}
```
[[common.ChallengeResponse]]



