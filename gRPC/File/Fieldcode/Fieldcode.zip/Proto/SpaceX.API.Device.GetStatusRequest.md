[[device.GetStatusRequest]]
\

관련데이터
[[dish.DishGetStatusResponse]]

[[wifi.WifiGetStatusResponse]]


