```
message PingResult {
  .SpaceX.API.Device.PingTarget target = 3;
  float dropRate = 1;
  float latencyMs = 2;
}
```

[[common.PingTarget]]

