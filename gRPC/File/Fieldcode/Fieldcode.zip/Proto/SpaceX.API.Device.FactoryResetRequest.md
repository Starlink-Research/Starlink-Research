
[[device.FactoryResetRequest]]

관련데이터
[[device.FactoryResetResponse]]
