```
message DishGetConfigResponse {
  .SpaceX.API.Device.DishConfig dish_config = 1;
}
```
[[dish_config.DishConfig]]
