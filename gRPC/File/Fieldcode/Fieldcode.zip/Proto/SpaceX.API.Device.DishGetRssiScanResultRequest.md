[[dish.DishGetRssiScanResultRequest]]

관련데이터
[[dish.DishGetRssiScanResultResponse]]

