```
message GetRadioStatsResponse {
  repeated .SpaceX.API.Device.RadioStats radio_stats = 1;
}
```
[[wifi.RadioStats]]
