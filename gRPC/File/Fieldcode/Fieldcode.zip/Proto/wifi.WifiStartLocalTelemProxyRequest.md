```
message WifiStartLocalTelemProxyRequest {
  int32 port = 1;
}
```
