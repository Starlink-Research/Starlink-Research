```
enum TransceiverModulatorState {
  MODSTATE_UNKNOWN = 0;
  MODSTATE_ENABLED = 1;
  MODSTATE_DISABLED = 2;
}
```

