```
message TransceiverIFLoopbackTestRequest {
  bool enable_if_loopback = 1;
}
```
