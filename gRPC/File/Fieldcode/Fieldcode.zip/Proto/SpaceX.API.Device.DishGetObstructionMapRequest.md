[[dish.DishGetObstructionMapRequest]]

관련데이터
[[dish.DishGetObstructionMapResponse]]

