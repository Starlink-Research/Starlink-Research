```
message GetNextIdRequest {
}
```


