```
message DishGetConfigRequest {
}
```
