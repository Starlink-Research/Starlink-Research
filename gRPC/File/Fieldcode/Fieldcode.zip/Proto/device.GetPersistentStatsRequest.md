```
message GetPersistentStatsRequest {
}
```



