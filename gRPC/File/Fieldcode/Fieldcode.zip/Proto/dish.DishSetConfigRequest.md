```
message DishSetConfigRequest {
  .SpaceX.API.Device.DishConfig dish_config = 1;
}
```
[[dish_config.DishConfig]]

![[Pasted image 20241012210742.png]]

