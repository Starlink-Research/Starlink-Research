```
message GetRadioStatsRequest {
}
```

