[[device.StartSpeedtestRequest]]

관련데이터
[[device.StartSpeedtestResponse]]

