```
message DishSetEmcResponse {
}
```
