```
message AuthenticateRequest {
  .SpaceX.API.Device.SignedData challenge = 1;
}
```

[[common.SignedData]]

![[Pasted image 20241012184717.png]]