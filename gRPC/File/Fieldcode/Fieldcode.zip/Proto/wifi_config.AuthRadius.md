```
message AuthRadius {
  string server = 1;
  string server_ca = 3;
  string server_ca_base_64 = 4;
  string password = 2;
}
```
router


```
message AuthRadius {
  string server = 1;
  string server_ca = 3;
  string server_ca_base_64 = 4;
  string password = 2;
  .SpaceX.API.Device.Protocol transport = 5;
}
```
dishy

[[wifi_util.Protocol]]


