```
message DishGetEmcRequest {
}
```
