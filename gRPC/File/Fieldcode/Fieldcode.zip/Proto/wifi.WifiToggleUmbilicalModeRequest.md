```
message WifiToggleUmbilicalModeRequest {
  bool enable = 1;
}
```

