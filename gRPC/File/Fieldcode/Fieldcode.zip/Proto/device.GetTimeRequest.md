```
message GetTimeRequest {
}
```

