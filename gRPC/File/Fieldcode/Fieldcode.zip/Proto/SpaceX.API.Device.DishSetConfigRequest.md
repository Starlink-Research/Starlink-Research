[[dish.DishSetConfigRequest]]

관련데이터
[[dish.DishSetConfigResponse]]

