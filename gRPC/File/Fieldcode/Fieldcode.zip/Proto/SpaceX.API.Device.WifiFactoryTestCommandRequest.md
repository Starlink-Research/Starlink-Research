[[wifi.WifiFactoryTestCommandRequest]]

관련데이터
[[wifi.WifiFactoryTestCommandRespons]]

