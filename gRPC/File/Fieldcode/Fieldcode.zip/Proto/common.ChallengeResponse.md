```
message ChallengeResponse {
  bytes signature = 1;
  bytes certificate_chain = 2;
}
```


