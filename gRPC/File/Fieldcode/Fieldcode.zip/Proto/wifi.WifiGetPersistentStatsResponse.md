```
message WifiGetPersistentStatsResponse {
  .SpaceX.API.Device.WifiPersistentStats stats = 1;
}
```
[[wifi.WifiPersistentStats]]

