[[wifi.WifiGetFirewallRequest]]

관련데이터
[[wifi.WifiGetFirewallResponse]]

