```
message ClientName {
  string mac_address = 1;
  string given_name = 2;
}
```

![[Pasted image 20241012214713.png]]

