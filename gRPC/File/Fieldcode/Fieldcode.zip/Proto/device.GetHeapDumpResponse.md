```
message GetHeapDumpResponse {
  string heap_dump = 1;
}
```

