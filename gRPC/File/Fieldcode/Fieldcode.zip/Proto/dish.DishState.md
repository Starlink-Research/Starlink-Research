```
enum DishState {
  UNKNOWN = 0;
  CONNECTED = 1;
  SEARCHING = 2;
  BOOTING = 3;
}
```
