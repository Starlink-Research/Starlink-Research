```
message GetLocationResponse {
  reserved "ecef";
  reserved 2;
  .SpaceX.API.Device.LLAPosition lla = 1;
  double sigma_m = 4;
  .SpaceX.API.Device.PositionSource source = 3;
}
```

[[common.LLAPosition]]
[[device.PositionSource]]

