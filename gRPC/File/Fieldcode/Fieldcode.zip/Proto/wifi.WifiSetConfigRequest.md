```
message WifiSetConfigRequest {
  .SpaceX.API.Device.WifiConfig wifi_config = 1;
}
```
[[wifi_config.WifiConfig]]

![[Pasted image 20241012213947.png]]

