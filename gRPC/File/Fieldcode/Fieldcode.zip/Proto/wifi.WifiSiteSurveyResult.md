```
message WifiSiteSurveyResult {
  float rssi = 1;
  uint32 channel = 2;
  string ssid = 3;
  .SpaceX.API.Device.WifiSecurity security = 4;
  .SpaceX.API.Device.WifiMode wireless_mode = 5;
  .SpaceX.API.Device.IfaceType iface = 6;
  string mac_address = 7;
  float est_rx_rate = 8;
}
```

[[wifi_util.WifiSecurity]]
[[wifi_util.WifiMode]]
[[wifi_util.IfaceType]]

