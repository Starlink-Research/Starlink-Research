```
message DishGetContextRequest {
}
```
