```
message WifiGetClientsResponse {
  repeated .SpaceX.API.Device.WifiClient clients = 1;
  bool has_client_index = 2;
  int32 client_index = 3;
}
```
[[wifi.WifiClient]]
