```
message SpeedtestStatus {
  message Direction {
    repeated float throughputs_mbps = 1;
    .SpaceX.API.Device.SpeedtestError err = 2;
  }

  bool running = 1;
  uint32 id = 2;
  .SpaceX.API.Device.SpeedtestStatus.Direction up = 1000;
  .SpaceX.API.Device.SpeedtestStatus.Direction down = 1001;
}
```

[[device.SpeedtestError]]
