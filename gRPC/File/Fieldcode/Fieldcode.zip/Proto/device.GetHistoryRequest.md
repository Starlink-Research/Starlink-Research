```
message GetHistoryRequest {
}
```

