```
message GetSpeedtestStatusRequest {
}
```





