```
message WifiGetFirewallRequest {
}
```
