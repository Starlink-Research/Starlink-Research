```
message WifiSetMeshDeviceTrustRequest {
  string device_id = 1;
  .SpaceX.API.Device.MeshAuth auth = 2;
}
```
[[wifi_config.MeshAuth]]

