```
message AckSuppression {
  uint32 ack_mark = 1;
  float htb_ack_queue_rate = 2;
  float htb_ack_queue_ceil = 3;
  float cake_queue_bandwidth = 4;
  bool cake_ack_filter_aggressive = 5;
  float cake_manual_rtt = 6;
}
```


