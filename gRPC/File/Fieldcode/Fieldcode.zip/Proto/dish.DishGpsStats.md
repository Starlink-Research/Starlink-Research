```
message DishGpsStats {
  bool gps_valid = 1;
  uint32 gps_sats = 2;
  bool no_sats_after_ttff = 3;
  bool inhibit_gps = 4;
}
```

