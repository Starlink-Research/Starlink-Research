```
message DishSetMaxPowerTestModeResponse {
  bool enabled = 1;
}
```

