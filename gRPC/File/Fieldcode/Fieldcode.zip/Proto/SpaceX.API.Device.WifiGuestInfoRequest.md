[[wifi.WifiGuestInfoRequest]]

관련데이터
[[wifi.WifiGuestInfoResponse]]

