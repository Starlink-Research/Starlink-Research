```
message DishPrioritizedUpdateResponse {
  bool prioritized = 1;
}
```
