```
message DishGetRssiScanResult {
  bool success = 1;
  uint32 channel = 2;
  uint64 request_timestamp = 3;
  uint32 number_samples = 4;
  repeated .SpaceX.API.Device.RssiEntry rssi_scan_points = 5;
}
```

[[rssi_scan.RssiEntry]]

