Field_code: 1038
hex_data: 0000000003f24000

## 형식
![[Pasted image 20241012204152.png]]
[[SpaceX.API.Device.RunIperfServerRequest]]



## 요청정보
- 데이터 없을때
```
{
  "runIperfServer": {}
}
```

- 데이터 있을때
```
{
  "runIperfServer": {
    "durationS": 0
  }
}
```
[[device.RunIperfServerRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_RunIperfServer
[[device.RunIperfServerResponse]]



