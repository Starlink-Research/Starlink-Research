Field_code: 2002
hex_data: 0000000003927d00

## 형식
![[Pasted image 20241012204404.png]]
[[SpaceX.API.Device.DishStowRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishStow": {}
}
```

- 데이터 있을때
```
{
  "dishStow": {
    "unstow": false
  }
}
```
[[dish.DishStowRequest]]



## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "25",
  "dish_stow": {}
}
```
[[dish.DishStowResponse]]



