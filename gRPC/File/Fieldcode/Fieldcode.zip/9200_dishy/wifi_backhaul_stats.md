Field_code: 3029
hex_data: 0000000004AABD0100


## 형식

[[SpaceX.API.Device.WifiBackhaulStatsRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishActivateRssiScan": {}
}
```

- 데이터 있을때
```

```
[[wifi.WifiBackhaulStatsRequest]]


## 응답정보

[[wifi.WifiBackhaulStatsResponse]]



