Field_code: 1029
hex_data: 0000000003aa4000

## 형식
![[Pasted image 20241012192749.png]]
[[SpaceX.API.Device.ReportClientSpeedtestRequest]]



## 요청정보
- 데이터 없을때
```
{
  "reportClientSpeedtest": {}
}
```

- 데이터 있을때
```
{
  "reportClientSpeedtest": {
    "id": 0,
    "clientSpeedtest": {
      "latencyMs": 0,
      "startTime": "0",
      "uploadStartTime": "0",
      "downloadStartTime": "0",
      "uploadMbps": 0,
      "target": "UNKNOWN",
      "downloadMbps": 0,
      "tcpStreams": 0
    },
    "wifiSpeedtest": {
      "latencyMs": 0,
      "startTime": "0",
      "uploadStartTime": "0",
      "downloadStartTime": "0",
      "uploadMbps": 0,
      "downloadMbps": 0,
      "target": "UNKNOWN",
      "tcpStreams": 0
    },
    "clientRssi": 0,
    "clientPlatform": {
      "platform": "UNKNOWN",
      "majorVersion": 0,
      "minorVersion": 0
    },
    "appVersion": "A",
    "appBuild": 0
  }
}
```
[[device.ReportClientSpeedtestRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_ReportClientSpeedtest
[[device.ReportClientSpeedtestResponse]]


