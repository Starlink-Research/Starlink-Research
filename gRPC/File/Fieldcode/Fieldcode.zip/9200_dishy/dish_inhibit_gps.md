Field_code: 2014
hex_data: 0000000003f27d00

## 형식
![[Pasted image 20241012211944.png]]
[[SpaceX.API.Device.DishInhibitGpsRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishInhibitGps": {}
}
```

- 데이터 있을때
```
{
  "dishInhibitGps": {
    "inhibitGps": true
  }
}
```
[[dish.DishInhibitGpsRequest]]



## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "25",
  "dish_inhibit_gps": {
    "inhibit_gps": false
  }
}
```
[[dish.DishInhibitGpsResponse]]



