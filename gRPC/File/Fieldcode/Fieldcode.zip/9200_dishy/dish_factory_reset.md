Field_code: 2021
hex_data: 0000000003AA7E00

## 형식
![[Pasted image 20241013154706.png]]
[[SpaceX.API.Device.DishFactoryResetRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishFactoryReset": {}
}
```
[[dish.DishFactoryResetRequest]]


## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "25",
  "dish_factory_reset": {}
}
```
[[dish.DishFactoryResetResponse]]


