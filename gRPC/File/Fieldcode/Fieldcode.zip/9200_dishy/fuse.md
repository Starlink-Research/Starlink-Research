Field_code: 1021
hex_data: 0000000003ea3f00

## 형식
![[Pasted image 20241012191130.png]]
[[SpaceX.API.Device.FuseRequest]]



## 요청정보
- 데이터 없을때
```
{
  "fuse": {}
}
```

- 데이터 있을때
```
{
  "fuse": {
    "preventReboot": true
  }
}
```
[[device.FuseRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_Fuse
[[device.FuseResponse]]


