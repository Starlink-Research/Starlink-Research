Field_code: 1040
hex_data: 0000000003824100

## 형식
![[Pasted image 20241013152114.png]]
[[SpaceX.API.Device.UdpConnectivityTestRequest]]




## 요청정보
- 데이터 없을때
```
{
  "udpConnectivityTest": {}
}
```

- 데이터 있을때
```
{
  "udpConnectivityTest": {
    "target": "192.168.1.1",
    "port": 9000,
    "probeData": "EMPTY"
  }
}
```
[[device.UdpConnectivityTestRequest]]




## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_UdpConnectivityTest




