Field_code: 2019
hex_data: 0000000003A27E00

## 형식
![[Pasted image 20241013154501.png]]
[[SpaceX.API.Device.DishGetRssiScanResultRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishGetRssiScanResult": {}
}
```
[[dish.DishGetRssiScanResultRequest]]


## 응답정보
- PermissionDenied (7)
- Permission denied
[[dish.DishGetRssiScanResultResponse]]



