Field_code: 1023
hex_data: 0000000003f23f00

## 형식
![[Pasted image 20241012192035.png]]
[[SpaceX.API.Device.GetConnectionsRequest]]



## 요청정보
- 데이터 없을때
```
{
  "getConnections": {}
}
```
[[device.GetConnectionsRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_GetConnections
[[device.GetConnectionsResponse]]



