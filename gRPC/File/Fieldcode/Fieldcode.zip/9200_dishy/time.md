Field_code: 1037
hex_data: 0000000003ea4000

## 형식
![[Pasted image 20241012195606.png]]
[[SpaceX.API.Device.GetTimeRequest]]



## 요청정보
- 데이터 없을때
```
{
  "time": {}
}
```
[[device.GetTimeRequest]]



## 응답정보
- PermissionDenied (7)
- Permission denied
[[device.GetTimeResponse]]


