Field_code: 3018
hex_data: 0000000004d2bc0100

## 형식
![[Pasted image 20241013135738.png]]
[[SpaceX.API.Device.WifiSelfTestRequest]]



## 요청정보
- 데이터 없을때
```
{
  "wifiSelfTest": {}
}
```
[[wifi.WifiSelfTestRequest]]


## 응답정보
- Unimplemented (12)
[[wifi.WifiSelfTestResponse]]


