Field_code: 2013
hex_data: 0000000003ea7d00

## 형식
![[Pasted image 20241012211709.png]]
[[SpaceX.API.Device.DishPowerSaveRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishPowerSave": {}
}
```

- 데이터 있을때
```
{
  "dishPowerSave": {
    "powerSaveStartMinutes": 0,
    "powerSaveDurationMinutes": 0,
    "enablePowerSave": false
  }
}
```
[[device.DishPowerSaveRequest]]



## 응답정보
```
{
  "id": "0",
  "status": {
    "code": 0,
    "message": ""
  },
  "api_version": "25"
}
```




