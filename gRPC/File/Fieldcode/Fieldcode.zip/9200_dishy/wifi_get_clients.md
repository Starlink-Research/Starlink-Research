Field_code: 3002
hex_data: 0000000004d2bb0100

## 형식
![[Pasted image 20241012213135.png]]
[[SpaceX.API.Device.WifiGetClientsRequest]]



## 요청정보
- 데이터 없을때
```
{
  "wifiGetClients": {}
}
```
[[wifi.WifiGetClientsRequest]]


## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_WifiGetClients
[[wifi.WifiGetClientsResponse]]

