Field_code: 1004
hex_data: 0000000003E23E00

## 형식
![[Pasted image 20241012165254.png]]
[[SpaceX.API.Device.GetStatusRequest]]



## 요청정보
- 데이터 없을때
```
{
  "getStatus": {}
}
```
[[device.GetStatusRequest]]



## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "25",
  "dish_get_status": {
    "device_info": {
      "id": "ut01000000-00000000-00df1780",
      "hardware_version": "rev4_prod3",
      "software_version": "dc6da6f2-7a98-4cdf-9372-80359e046af9.uterm_manifest.release",
      "country_code": "",
      "utc_offset_s": 0,
      "software_partitions_equal": false,
      "is_dev": false,
      "bootcount": 102,
      "anti_rollback_version": 0,
      "is_hitl": false,
      "manufactured_version": "",
      "generation_number": "1726524354",
      "dish_cohoused": false,
      "board_rev": 0,
      "boot": null
    },
    "device_state": {
      "uptime_s": "1251"
    },
    "seconds_to_first_nonempty_slot": -1,
    "pop_ping_drop_rate": 1,
    "obstruction_stats": {
      "fraction_obstructed": 0,
      "valid_s": 0,
      "currently_obstructed": false,
      "avg_prolonged_obstruction_duration_s": 0,
      "avg_prolonged_obstruction_interval_s": "NaN",
      "avg_prolonged_obstruction_valid": false,
      "time_obstructed": 0,
      "patches_valid": 0
    },
    "alerts": {
      "motors_stuck": false,
      "thermal_shutdown": false,
      "thermal_throttle": false,
      "unexpected_location": false,
      "mast_not_near_vertical": false,
      "slow_ethernet_speeds": false,
      "roaming": false,
      "install_pending": false,
      "is_heating": false,
      "power_supply_thermal_throttle": false,
      "is_power_save_idle": false,
      "moving_while_not_mobile": false,
      "dbf_telem_stale": false,
      "moving_too_fast_for_policy": false,
      "low_motor_current": false,
      "lower_signal_than_predicted": false,
      "slow_ethernet_speeds_100": false,
      "obstruction_map_reset": false
    },
    "downlink_throughput_bps": 0,
    "uplink_throughput_bps": 12037.652,
    "pop_ping_latency_ms": -1,
    "stow_requested": false,
    "boresight_azimuth_deg": 0,
    "boresight_elevation_deg": 0,
    "outage": {
      "cause": "BOOTING",
      "start_timestamp_ns": "-1",
      "duration_ns": "0",
      "did_switch": false
    },
    "gps_stats": {
      "gps_valid": false,
      "gps_sats": 0,
      "no_sats_after_ttff": false,
      "inhibit_gps": false
    },
    "eth_speed_mbps": 1000,
    "mobility_class": "STATIONARY",
    "is_snr_above_noise_floor": false,
    "ready_states": {
      "cady": false,
      "scp": true,
      "l1l2": true,
      "xphy": true,
      "aap": true,
      "rf": true
    },
    "class_of_service": "UNKNOWN_USER_CLASS_OF_SERVICE",
    "software_update_state": "IDLE",
    "is_snr_persistently_low": false,
    "has_actuators": "HAS_ACTUATORS_NO",
    "disablement_code": "UNKNOWN_STATE",
    "has_signed_cals": true,
    "software_update_stats": {
      "software_update_state": "IDLE",
      "software_update_progress": 0,
      "update_requires_reboot": false
    },
    "alignment_stats": {
      "has_actuators": "HAS_ACTUATORS_NO",
      "actuator_state": "ACTUATOR_STATE_IDLE",
      "tilt_angle_deg": 18.072042,
      "boresight_azimuth_deg": 0,
      "boresight_elevation_deg": 0,
      "attitude_estimation_state": "FILTER_RESET",
      "attitude_uncertainty_deg": 51.756836,
      "desired_boresight_azimuth_deg": 0,
      "desired_boresight_elevation_deg": 0
    },
    "initialization_duration_seconds": {
      "attitude_initialization": 0,
      "burst_detected": 0,
      "ekf_converged": 0,
      "first_cplane": -1,
      "first_pop_ping": -1,
      "gps_valid": 0,
      "initial_network_entry": 0,
      "network_schedule": 0,
      "rf_ready": 36,
      "stable_connection": 1
    },
    "is_cell_disabled": false,
    "swupdate_reboot_ready": false,
    "seconds_until_swupdate_reboot_possible": -1,
    "reboot_reason": "REBOOT_REASON_NONE",
    "high_power_test_mode": false,
    "connected_routers": [
      "Router-010000000000000000CEF48F"
    ],
    "config": {
      "snow_melt_mode": "AUTO",
      "location_request_mode": "NONE",
      "level_dish_mode": "TILT_LIKE_NORMAL",
      "power_save_start_minutes": 0,
      "power_save_duration_minutes": 0,
      "power_save_mode": false,
      "swupdate_three_day_deferral_enabled": false,
      "asset_class": 0,
      "apply_snow_melt_mode": true,
      "apply_location_request_mode": true,
      "apply_level_dish_mode": true,
      "apply_power_save_start_minutes": true,
      "apply_power_save_duration_minutes": true,
      "apply_power_save_mode": true,
      "apply_swupdate_three_day_deferral_enabled": true,
      "apply_asset_class": true
    }
  }
}
```
[[dish.DishGetStatusResponse]]





