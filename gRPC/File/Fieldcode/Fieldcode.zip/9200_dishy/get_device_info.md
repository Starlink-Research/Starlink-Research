Field_code: 1008
hex_data: 0000000003823f00

## 형식
![[Pasted image 20241012162033.png]]
[[SpaceX.API.Device.GetDeviceInfoRequest]]



## 요청정보
- 데이터 없을때
```
{
  "getDeviceInfo": {}
}
```
[[device.GetDeviceInfoRequest]]



## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "25",
  "get_device_info": {
    "device_info": {
      "id": "ut01000000-00000000-00df1780",
      "hardware_version": "rev4_prod3",
      "software_version": "dc6da6f2-7a98-4cdf-9372-80359e046af9.uterm_manifest.release",
      "country_code": "",
      "utc_offset_s": 0,
      "software_partitions_equal": false,
      "is_dev": false,
      "bootcount": 102,
      "anti_rollback_version": 0,
      "is_hitl": false,
      "manufactured_version": "",
      "generation_number": "1726524354",
      "dish_cohoused": false,
      "board_rev": 0,
      "boot": null
    }
  }
}
```
[[device.GetDeviceInfoResponse]]


