Field_code: 2022
hex_data: 0000000003B27E00

## 형식
![[Pasted image 20241013154937.png]]
[[SpaceX.API.Device.ResetButtonRequest]]



## 요청정보
- 데이터 없을때
```
{
  "resetButton": {
    "pressed": true
  }
}
```
[[dish.ResetButtonRequest]]



## 응답정보
- PermissionDenied (7)
- Permission denied
[[dish.ResetButtonResponse]]


