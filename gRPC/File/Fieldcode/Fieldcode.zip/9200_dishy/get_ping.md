Field_code: 1009
hex_data: 00000000038a3f00

## 형식
![[Pasted image 20241012164509.png]]
[[SpaceX.API.Device.GetPingRequest]]



## 요청정보
- 데이터 없을때
```
{
  "getPing": {}
}
```
[[device.GetPingRequest]]



## 응답정보
Unimplemented (12)
Unimplemented: *device.Request_GetPing
[[device.GetPingResponse]]


