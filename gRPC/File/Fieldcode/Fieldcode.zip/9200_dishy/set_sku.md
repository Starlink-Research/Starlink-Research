Field_code: 1013
hex_data: 0000000003aa3f00

## 형식
![[Pasted image 20241012182910.png]]
[[SpaceX.API.Device.SetSkuRequest]]



## 요청정보
- 데이터 없을때
```
{
  "setSku": {}
}
```

- 데이터 있을때
```
{
  "setSku": {
    "sku": "a",
    "countryCode": "aa",
    "applyCountryCode": true,
    "pinCountryCode": true,
    "customPowerTable": false
  }
}
```
[[device.SetSkuRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_SetSku
[[device.SetSkuResponse]]
