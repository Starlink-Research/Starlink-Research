Field_code: 1015
hex_data: 0000000003ba3f00

## 형식
![[Pasted image 20241012164136.png]]
[[SpaceX.API.Device.GetNetworkInterfacesRequest]]



## 요청정보
- 데이터 없을때
```
{
  "getNetworkInterfaces": {}
}
```
[[device.GetNetworkInterfacesRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_GetNetworkInterfaces
[[device.GetNetworkInterfacesResponse]]


