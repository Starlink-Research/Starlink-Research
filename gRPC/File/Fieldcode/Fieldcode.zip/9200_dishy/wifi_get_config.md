Field_code: 3009
hex_data: 00000000048abc0100

## 형식
![[Pasted image 20241012215554.png]]
[[SpaceX.API.Device.WifiGetConfigRequest]]



## 요청정보
- 데이터 없을때
```
{
  "wifiGetConfig": {}
}
```
[[wifi.WifiGetConfigRequest]]


## 응답정보
- Unimplemented (12)
[[wifi.WifiGetConfigResponse]]

