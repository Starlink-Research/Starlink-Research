Field_code: 3030
hex_data: 0000000004B2BD0100

## 형식

[[SpaceX.API.Device.WifiToggleUmbilicalModeRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishActivateRssiScan": {}
}
```

- 데이터 있을때
```

```
[[wifi.WifiToggleUmbilicalModeRequest]]


## 응답정보
- PermissionDenied (7)
- Permission denied



