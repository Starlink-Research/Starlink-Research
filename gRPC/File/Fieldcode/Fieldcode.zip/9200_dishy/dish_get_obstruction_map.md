Field_code: 2008
hex_data: 0000000003c27d00

## 형식
![[Pasted image 20241012205802.png]]
[[SpaceX.API.Device.DishGetObstructionMapRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishGetObstructionMap": {}
}
```
[[dish.DishGetObstructionMapRequest]]


## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "25",
  "dish_get_obstruction_map": {
    "num_rows": 1,
    "num_cols": 1,
    "snr": [
      -1
    ],
    "min_elevation_deg": 0,
    "max_theta_deg": 90,
    "map_reference_frame": "FRAME_UNKNOWN"
  }
}
```
[[dish.DishGetObstructionMapResponse]]

