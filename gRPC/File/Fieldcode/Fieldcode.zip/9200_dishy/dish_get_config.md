Field_code: 2011
hex_data: 0000000003da7d00

## 형식
![[Pasted image 20241012211428.png]]
[[SpaceX.API.Device.DishGetConfigRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishGetConfig": {}
}
```
[[dish.DishGetConfigRequest]]


## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "25",
  "dish_get_config": {
    "dish_config": {
      "snow_melt_mode": "AUTO",
      "location_request_mode": "NONE",
      "level_dish_mode": "TILT_LIKE_NORMAL",
      "power_save_start_minutes": 0,
      "power_save_duration_minutes": 0,
      "power_save_mode": false,
      "swupdate_three_day_deferral_enabled": false,
      "asset_class": 0,
      "apply_snow_melt_mode": true,
      "apply_location_request_mode": true,
      "apply_level_dish_mode": true,
      "apply_power_save_start_minutes": true,
      "apply_power_save_duration_minutes": true,
      "apply_power_save_mode": true,
      "apply_swupdate_three_day_deferral_enabled": true,
      "apply_asset_class": true
    }
  }
}
```
[[dish.DishGetConfigResponse]]

