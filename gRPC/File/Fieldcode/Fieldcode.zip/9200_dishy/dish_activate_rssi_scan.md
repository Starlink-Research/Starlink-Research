Field_code: 2019
hex_data: 00000000039A7E00

## 형식
![[Pasted image 20241013154205.png]]
[[SpaceX.API.Device.DishActivateRssiScanRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishActivateRssiScan": {}
}
```

- 데이터 있을때
```
{
  "dishActivateRssiScan": {
    "scanQuery": {
      "channel": 0
    }
  }
}
```
[[dish.DishActivateRssiScanRequest]]


## 응답정보
- PermissionDenied (7)
- Permission denied
[[dish.DishActivateRssiScanResponse]]



