Field_code: 5000
hex_data: 0000000004c2b80200

## 형식
![[Pasted image 20241013141805.png]]
[[SpaceX.API.Device.Services.Unlock.StartUnlockRequest]]


## 요청정보
- 데이터 없을때
```
{
  "startUnlock": {}
}
```
[[service.StartUnlockRequest]]



## 응답정보
- Unimplemented (12) 
[[service.StartUnlockResponse]]


