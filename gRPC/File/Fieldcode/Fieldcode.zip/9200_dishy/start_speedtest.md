Field_code: 1027
hex_data: 00000000039a4000

## 형식
![[Pasted image 20241012192248.png]]
[[SpaceX.API.Device.StartSpeedtestRequest]]



## 요청정보
- 데이터 없을때
```
{
  "startSpeedtest": {}
}
```
[[device.StartSpeedtestRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_StartSpeedtest
[[device.StartSpeedtestResponse]]



