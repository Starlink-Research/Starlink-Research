Field_code: 3015
hex_data: 0000000004babc0100

## 형식
![[Pasted image 20241013135404.png]]
[[SpaceX.API.Device.WifiGetClientHistoryRequest]]



## 요청정보
- 데이터 없을때
```
{
  "wifiGetClientHistory": {}
}
```

- 데이터 있을때
```
{
  "wifiGetClientHistory": {
    "macAddress": "",
    "clientId": 0
  }
}
```
[[wifi.WifiGetClientHistoryRequest]]


## 응답정보
- Unimplemented (12)
[[wifi.WifiGetClientHistoryResponse]]


