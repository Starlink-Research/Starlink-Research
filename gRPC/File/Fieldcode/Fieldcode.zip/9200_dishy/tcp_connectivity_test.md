Field_code: 1039
hex_data: 0000000003FA4000

## 형식
![[Pasted image 20241013151703.png]]
[[SpaceX.API.Device.TcpConnectivityTestRequest]]




## 요청정보
- 데이터 없을때
```
{
  "tcpConnectivityTest": {}
}
```

- 데이터 있을때
```
{
  "tcpConnectivityTest": {
    "target": "192.168.1.1",
    "port": 9000
  }
}
```
[[device.TcpConnectivityTestRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_TcpConnectivityTest




