Field_code: 2018
hex_data: 0000000003927E00

## 형식
![[Pasted image 20241013153744.png]]
[[SpaceX.API.Device.DishSetMaxPowerTestModeRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishSetMaxPowerTestMode": {}
}
```

- 데이터 있을때
```
{
  "dishSetMaxPowerTestMode": {
    "enabled": false
  }
}
```
[[device.DishSetMaxPowerTestModeRequest]]


## 응답정보
- PermissionDenied (7)
- Permission denied
[[device.DishSetMaxPowerTestModeResponse]]


