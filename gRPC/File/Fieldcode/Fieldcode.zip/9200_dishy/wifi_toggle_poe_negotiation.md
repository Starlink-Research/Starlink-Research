Field_code: 3025
hex_data: 00000000048abd0100

## 형식
![[Pasted image 20241013140918.png]]
[[SpaceX.API.Device.WifiTogglePoeNegotiationRequest]]



## 요청정보
- 데이터 없을때
```
{
  "wifiTogglePoeNegotiation": {}
}
```

- 데이터 있을때
```
{
  "wifiTogglePoeNegotiation": {
    "enable": false
  }
}
```
[[wifi.WifiTogglePoeNegotiationRequest]]


## 응답정보
- Unimplemented (12) 




