Field_code: 3020
hex_data: 0000000004e2bc0100

## 형식
![[Pasted image 20241013140646.png]]
[[SpaceX.API.Device.WifiGuestInfoRequest]]



## 요청정보
- 데이터 없을때
```
{
  "wifiGuestInfo": {}
}
```
[[wifi.WifiGuestInfoRequest]]



## 응답정보
- Unimplemented (12) 
[[wifi.WifiGuestInfoResponse]]


