Field_code: 1036
hex_data: 0000000003e24000

## 형식
![[Pasted image 20241012195213.png]]
[[SpaceX.API.Device.GetRadioStatsRequest]]



## 요청정보
- 데이터 없을때
```
{
  "getRadioStats": {}
}
```
[[device.GetRadioStatsRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_GetRadioStats
[[device.GetRadioStatsResponse]]



