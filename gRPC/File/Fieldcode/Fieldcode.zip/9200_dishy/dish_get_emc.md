Field_code: 2009
hex_data: 0000000003ca7d00

## 형식
![[Pasted image 20241012210430.png]]
[[SpaceX.API.Device.DishGetEmcRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishGetEmc": {}
}
```
[[device.DishGetEmcRequest]]


## 응답정보
- PermissionDenied (7) 
[[device.DishGetEmcResponse]]


