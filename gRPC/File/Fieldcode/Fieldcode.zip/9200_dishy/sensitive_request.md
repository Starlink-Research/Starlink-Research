Field_code: 1078
hex_data: 0000000003b24300

## 형식
![[Pasted image 20241012155436.png]]
[[SpaceX.API.Device.SignedData]]



## 요청정보
- 데이터 없을때
```
{
  "sensitiveRequest": {}
}
```

- 데이터 있을때
```
{
  "sensitiveRequest": {
    "data": "",
    "signature": ""
  }
}
```
[[common.SignedData]]

## 응답정보
- PermissionDenied (7)
- Sensitive commands can only be run from the cloud current user is LAN