Field_code: 3028
hex_data: 0000000004A2BD0100

## 형식

[[SpaceX.API.Device.WifiRunSelfTestRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishActivateRssiScan": {}
}
```

- 데이터 있을때
```

```
[[wifi.WifiRunSelfTestRequest]]


## 응답정보
- PermissionDenied (7)
- Permission denied




