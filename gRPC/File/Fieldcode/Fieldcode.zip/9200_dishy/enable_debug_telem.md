Field_code: 1034
hex_data: 0000000003d24000

## 형식
![[Pasted image 20241012161004.png]]
[[SpaceX.API.Device.EnableDebugTelemRequest]]



## 요청정보
- 데이터 없을때
```
{
  "enableDebugTelem": {}
}
```

- 데이터 있을때
```
{
  "enableDebugTelem": {
    "durationM": 0
  }
}
```
[[device.EnableDebugTelemRequest]]

## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_EnableDebugTelem
[[device.EnableDebugTelemResponse]]

