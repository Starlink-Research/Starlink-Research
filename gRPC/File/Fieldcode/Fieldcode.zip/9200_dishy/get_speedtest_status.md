Field_code: 1028
hex_data: 0000000003a24000

## 형식
![[Pasted image 20241012192445.png]]
[[SpaceX.API.Device.GetSpeedtestStatusRequest]]



## 요청정보
- 데이터 없을때
```
{
  "getSpeedtestStatus": {}
}
```
[[device.GetSpeedtestStatusRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_GetSpeedtestStatus
[[device.GetSpeedtestStatusResponse]]




