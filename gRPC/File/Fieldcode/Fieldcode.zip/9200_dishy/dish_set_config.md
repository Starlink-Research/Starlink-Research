Field_code: 2010
hex_data: 0000000003d27d00

## 형식
![[Pasted image 20241012210632.png]]
![[Pasted image 20241013152934.png]]
[[SpaceX.API.Device.DishSetConfigRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishSetConfig": {}
}
```

- 데이터 있을때
```
{
  "dishSetConfig": {
    "dishConfig": {
      "snowMeltMode": "AUTO",
      "applySnowMeltMode": false,
      "locationRequestMode": "NONE",
      "applyLocationRequestMode": false,
      "levelDishMode": "TILT_LIKE_NORMAL",
      "applyLevelDishMode": false,
      "powerSaveStartMinutes": 0,
      "applyPowerSaveStartMinutes": false,
      "powerSaveDurationMinutes": 0,
      "applyPowerSaveDurationMinutes": false,
      "powerSaveMode": false,
      "applyPowerSaveMode": false
    }
  }
}
```
[[dish.DishSetConfigRequest]]


## 응답정보
- PermissionDenied (7)
- Permission denied
[[dish.DishSetConfigResponse]]



