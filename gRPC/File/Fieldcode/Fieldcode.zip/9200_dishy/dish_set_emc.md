Field_code: 2007
hex_data: 0000000003ba7d00

## 형식
![[Pasted image 20241012205958.png]]
![[Pasted image 20241012210055.png]]
[[SpaceX.API.Device.DishSetEmcRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishSetEmc": {}
}
```

- 데이터 있을때
```
{
  "dishSetEmc": {
    "theta": 0,
    "rxChan": 0,
    "phi": 0,
    "txChan": 0,
    "modulation": 0,
    "desiredTiltAngle": 0,
    "chanOverride": false,
    "thetaEnabled": false,
    "phiEnabled": false,
    "idle": false,
    "fastSwitching": false,
    "skySearch": false,
    "forcePllUnlock": false,
    "forceEirpFailure": false,
    "snowActiveOverride": false,
    "manualTilting": false,
    "reboot": false,
    "tiltToStowed": false,
    "continuousMotorTest": false,
    "distanceOverrideMeters": 0,
    "amplitudeTaperOverride": 0,
    "countryCodeOverride": 0,
    "txDutyCycleOverride": 0,
    "rxDutyCycleOverride": 0,
    "eirpLegalLimitDbwOverride": 0,
    "eirpAdjustmentDb": 0
  }
}
```
[[device.DishSetEmcRequest]]



## 응답정보
 - PermissionDenied (7) 
[[device.DishSetEmcResponse]]



