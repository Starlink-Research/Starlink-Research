Field_code: 6000
hex_data: 000000000482f70200

## 형식
![[Pasted image 20241013142246.png]]
[[SpaceX.API.Device.GetDiagnosticsRequest]]


## 요청정보
- 데이터 없을때
```
{
  "getDiagnostics": {}
}
```
[[device.GetDiagnosticsRequest]]




## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "25",
  "dish_get_diagnostics": {
    "id": "ut01000000-00000000-00df1780",
    "hardware_version": "rev4_prod3",
    "software_version": "dc6da6f2-7a98-4cdf-9372-80359e046af9.uterm_manifest.release",
    "utc_offset_s": 0,
    "alerts": {
      "dish_is_heating": false,
      "dish_thermal_throttle": false,
      "dish_thermal_shutdown": false,
      "power_supply_thermal_throttle": false,
      "motors_stuck": false,
      "mast_not_near_vertical": false,
      "slow_ethernet_speeds": false,
      "software_install_pending": false,
      "moving_too_fast_for_policy": false,
      "obstructed": false
    },
    "disablement_code": "UNKNOWN",
    "hardware_self_test": "PASSED",
    "location": {
      "enabled": false,
      "latitude": 0,
      "longitude": 0,
      "altitude_meters": 0
    }
  }
}
```
[[device.DishGetDiagnosticsResponse]]


