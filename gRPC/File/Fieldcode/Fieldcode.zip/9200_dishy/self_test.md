Field_code: 1031
hex_data: 0000000003ba4000

## 형식
![[Pasted image 20241012193435.png]]
[[SpaceX.API.Device.SelfTestRequest]]



## 요청정보
- 데이터 없을때
```
{
  "selfTest": {}
}
```

- 데이터 있을때
```
{
  "selfTest": {
    "detailed": true
  }
}
```
[[dish.SelfTestRequest]]



## 응답정보
- PermissionDenied (7)
- Permission denied
[[dish.SelfTestResponse]]


