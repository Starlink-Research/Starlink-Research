Field_code: 2015
hex_data: 0000000003fa7d00

## 형식
![[Pasted image 20241012212150.png]]
[[SpaceX.API.Device.DishGetDataRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishGetData": {}
}
```

- 데이터 있을때
```
{
  "dishGetData": {
    "id": 0
  }
}
```
[[dish.DishGetDataRequest]]



## 응답정보
- PermissionDenied (7)
- Permission denied



