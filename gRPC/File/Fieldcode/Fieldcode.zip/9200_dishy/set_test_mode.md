Field_code: 1032
hex_data: 0000000003c24000

## 형식
![[Pasted image 20241012193911.png]]
[[SpaceX.API.Device.SetTestModeRequest]]



## 요청정보
- 데이터 없을때
```
{
  "setTestMode": {}
}
```

- 데이터 있을때
```
{
  "setTestMode": {
    "rfMode": "TX",
    "disableLossOfCommFdir": false,
    "enableRulesOverride": false
  }
}
```
[[dish.SetTestModeRequest]]



## 응답정보
- PermissionDenied (7)
- Permission denied
[[dish.SetTestModeResponse]]


