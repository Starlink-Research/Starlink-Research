Field_code: 2017
hex_data: 00000000038a7e00

## 형식
![[Pasted image 20241012212725.png]]
[[SpaceX.API.Device.DishClearObstructionMapRequest]]



## 요청정보
- 데이터 없을때
```
{
  "dishClearObstructionMap": {}
}
```
[[dish.DishClearObstructionMapRequest]]


## 응답정보
```
{
  "id": "0",
  "status": null,
  "api_version": "25",
  "dish_clear_obstruction_map": {}
}
```
[[dish.DishClearObstructionMapResponse]]

