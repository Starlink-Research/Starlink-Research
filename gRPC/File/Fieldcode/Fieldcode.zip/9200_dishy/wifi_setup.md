Field_code: 3003
hex_data: 0000000004dabb0100

## 형식
![[Pasted image 20241012215819.png]]
[[SpaceX.API.Device.WifiSetupRequest]]



## 요청정보
- 데이터 없을때
```
{
  "wifiSetup": {}
}
```

- 데이터 있을때
```
{
  "wifiSetup": {
    "skip": false,
    "networkName": "a",
    "networkPassword": "aa",
    "bypass": false
  }
}
```
[[wifi.WifiSetupRequest]]


## 응답정보
- Unimplemented (12)
[[wifi.WifiSetupResponse]]

