Field_code: 3026
hex_data: 000000000492bd0100

## 형식
![[Pasted image 20241013141110.png]]
[[SpaceX.API.Device.WifiFactoryTestCommandRequest]]


## 요청정보
- 데이터 없을때
```
{
  "wifiFactoryTestCommand": {}
}
```

- 데이터 있을때
```
{
  "wifiFactoryTestCommand": {
    "iwprivCommand": {
      "iface": "a",
      "arg": "a",
      "ioctl": "IOCTL_SET"
    }
  }
}
```
[[wifi.WifiFactoryTestCommandRequest]]


## 응답정보
- Unimplemented (12) 
[[wifi.WifiFactoryTestCommandRespons]]


