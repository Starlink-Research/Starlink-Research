Field_code: 1016
hex_data: 0000000003c23f00

## 형식
![[Pasted image 20241012164826.png]]
[[SpaceX.API.Device.PingHostRequest]]



## 요청정보
- 데이터 없을때
```
{
  "pingHost": {}
}
```

- 데이터 있을때
```
{
  "pingHost": {
    "address": "8.8.8.8"
  }
}
```
[[device.PingHostRequest]]



## 응답정보
- Unimplemented (12)
- Unimplemented: *device.Request_PingHost
[[device.PingHostResponse]]


